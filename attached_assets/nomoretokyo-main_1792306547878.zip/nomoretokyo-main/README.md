# Storms Tuners Hub

Build a complete production-quality web application called **Storms Tuners Management System (STMS)**.

This is for a FiveM mechanic business where mechanics install upgrades, collect payment, upload proof, and management tracks completed work.

The app should feel premium, extremely polished, modern, and fast.

DESIGN

Visual Style:

* Inspired by the attached Storms Tuners pricing sheet
* Dark black UI
* Glossy panels
* Red accents
* Neon blue highlights
* Performance car aesthetic
* Glassmorphism
* Smooth transitions
* Animated counters
* Mobile + desktop responsive
* Dashboard style UI
* Professional—not gaming UI

---

SYSTEM ROLES

ROLE 1 — MECHANIC

Can:

* Login
* Create work orders
* Upload payment screenshots
* View only their jobs
* Edit drafts
* View paid jobs
* Track earnings
* Generate receipts
* Search previous customer jobs
* Receive Discord notifications

Cannot:

* Mark paid
* Delete completed jobs
* View boss analytics

ROLE 2 — MANAGER

Can:

* View all orders
* Approve payments
* Reject payments
* View analytics
* Search all mechanics

Cannot:

* Manage system settings

ROLE 3 — OWNER / BOSS

Full access:

* All mechanic tools
* All manager tools
* Manage users
* Revenue analytics
* Edit pricing
* Export data
* View logs
* Inventory control
* Commission settings

---

LOGIN

Pages:

* Login
* Register (owner disabled)
* Forgot Password

Support:

* Email login
* Discord OAuth
* Remember login
* Session persistence

---

MECHANIC DASHBOARD

Cards:
Revenue Generated
Completed Jobs
Pending Orders
Average Ticket

Charts:
Revenue by Day
Jobs by Mechanic

Recent Orders Table

Buttons:
New Order
History
Settings

---

CREATE WORK ORDER

SECTION 1 — CUSTOMER

Customer Name
Vehicle Name
Plate
Mechanic
Notes

Auto Timestamp

---

SECTION 2 — SERVICES

REPAIR
Repair → $1,000

BRAKES
None
Brake 1 → $10,000
Brake 2 → $15,000
Brake 3 → $20,000

ENGINE
None
Engine 1 → $30,000
Engine 2 → $50,000
Engine 3 → $70,000
Engine 4 → $90,000

SUSPENSION
None
Suspension 1 → $6,000
Suspension 2 → $12,000
Suspension 3 → $18,000
Suspension 4 → $24,000
Suspension 5 → $30,000

TRANSMISSION
None
Transmission 1 → $10,000
Transmission 2 → $20,000
Transmission 3 → $30,000
Transmission 4 → $40,000

TURBO
Disabled
Enabled → $60,000

VISUAL
Respray → $15,000

LIGHTING
Neon → $5,000
Tire Smoke → $5,000
Window Tint → $2,500
Xenon → $2,500

EXTRAS
Horns → $1,500
Hydraulics → $1,500
Plate Style → $1,500
Wheels → $2,000

---

ORDER CALCULATOR

Features:

* Live updating total
* Animated calculation
* Itemized invoice
* Tax toggle (optional)
* Final total

Show:

Items

Subtotal

Total

Generate Order ID:
ST-000001
ST-000002

---

PAYMENT PROOF

Upload:

* Image
* Drag & Drop
* Paste Screenshot

Features:
Preview
Zoom
Delete
Replace

Require upload before submission

---

SUBMIT ORDER

Create:
Order
Receipt
Discord Event
Database Record

Order Status:
Draft
Submitted
Paid
Rejected
Archived

---

DISCORD INTEGRATION

Send rich embed.

Embed:

Title:
Storms Tuners Work Order

Fields:

Order ID
Customer
Vehicle
Mechanic
Installed Upgrades
Price
Timestamp

Thumbnail:
Company logo

Image:
Payment Screenshot

Status:
🟡 Pending Payment

Buttons:

✅ Mark Paid
❌ Reject
📄 View Order

When owner presses PAID:

Update embed:
🟢 PAID

Change color:
Green

Show:
Approved By
Time Approved

Ping mechanic:
<@mechanic>

Message:
Your work order has been paid.

When REJECT:

Open popup:
Enter reason

Update:
🔴 Rejected

Notify mechanic.

---

VEHICLE HISTORY

Search:
Plate
Customer
Vehicle

Show:
Previous installs
Total spent
Previous mechanics

---

RECEIPTS

Generate printable receipt.

Include:
Order ID
Vehicle
Customer
Items
Total
Mechanic

Generate:
PDF
Print
Download

---

MECHANIC STATS

Track:

Total Revenue
Completed Jobs
Average Order
Pending Payments
Fastest Completion

Leaderboard:
Top Mechanics

---

OWNER ANALYTICS

Revenue Today
Revenue Week
Revenue Month
Pending Orders
Top Services
Top Mechanics

Charts:
Revenue
Orders
Payments

Export:
CSV
Excel
PDF

---

INVENTORY SYSTEM

Track:

Turbo Kits
Engine Kits
Neons
Suspension Kits

Warn:
Low Stock

Deduct automatically.

---

COMMISSION SYSTEM

Owner can configure.

Examples:
10%
15%

Auto calculate payout.

---

AUDIT LOGS

Track:

User
Action
Timestamp

Example:
Owner marked ST-00422 paid.

---

NOTIFICATIONS

Browser notifications
Discord notifications
Sound effects

---

SETTINGS

Edit pricing
Logo upload
Webhook URL
Roles
Currency

---

DATABASE

Tables:

Users
Orders
Payments
Vehicles
Inventory
Receipts
Notifications
Logs

---

TECH STACK

Frontend:
Next.js
React
Tailwind
Framer Motion

Backend:
Supabase

Storage:
Supabase Storage

Discord:
Bot + Webhooks

Authentication:
Supabase Auth

Deployment:
Vercel

Build everything fully functional with realistic UI, proper validation, modern components, polished interactions, and production-ready structure.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://nomoretokyo.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/911c3658-0c62-4c5e-afdd-26a811f7bba9).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
