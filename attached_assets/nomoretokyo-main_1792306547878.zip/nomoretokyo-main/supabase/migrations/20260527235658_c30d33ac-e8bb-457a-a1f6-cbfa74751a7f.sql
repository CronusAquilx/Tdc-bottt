
CREATE TABLE public.job_ads (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  posted_by UUID NOT NULL,
  pinned BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.job_ads TO authenticated;
GRANT ALL ON public.job_ads TO service_role;

ALTER TABLE public.job_ads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "job_ads_select_authed" ON public.job_ads
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "job_ads_owner_all" ON public.job_ads
  FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'owner'::app_role))
  WITH CHECK (has_role(auth.uid(), 'owner'::app_role));

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER job_ads_set_updated_at
  BEFORE UPDATE ON public.job_ads
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
