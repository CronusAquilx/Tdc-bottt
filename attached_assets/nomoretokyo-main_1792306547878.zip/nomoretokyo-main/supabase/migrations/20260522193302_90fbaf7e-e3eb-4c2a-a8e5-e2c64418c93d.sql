-- 1. Restrict profiles SELECT to self/staff
DROP POLICY IF EXISTS "profiles_select_all_authed" ON public.profiles;

CREATE POLICY "profiles_select_self_or_staff"
ON public.profiles FOR SELECT
TO authenticated
USING (
  id = auth.uid()
  OR public.has_role(auth.uid(), 'owner'::app_role)
  OR public.has_role(auth.uid(), 'manager'::app_role)
);

-- Public-safe view for display names / avatars (no sensitive fields)
CREATE OR REPLACE VIEW public.profiles_public
WITH (security_invoker = true) AS
SELECT id, display_name, avatar_url
FROM public.profiles;

GRANT SELECT ON public.profiles_public TO authenticated, anon;

-- 2. Prevent self privilege escalation on profile updates
CREATE OR REPLACE FUNCTION public.prevent_profile_privilege_escalation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Owners can change anything
  IF public.has_role(auth.uid(), 'owner'::app_role) THEN
    RETURN NEW;
  END IF;

  IF NEW.commission_rate IS DISTINCT FROM OLD.commission_rate
     OR NEW.weekly_hours IS DISTINCT FROM OLD.weekly_hours
     OR NEW.discord_webhook_url IS DISTINCT FROM OLD.discord_webhook_url
     OR NEW.discord_id IS DISTINCT FROM OLD.discord_id
     OR NEW.email IS DISTINCT FROM OLD.email
     OR NEW.id IS DISTINCT FROM OLD.id THEN
    RAISE EXCEPTION 'Only owners can modify protected profile fields';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profiles_prevent_privilege_escalation ON public.profiles;
CREATE TRIGGER profiles_prevent_privilege_escalation
BEFORE UPDATE ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.prevent_profile_privilege_escalation();

-- 3. Storage: add UPDATE policy on payment-proofs
DROP POLICY IF EXISTS "proofs_update_own_or_owner" ON storage.objects;
CREATE POLICY "proofs_update_own_or_owner"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'payment-proofs'
  AND (
    (storage.foldername(name))[1] = (auth.uid())::text
    OR public.has_role(auth.uid(), 'owner'::app_role)
  )
)
WITH CHECK (
  bucket_id = 'payment-proofs'
  AND (
    (storage.foldername(name))[1] = (auth.uid())::text
    OR public.has_role(auth.uid(), 'owner'::app_role)
  )
);