ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS commission_rate numeric NOT NULL DEFAULT 0.4,
  ADD COLUMN IF NOT EXISTS weekly_hours numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS weekly_discord_message_id text;

INSERT INTO public.app_settings (key, value)
VALUES ('payroll_config', jsonb_build_object('payout_day', 5, 'last_payout_at', null))
ON CONFLICT (key) DO NOTHING;