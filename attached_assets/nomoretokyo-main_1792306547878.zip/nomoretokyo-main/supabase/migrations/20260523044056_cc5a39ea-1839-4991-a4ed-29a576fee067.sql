
-- Create trial mechanic user
DO $$
DECLARE
  trial_uid uuid;
  existing_uid uuid;
BEGIN
  SELECT id INTO existing_uid FROM auth.users WHERE email = 'trialmech@trial.local';
  IF existing_uid IS NOT NULL THEN
    RAISE NOTICE 'Trial user already exists: %', existing_uid;
    RETURN;
  END IF;

  trial_uid := gen_random_uuid();

  INSERT INTO auth.users (
    instance_id, id, aud, role, email,
    encrypted_password, email_confirmed_at,
    raw_app_meta_data, raw_user_meta_data,
    created_at, updated_at, confirmation_token,
    email_change, email_change_token_new, recovery_token
  ) VALUES (
    '00000000-0000-0000-0000-000000000000',
    trial_uid, 'authenticated', 'authenticated',
    'trialmech@trial.local',
    crypt('123!ab', gen_salt('bf')),
    now(),
    '{"provider":"email","providers":["email"]}'::jsonb,
    '{"display_name":"TrialMech"}'::jsonb,
    now(), now(), '', '', '', ''
  );

  INSERT INTO auth.identities (
    id, user_id, identity_data, provider, provider_id,
    last_sign_in_at, created_at, updated_at
  ) VALUES (
    gen_random_uuid(), trial_uid,
    jsonb_build_object('sub', trial_uid::text, 'email', 'trialmech@trial.local'),
    'email', trial_uid::text,
    now(), now(), now()
  );

  -- handle_new_user trigger should create profile + mechanic role,
  -- but ensure they exist in case trigger isn't on auth.users
  INSERT INTO public.profiles (id, email, display_name)
  VALUES (trial_uid, 'trialmech@trial.local', 'TrialMech')
  ON CONFLICT (id) DO NOTHING;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (trial_uid, 'mechanic')
  ON CONFLICT DO NOTHING;
END $$;
