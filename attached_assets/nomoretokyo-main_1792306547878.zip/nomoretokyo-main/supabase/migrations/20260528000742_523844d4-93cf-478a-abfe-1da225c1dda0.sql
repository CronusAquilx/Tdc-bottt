
CREATE OR REPLACE FUNCTION public.prevent_profile_privilege_escalation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Service role (server-side admin client) bypasses this guard
  IF current_setting('role', true) = 'service_role' OR auth.uid() IS NULL THEN
    RETURN NEW;
  END IF;

  IF public.has_role(auth.uid(), 'owner'::app_role) THEN
    RETURN NEW;
  END IF;

  IF NEW.commission_rate IS DISTINCT FROM OLD.commission_rate
     OR NEW.weekly_hours IS DISTINCT FROM OLD.weekly_hours
     OR NEW.discord_webhook_url IS DISTINCT FROM OLD.discord_webhook_url
     OR NEW.discord_id IS DISTINCT FROM OLD.discord_id
     OR NEW.email IS DISTINCT FROM OLD.email
     OR NEW.id IS DISTINCT FROM OLD.id THEN
    RAISE EXCEPTION 'Only owners can modify protected profile fields';
  END IF;

  RETURN NEW;
END;
$function$;
