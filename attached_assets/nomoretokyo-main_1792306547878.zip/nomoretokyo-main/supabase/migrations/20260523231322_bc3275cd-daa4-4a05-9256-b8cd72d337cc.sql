
DELETE FROM public.orders;
DELETE FROM public.audit_logs;
DELETE FROM public.app_settings;
DELETE FROM public.user_roles;
DELETE FROM public.profiles;
DELETE FROM auth.identities;
DELETE FROM auth.users;

DO $$
DECLARE
  v_users uuid[] := ARRAY[gen_random_uuid(), gen_random_uuid(), gen_random_uuid()];
  v_emails text[] := ARRAY['phoenix@tokyocustoms.gg','lu@tokyocustoms.gg','ander@tokyocustoms.gg'];
  v_names text[] := ARRAY['Phoenix','Lu','Ander'];
  i int;
BEGIN
  FOR i IN 1..3 LOOP
    INSERT INTO auth.users (
      id, instance_id, aud, role, email, encrypted_password,
      email_confirmed_at, raw_app_meta_data, raw_user_meta_data,
      created_at, updated_at, confirmation_token, recovery_token, email_change_token_new, email_change
    ) VALUES (
      v_users[i], '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
      v_emails[i], crypt('boss123', gen_salt('bf')),
      now(),
      jsonb_build_object('provider','email','providers',ARRAY['email']),
      jsonb_build_object('display_name', v_names[i]),
      now(), now(), '', '', '', ''
    );

    INSERT INTO auth.identities (id, user_id, provider_id, identity_data, provider, last_sign_in_at, created_at, updated_at)
    VALUES (
      gen_random_uuid(), v_users[i], v_users[i]::text,
      jsonb_build_object('sub', v_users[i]::text, 'email', v_emails[i]),
      'email', now(), now(), now()
    );

    -- handle_new_user trigger already created profile + mechanic role; promote to owner
    UPDATE public.profiles SET display_name = v_names[i], email = v_emails[i] WHERE id = v_users[i];
    DELETE FROM public.user_roles WHERE user_id = v_users[i];
    INSERT INTO public.user_roles (user_id, role) VALUES (v_users[i], 'owner');
  END LOOP;
END $$;

CREATE OR REPLACE FUNCTION public.reset_system_data()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'owner'::app_role) THEN
    RAISE EXCEPTION 'Only owners can reset the system';
  END IF;
  DELETE FROM public.orders;
  DELETE FROM public.audit_logs;
  UPDATE public.profiles SET weekly_hours = 0, weekly_discord_message_id = NULL;
END;
$$;

REVOKE ALL ON FUNCTION public.reset_system_data() FROM public;
GRANT EXECUTE ON FUNCTION public.reset_system_data() TO authenticated;
