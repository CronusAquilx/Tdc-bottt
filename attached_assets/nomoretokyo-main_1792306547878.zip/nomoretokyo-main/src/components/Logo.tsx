import { Link } from "@tanstack/react-router";
import logoSrc from "@/assets/tokyo-logo.png";

export function Logo({ to = "/" }: { to?: string }) {
  return (
    <Link to={to} className="group flex items-center gap-2.5">
      <div className="relative">
        <div className="absolute inset-0 rounded-xl bg-primary/30 blur-lg transition group-hover:bg-primary/50" />
        <img
          src={logoSrc}
          alt="Tokyo Drift Customs"
          className="relative h-10 w-10 rounded-xl object-cover ring-1 ring-border/40 shadow-[0_0_24px_oklch(0.62_0.24_25/0.35)]"
        />
      </div>
      <div className="leading-tight">
        <div className="font-display text-sm font-bold tracking-wider uppercase">Tokyo Drift Customs</div>
        <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">東京 · Custom Garage</div>
      </div>
    </Link>
  );
}