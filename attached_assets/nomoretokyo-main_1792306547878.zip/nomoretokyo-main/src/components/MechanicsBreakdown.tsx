import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { ChevronRight, Users, Wrench } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { formatMoney } from "@/lib/pricing";
import { StatusBadge } from "@/components/StatusBadge";

type Order = {
  id: string;
  order_number: string;
  mechanic_id: string | null;
  status: string;
  total: number;
  parts_cost?: number;
  labour?: number;
  created_at: string;
  items?: unknown;
};

type Item = { label: string; price: number; category?: string };

function labourOf(o: Order) {
  const total = Number(o.total) || 0;
  const parts = Number(o.parts_cost ?? 0) || 0;
  const l = Number(o.labour ?? 0);
  return l > 0 ? l : Math.max(0, total - parts);
}

export function MechanicsBreakdown({ orders }: { orders: Order[] }) {
  const [openMech, setOpenMech] = useState<string | null>(null);
  const [openOrder, setOpenOrder] = useState<string | null>(null);

  const mechIds = useMemo(
    () => Array.from(new Set(orders.map((o) => o.mechanic_id).filter(Boolean))) as string[],
    [orders],
  );

  const { data: profiles } = useQuery({
    queryKey: ["mech-breakdown-profiles", mechIds.sort().join(",")],
    queryFn: async () => {
      if (mechIds.length === 0) return [] as any[];
      const { data, error } = await supabase
        .from("profiles")
        .select("id, display_name, email, commission_rate")
        .in("id", mechIds);
      if (error) throw error;
      return data ?? [];
    },
    enabled: mechIds.length > 0,
  });

  const profMap = useMemo(() => {
    const m: Record<string, { name: string; rate: number }> = {};
    (profiles ?? []).forEach((p: any) => {
      m[p.id] = {
        name: p.display_name || p.email || "Unknown",
        rate: typeof p.commission_rate === "number" ? p.commission_rate : 0.4,
      };
    });
    return m;
  }, [profiles]);

  const groups = useMemo(() => {
    const byMech: Record<string, Order[]> = {};
    orders.forEach((o) => {
      const key = o.mechanic_id ?? "unassigned";
      (byMech[key] ||= []).push(o);
    });
    return Object.entries(byMech)
      .map(([id, list]) => {
        const rate = profMap[id]?.rate ?? 0.4;
        const paid = list.filter((o) => o.status === "paid");
        const totalCost = list.reduce((s, o) => s + Number(o.total), 0);
        const partsCost = list.reduce((s, o) => s + Number(o.parts_cost ?? 0), 0);
        const labour = list.reduce((s, o) => s + labourOf(o), 0);
        const commission = paid.reduce((s, o) => s + labourOf(o) * rate, 0);
        return {
          id,
          name: id === "unassigned" ? "Unassigned" : profMap[id]?.name ?? "…",
          rate,
          orders: list.sort((a, b) => +new Date(b.created_at) - +new Date(a.created_at)),
          count: list.length,
          totalCost,
          partsCost,
          labour,
          commission,
        };
      })
      .sort((a, b) => b.totalCost - a.totalCost);
  }, [orders, profMap]);

  if (groups.length === 0) return null;

  return (
    <div className="glass rounded-2xl p-4 md:p-6">
      <div className="mb-4 flex items-center gap-2">
        <Users className="h-5 w-5 text-accent" />
        <h2 className="font-display text-xl font-semibold">Mechanics</h2>
      </div>

      <div className="space-y-3">
        {groups.map((g) => {
          const isOpen = openMech === g.id;
          return (
            <div key={g.id} className="overflow-hidden rounded-xl border border-border/50 bg-card/30">
              <button
                onClick={() => setOpenMech(isOpen ? null : g.id)}
                className="flex w-full items-center gap-3 p-4 text-left transition hover:bg-card/50"
              >
                <ChevronRight className={`h-4 w-4 shrink-0 text-muted-foreground transition-transform ${isOpen ? "rotate-90" : ""}`} />
                <div className="min-w-0 flex-1">
                  <div className="font-display font-semibold">{g.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {g.count} order{g.count === 1 ? "" : "s"} · {(g.rate * 100).toFixed(0)}% commission
                  </div>
                </div>
                <div className="hidden shrink-0 gap-6 text-right sm:flex">
                  <Stat label="Total" value={formatMoney(g.totalCost)} />
                  <Stat label="Parts" value={formatMoney(g.partsCost)} tone="emerald" />
                  <Stat label="Labour" value={formatMoney(g.labour)} />
                  <Stat label="Est. Pay" value={formatMoney(g.commission)} tone="accent" />
                </div>
              </button>

              {/* Mobile stat row */}
              <div className="grid grid-cols-2 gap-2 px-4 pb-3 sm:hidden">
                <Stat label="Total" value={formatMoney(g.totalCost)} />
                <Stat label="Parts" value={formatMoney(g.partsCost)} tone="emerald" />
                <Stat label="Labour" value={formatMoney(g.labour)} />
                <Stat label="Est. Pay" value={formatMoney(g.commission)} tone="accent" />
              </div>

              {isOpen && (
                <div className="border-t border-border/50 bg-background/40 p-3">
                  <ul className="space-y-2">
                    {g.orders.map((o) => {
                      const oOpen = openOrder === o.id;
                      const items = Array.isArray(o.items) ? (o.items as Item[]) : [];
                      return (
                        <li key={o.id} className="overflow-hidden rounded-lg border border-border/40 bg-card/40">
                          <button
                            onClick={() => setOpenOrder(oOpen ? null : o.id)}
                            className="flex w-full items-center gap-2 p-3 text-left transition hover:bg-card/60"
                          >
                            <ChevronRight className={`h-3.5 w-3.5 shrink-0 text-muted-foreground transition-transform ${oOpen ? "rotate-90" : ""}`} />
                            <span className="font-mono text-xs font-semibold text-accent">{o.order_number}</span>
                            <StatusBadge status={o.status as any} />
                            <span className="ml-auto font-display text-sm font-semibold">{formatMoney(Number(o.total))}</span>
                          </button>
                          {oOpen && (
                            <div className="border-t border-border/40 p-3">
                              {items.length === 0 ? (
                                <p className="text-xs text-muted-foreground">No itemized work recorded.</p>
                              ) : (
                                <ul className="space-y-1.5">
                                  {items.map((it, i) => (
                                    <li key={i} className="flex items-center gap-2 text-sm">
                                      <Wrench className="h-3.5 w-3.5 text-muted-foreground" />
                                      <span className="min-w-0 flex-1 truncate">{it.label}</span>
                                      <span className="font-mono text-xs">{formatMoney(Number(it.price))}</span>
                                    </li>
                                  ))}
                                </ul>
                              )}
                              <div className="mt-3 grid grid-cols-3 gap-2 border-t border-border/40 pt-2">
                                <Stat label="Parts" value={formatMoney(Number(o.parts_cost ?? 0))} tone="emerald" />
                                <Stat label="Labour" value={formatMoney(labourOf(o))} />
                                <Stat label="Est. Pay" value={formatMoney(labourOf(o) * g.rate)} tone="accent" />
                              </div>
                              <Link
                                to="/orders/$id"
                                params={{ id: o.id }}
                                className="mt-3 inline-block text-xs font-semibold text-accent hover:underline"
                              >
                                Open full order →
                              </Link>
                            </div>
                          )}
                        </li>
                      );
                    })}
                  </ul>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone?: "emerald" | "accent" }) {
  const color = tone === "emerald" ? "text-emerald-400" : tone === "accent" ? "text-accent" : "text-foreground";
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`font-display text-sm font-semibold ${color}`}>{value}</div>
    </div>
  );
}