import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { GraduationCap, ChevronLeft, ChevronRight, Sparkles } from "lucide-react";

type Step = { title: string; body: string };

const OWNER_STEPS: Step[] = [
  { title: "Welcome, Boss 👑", body: "This site replaces the spreadsheet. You'll see every job, every dollar, and every mechanic's pay in one place — no more copy-paste, no more lost rows." },
  { title: "Settings · One-time setup", body: "Open Settings → set the Discord Payroll Webhook (where weekly pay posts) and the fallback Discord Webhook. Pick the payout day (e.g. Friday). Done." },
  { title: "Crew & Roles", body: "Open Crew. For each mechanic set their commission % and paste their personal Discord webhook — every order they submit posts to THEIR channel automatically." },
  { title: "Reviewing jobs", body: "When a mechanic submits an order it shows under Jobs as 'submitted'. Open it, check the payment proof image, then hit Mark Paid or Reject. The Discord embed updates itself — no duplicate posts." },
  { title: "How pay is calculated", body: "Customer Total − Parts Cost = Labour. Mechanic gets their commission % of Labour (not the full sale). This matches the spreadsheet's Commission column, just done automatically." },
  { title: "Weekly payout", body: "On payout day, open Settings → Run Payout. A summary embed posts, every mechanic's weekly counter resets to zero, and the new week begins." },
  { title: "That's it", body: "Analytics shows revenue, labour profit and top mechanics. The whole flow runs on its own — you just review and approve." },
];

const MECHANIC_STEPS: Step[] = [
  { title: "Welcome 🔧", body: "Every job you finish lives here. Submit it, get paid, see your weekly commission update in real time." },
  { title: "New Order", body: "Tap New Order. Click the upgrades you did (each shows the customer charge in red and the parts cost in green). Resprays auto-cap at $60k after 4." },
  { title: "Payment proof", body: "Take a screenshot of the customer's payment, drag/paste/upload it, then Submit. Boss reviews and marks Paid." },
  { title: "Your commission", body: "You earn your % of Labour (Customer Total − Parts Cost). The live invoice on the right shows your estimated payout while you build the order." },
  { title: "Weekly pay card", body: "On the Dashboard the Weekly Pay card shows your invoices, labour, and expected pay for the current week. Enter your hours worked there too." },
  { title: "Discord", body: "Every submit posts to your personal Discord channel, and the boss approves from there or from this site. No double-posts — the same message just updates." },
];

export function TutorialDialog({ role }: { role: "owner" | "mechanic" }) {
  const steps = role === "owner" ? OWNER_STEPS : MECHANIC_STEPS;
  const [open, setOpen] = useState(false);
  const [i, setI] = useState(0);
  const step = steps[i];
  const last = i === steps.length - 1;

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) setI(0); }}>
      <DialogTrigger asChild>
        <button className="inline-flex w-full md:w-auto items-center justify-center gap-2 rounded-xl border border-accent/40 bg-accent/10 px-5 py-3 font-semibold text-accent transition hover:bg-accent/20">
          <GraduationCap className="h-4 w-4" /> Tutorial
        </button>
      </DialogTrigger>
      <DialogContent className="max-w-md border-border/60 bg-card">
        <DialogHeader>
          <div className="mb-2 flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-accent">
            <Sparkles className="h-3.5 w-3.5" /> {role === "owner" ? "Owner walkthrough" : "Mechanic walkthrough"} · {i + 1}/{steps.length}
          </div>
          <DialogTitle className="font-display text-xl">{step.title}</DialogTitle>
          <DialogDescription className="pt-2 text-sm leading-relaxed text-foreground/80">
            {step.body}
          </DialogDescription>
        </DialogHeader>
        <div className="mt-2 flex items-center gap-1">
          {steps.map((_, n) => (
            <div key={n} className={`h-1 flex-1 rounded-full ${n <= i ? "bg-primary" : "bg-border/60"}`} />
          ))}
        </div>
        <div className="mt-4 flex items-center justify-between gap-3">
          <button disabled={i === 0} onClick={() => setI(i - 1)} className="inline-flex items-center gap-1 rounded-lg px-3 py-2 text-sm font-semibold text-muted-foreground transition hover:text-foreground disabled:opacity-30">
            <ChevronLeft className="h-4 w-4" /> Back
          </button>
          {last ? (
            <button onClick={() => setOpen(false)} className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">Got it</button>
          ) : (
            <button onClick={() => setI(i + 1)} className="inline-flex items-center gap-1 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">
              Next <ChevronRight className="h-4 w-4" />
            </button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}