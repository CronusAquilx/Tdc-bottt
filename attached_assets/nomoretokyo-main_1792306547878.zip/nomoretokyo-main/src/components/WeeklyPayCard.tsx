import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Loader2, Clock4, DollarSign } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { setWeeklyHours } from "@/lib/payroll.functions";
import { formatMoney } from "@/lib/pricing";

export function WeeklyPayCard() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [hours, setHours] = useState("0");
  const [busy, setBusy] = useState(false);

  const { data } = useQuery({
    queryKey: ["my-weekly", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data: cfgRow } = await supabase.from("app_settings").select("value").eq("key", "payroll_config").maybeSingle();
      const cfg = (cfgRow?.value as { payout_day?: number; last_payout_at?: string | null } | null) ?? {};
      const payoutDay = typeof cfg.payout_day === "number" ? cfg.payout_day : 5;
      let weekStart: Date;
      if (cfg.last_payout_at) weekStart = new Date(cfg.last_payout_at);
      else {
        const d = new Date(); d.setHours(0,0,0,0);
        const diff = (d.getDay() - payoutDay + 7) % 7;
        d.setDate(d.getDate() - diff); weekStart = d;
      }
      const { data: prof } = await supabase.from("profiles").select("*").eq("id", user!.id).maybeSingle();
      const p = prof as unknown as { commission_rate: number | null; weekly_hours: number | null };
      const { data: orders } = await supabase.from("orders")
        .select("order_number,total,status")
        .eq("mechanic_id", user!.id)
        .neq("status","draft").neq("status","rejected")
        .gte("created_at", weekStart.toISOString());
      const total = (orders ?? []).reduce((s,o) => s + Number(o.total), 0);
      const rate = Number(p?.commission_rate ?? 0.4);
      const hrs = Number(p?.weekly_hours ?? 0);
      return {
        count: (orders ?? []).length,
        total, rate, hours: hrs,
        pay: total * rate,
        weekStart: weekStart.toLocaleDateString(),
        payoutDay: ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"][payoutDay],
      };
    },
  });

  useEffect(() => { if (data) setHours(String(data.hours)); }, [data]);

  async function saveHours() {
    const n = Number(hours);
    if (Number.isNaN(n) || n < 0) { toast.error("Invalid hours"); return; }
    setBusy(true);
    try {
      await setWeeklyHours({ data: { hours: n } });
      toast.success("Hours updated");
      qc.invalidateQueries({ queryKey: ["my-weekly"] });
    } catch (e: any) { toast.error(e?.message ?? "Failed"); }
    finally { setBusy(false); }
  }

  return (
    <section className="glass-strong rounded-2xl p-4 md:p-6">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-xs font-bold uppercase tracking-widest text-accent">This Pay Week</div>
          <h2 className="mt-1 font-display text-lg font-semibold sm:text-xl">Your Weekly Pay</h2>
          <p className="text-[11px] text-muted-foreground sm:text-xs">Week of {data?.weekStart ?? "—"} · Payout: {data?.payoutDay ?? "—"}</p>
        </div>
        <DollarSign className="h-6 w-6 shrink-0 text-accent" />
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Invoices" value={data?.count ?? 0} />
        <Stat label="Invoice Total" value={formatMoney(data?.total ?? 0)} />
        <Stat label="Commission" value={`${Math.round((data?.rate ?? 0) * 100)}%`} />
        <Stat label="Expected Pay" value={formatMoney(data?.pay ?? 0)} highlight />
      </div>

      <div className="mt-4 flex flex-wrap items-end gap-2">
        <label className="flex-1 min-w-[160px]">
          <span className="mb-1 flex items-center gap-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            <Clock4 className="h-3 w-3" /> Hours Worked This Week
          </span>
          <input
            type="number" min={0} step="0.25" value={hours}
            onChange={(e) => setHours(e.target.value)}
            className="w-full rounded-lg border border-border/60 bg-input/60 px-3 py-2 text-sm outline-none focus:border-accent"
          />
        </label>
        <button onClick={saveHours} disabled={busy}
          className="rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-accent-foreground disabled:opacity-50">
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save Hours"}
        </button>
      </div>
    </section>
  );
}

function Stat({ label, value, highlight }: { label: string; value: React.ReactNode; highlight?: boolean }) {
  return (
    <div className={`rounded-xl border border-border/40 bg-card/30 p-3 ${highlight ? "ring-1 ring-accent/50" : ""}`}>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`mt-1 font-display text-lg font-bold ${highlight ? "text-accent" : ""}`}>{value}</div>
    </div>
  );
}