const COLORS: Record<string, string> = {
  draft:     "bg-muted text-muted-foreground border-border",
  submitted: "bg-accent/15 text-accent border-accent/30",
  paid:      "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
  rejected:  "bg-primary/15 text-primary border-primary/30",
  archived:  "bg-muted text-muted-foreground border-border",
};

export function StatusBadge({ status }: { status: string }) {
  return (
    <span className={`inline-flex items-center rounded-md border px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${COLORS[status] ?? COLORS.draft}`}>
      {status}
    </span>
  );
}