import { motion, useMotionValue, useTransform, animate } from "framer-motion";
import { useEffect, type ReactNode } from "react";

export function StatCard({
  label,
  value,
  prefix = "",
  suffix = "",
  icon,
  accent = "red",
  delay = 0,
}: {
  label: string;
  value: number;
  prefix?: string;
  suffix?: string;
  icon?: ReactNode;
  accent?: "red" | "blue";
  delay?: number;
}) {
  const mv = useMotionValue(0);
  const rounded = useTransform(mv, (v) => `${prefix}${Math.round(v).toLocaleString()}${suffix}`);
  useEffect(() => {
    const c = animate(mv, value, { duration: 1.2, ease: "easeOut" });
    return () => c.stop();
  }, [value, mv]);
  const accentClass = accent === "red" ? "text-primary" : "text-accent";

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      className="glass relative overflow-hidden rounded-2xl p-4 md:p-5"
    >
      <div className={`absolute -right-8 -top-8 h-24 w-24 rounded-full opacity-20 blur-2xl ${accent === "red" ? "bg-primary" : "bg-accent"}`} />
      <div className="flex items-start justify-between">
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</div>
        {icon && <div className={accentClass}>{icon}</div>}
      </div>
      <motion.div className="mt-3 font-display text-2xl font-bold sm:text-3xl md:text-4xl break-words">{rounded}</motion.div>
    </motion.div>
  );
}