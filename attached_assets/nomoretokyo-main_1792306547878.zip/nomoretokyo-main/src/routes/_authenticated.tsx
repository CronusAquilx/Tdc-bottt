import { createFileRoute, Outlet, useNavigate, Link, useLocation } from "@tanstack/react-router";
import { useEffect } from "react";
import { LayoutDashboard, FilePlus2, ListOrdered, Settings as SettingsIcon, LogOut, Loader2, BarChart3, Users as UsersIcon, Megaphone } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { Logo } from "@/components/Logo";

export const Route = createFileRoute("/_authenticated")({
  component: AuthedLayout,
});

function AuthedLayout() {
  const { user, loading, role, displayName, signOut } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/login" });
  }, [loading, user, navigate]);

  if (loading || !user) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  const isStaff = role === "owner" || role === "manager";
  const nav = [
    { to: "/dashboard", label: "Dashboard", shortLabel: "Home", icon: LayoutDashboard },
    { to: "/orders/new", label: "New Order", shortLabel: "New", icon: FilePlus2 },
    { to: "/orders", label: "Orders", shortLabel: "Jobs", icon: ListOrdered },
    { to: "/jobs", label: "Job Ads", shortLabel: "Ads", icon: Megaphone },
    ...(isStaff ? [{ to: "/analytics", label: "Analytics", shortLabel: "Stats", icon: BarChart3 }] : []),
    ...(role === "owner" ? [{ to: "/users", label: "Crew", shortLabel: "Crew", icon: UsersIcon }] : []),
    { to: "/settings", label: "Settings", shortLabel: "More", icon: SettingsIcon },
  ];

  return (
    <div className="relative flex min-h-screen flex-col bg-grid md:flex-row">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,oklch(0.62_0.24_25/0.12),transparent_50%),radial-gradient(ellipse_at_bottom_right,oklch(0.72_0.18_230/0.1),transparent_60%)]" />

      {/* Sidebar */}
      <aside className="glass-strong sticky top-0 z-20 hidden h-screen w-64 flex-col border-r border-border/50 px-4 py-6 md:flex">
        <div className="px-2"><Logo to="/dashboard" /></div>
        <nav className="mt-10 flex flex-1 flex-col gap-1">
          {nav.map((n) => <NavItem key={n.to} {...n} />)}
        </nav>
        <div className="border-t border-border/50 pt-4">
          <div className="rounded-xl bg-card/40 p-3">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Signed in</div>
            <div className="mt-1 truncate font-semibold">{displayName ?? user.email}</div>
            <div className="mt-1 inline-flex items-center rounded-md bg-primary/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-primary">
              {role}
            </div>
            <button
              onClick={async () => { await signOut(); navigate({ to: "/" }); }}
              className="mt-3 flex w-full items-center gap-2 rounded-lg border border-border/50 px-3 py-2 text-sm text-muted-foreground transition hover:border-primary hover:text-primary"
            >
              <LogOut className="h-4 w-4" /> Sign out
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile top bar */}
      <div className="md:hidden glass-strong sticky top-0 z-20 flex w-full items-center justify-between border-b border-border/50 px-4 py-3">
        <Logo to="/dashboard" />
        <button onClick={async () => { await signOut(); navigate({ to: "/" }); }} className="rounded-lg p-2 text-muted-foreground">
          <LogOut className="h-4 w-4" />
        </button>
      </div>

      <main className="relative z-10 w-full flex-1 overflow-x-hidden md:w-auto">
        <div className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-10">
          <Outlet />
        </div>

        {/* Mobile bottom nav */}
        <nav className="glass-strong fixed bottom-0 left-0 right-0 z-20 flex border-t border-border/50 md:hidden pb-[env(safe-area-inset-bottom)]">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="flex flex-1 min-w-0 flex-col items-center gap-0.5 px-1 py-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground"
              activeProps={{ className: "text-primary" }}
            >
              <n.icon className="h-5 w-5 shrink-0" />
              <span className="truncate">{n.shortLabel}</span>
            </Link>
          ))}
        </nav>
        <div className="h-20 md:hidden" />
      </main>
    </div>
  );
}

function NavItem({ to, label, icon: Icon }: { to: string; label: string; icon: React.ComponentType<{ className?: string }> }) {
  const loc = useLocation();
  const active = loc.pathname === to || (to !== "/dashboard" && loc.pathname.startsWith(to));
  return (
    <Link
      to={to}
      className={`group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
        active
          ? "bg-primary/15 text-primary"
          : "text-muted-foreground hover:bg-card/40 hover:text-foreground"
      }`}
    >
      {active && <span className="absolute left-0 top-1/2 h-6 w-0.5 -translate-y-1/2 rounded-r bg-primary shadow-[0_0_12px_oklch(0.62_0.24_25/0.7)]" />}
      <Icon className="h-4 w-4" />
      {label}
    </Link>
  );
}