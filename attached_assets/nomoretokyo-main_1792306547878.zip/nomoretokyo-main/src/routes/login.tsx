import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Logo } from "@/components/Logo";

export const Route = createFileRoute("/login")({
  component: LoginPage,
});

function LoginPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && user) navigate({ to: "/dashboard" });
  }, [loading, user, navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const u = username.trim().toLowerCase();
      const email = u.includes("@") ? u : `${u}@tokyocustoms.gg`;
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      toast.success("ようこそ — Welcome back");
    } catch (err: any) {
      toast.error(err.message ?? "Invalid username or password");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-grid px-4">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,oklch(0.62_0.24_25/0.18),transparent_60%)]" />
      <div className="absolute top-6 left-6"><Logo /></div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="glass-strong relative w-full max-w-md rounded-3xl p-8 shadow-2xl"
      >
        <div className="mb-6 text-center">
          <div className="text-xs font-bold uppercase tracking-[0.3em] text-accent">東京 · Tokyo</div>
          <h1 className="font-display text-3xl font-bold mt-2">Drift Customs</h1>
          <p className="mt-1 text-sm text-muted-foreground">Sign in to the garage</p>
        </div>

        <form onSubmit={submit} className="space-y-4">
          <Field label="Username">
            <input
              type="text"
              value={username}
              required
              autoCapitalize="off"
              autoCorrect="off"
              onChange={(e) => setUsername(e.target.value)}
              className="input"
              placeholder="phoenix"
            />
          </Field>
          <Field label="Password">
            <input
              type="password"
              value={password}
              required
              minLength={6}
              onChange={(e) => setPassword(e.target.value)}
              className="input"
              placeholder="••••••••"
            />
          </Field>

          <button
            type="submit"
            disabled={busy}
            className="group relative w-full overflow-hidden rounded-xl bg-primary py-3 font-semibold text-primary-foreground shadow-[0_0_30px_oklch(0.62_0.24_25/0.4)] transition hover:scale-[1.01] disabled:opacity-60"
          >
            {busy ? (
              <span className="flex items-center justify-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin" />
                Working...
              </span>
            ) : "Sign In"}
          </button>
        </form>

        <div className="mt-6 text-center text-xs text-muted-foreground">
          Need an account? Ask the boss to create one for you.
        </div>

        <div className="mt-6 text-center">
          <Link to="/" className="text-xs text-muted-foreground hover:text-foreground">← Back home</Link>
        </div>
      </motion.div>

      <style>{`
        .input {
          width: 100%;
          background: oklch(0.18 0.012 250 / 0.6);
          border: 1px solid oklch(0.3 0.015 250 / 0.6);
          border-radius: 0.75rem;
          padding: 0.75rem 1rem;
          color: inherit;
          outline: none;
          transition: all .15s;
        }
        .input:focus {
          border-color: oklch(0.72 0.18 230);
          box-shadow: 0 0 0 3px oklch(0.72 0.18 230 / 0.2);
        }
      `}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}