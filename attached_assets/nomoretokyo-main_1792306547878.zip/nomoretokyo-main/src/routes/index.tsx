import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useEffect } from "react";
import { ArrowRight, Gauge, ShieldCheck, Wrench } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { Logo } from "@/components/Logo";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  useEffect(() => {
    if (!loading && user) navigate({ to: "/dashboard" });
  }, [loading, user, navigate]);

  return (
    <div className="relative min-h-screen overflow-hidden bg-grid">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top,oklch(0.62_0.24_25/0.25),transparent_60%)]" />
      <header className="relative z-10 flex items-center justify-between px-6 py-5 md:px-12">
        <Logo />
        <Link
          to="/login"
          className="rounded-lg border border-border bg-card/50 px-5 py-2 text-sm font-semibold text-foreground backdrop-blur transition hover:border-primary hover:text-primary"
        >
          Sign In
        </Link>
      </header>

      <main className="relative z-10 mx-auto flex max-w-6xl flex-col items-center px-6 pt-16 pb-24 text-center md:pt-28">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-6 inline-flex items-center gap-2 rounded-full border border-accent/40 bg-accent/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest text-accent"
        >
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-accent" />
          Tokyo Drift Customs · 東京カスタムズ
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="font-display text-5xl font-bold leading-[1.05] md:text-7xl"
        >
          Built for the <span className="gradient-text-red text-glow-red">crew</span>.
          <br />
          Tuned for <span className="gradient-text-blue text-glow-blue">profit</span>.
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.25 }}
          className="mt-6 max-w-2xl text-lg text-muted-foreground md:text-xl"
        >
          Create work orders, capture payment proof, and track every install across the shop —
          in a dashboard that looks as fast as the cars you build.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-10 flex flex-col gap-3 sm:flex-row"
        >
          <Link
            to="/login"
            className="group inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-7 py-3.5 font-semibold text-primary-foreground shadow-[0_0_40px_oklch(0.62_0.24_25/0.4)] transition hover:scale-[1.02]"
          >
            Enter the Shop
            <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
          </Link>
        </motion.div>

        <div className="mt-24 grid w-full gap-5 sm:grid-cols-3">
          {[
            { icon: Wrench, title: "Work Orders", desc: "Itemized installs with a live calculator." },
            { icon: ShieldCheck, title: "Proof of Payment", desc: "Upload, review, approve in seconds." },
            { icon: Gauge, title: "Real Analytics", desc: "Revenue, leaderboards, top services." },
          ].map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 + i * 0.1 }}
              className="glass rounded-2xl p-6 text-left"
            >
              <f.icon className="mb-4 h-6 w-6 text-primary" />
              <h3 className="font-display text-lg font-semibold">{f.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </main>
    </div>
  );
}
