import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { Printer, ArrowLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { formatMoney } from "@/lib/pricing";

export const Route = createFileRoute("/_authenticated/receipts/$id")({
  component: ReceiptPage,
});

function ReceiptPage() {
  const { id } = Route.useParams();
  const { data: order, isLoading } = useQuery({
    queryKey: ["receipt", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("orders").select("*").eq("id", id).maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  useEffect(() => {
    const style = document.createElement("style");
    style.innerHTML = `@media print { aside, nav, .no-print { display: none !important; } main { padding: 0 !important; } body { background: white !important; color: black !important; } .receipt-card { background: white !important; color: black !important; border: 1px solid #ccc !important; box-shadow: none !important; } }`;
    document.head.appendChild(style);
    return () => { document.head.removeChild(style); };
  }, []);

  if (isLoading) return <div className="py-16 text-center text-muted-foreground">Loading…</div>;
  if (!order) return <div className="py-16 text-center">Receipt not found</div>;

  const items = (order.items as any[]) ?? [];

  return (
    <div className="space-y-6">
      <div className="no-print flex flex-wrap items-center justify-between gap-3">
        <Link to="/orders/$id" params={{ id }} className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to order
        </Link>
        <button onClick={() => window.print()} className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 font-semibold text-primary-foreground shadow-[0_0_30px_oklch(0.62_0.24_25/0.4)]">
          <Printer className="h-4 w-4" /> Print / Save PDF
        </button>
      </div>

      <div className="receipt-card glass mx-auto max-w-3xl rounded-2xl p-8 md:p-12">
        <div className="flex items-start justify-between border-b border-border/60 pb-6">
          <div>
            <div className="font-display text-2xl font-bold tracking-wider gradient-text-red">TOKYO DRIFT CUSTOMS</div>
            <div className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">東京 · Drift · Tuning · Resprays</div>
          </div>
          <div className="text-right">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Receipt</div>
            <div className="font-mono text-lg font-bold text-accent">{order.order_number}</div>
            <div className="mt-1 text-xs text-muted-foreground">{new Date(order.created_at).toLocaleDateString()}</div>
          </div>
        </div>

        <div className="mt-6">
          <div className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Date</div>
          <div className="mt-1 font-display text-lg font-semibold">{new Date(order.created_at).toLocaleString()}</div>
        </div>

        <table className="mt-8 w-full text-sm">
          <thead>
            <tr className="border-b border-border/60 text-left text-xs uppercase tracking-wider text-muted-foreground">
              <th className="pb-2">Service</th>
              <th className="pb-2">Category</th>
              <th className="pb-2 text-right">Price</th>
            </tr>
          </thead>
          <tbody>
            {items.map((i, idx) => (
              <tr key={idx} className="border-b border-border/30">
                <td className="py-2.5 font-semibold">{i.label}</td>
                <td className="py-2.5 text-muted-foreground capitalize">{i.category}</td>
                <td className="py-2.5 text-right font-mono">{formatMoney(Number(i.price))}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="mt-6 ml-auto max-w-xs space-y-1.5 text-sm">
          <div className="flex justify-between border-t border-border/60 pt-2 text-xl font-bold">
            <span>Total Due</span>
            <span className="font-display gradient-text-red">{formatMoney(Number(order.total))}</span>
          </div>
          <div className="pt-3 text-right text-[10px] uppercase tracking-widest text-muted-foreground">
            Status · <span className="text-accent">{order.status}</span>
          </div>
        </div>

        <div className="mt-10 border-t border-border/60 pt-4 text-center text-xs text-muted-foreground">
          Thank you for choosing Tokyo Drift Customs. All services covered by 24h workmanship guarantee.
        </div>
      </div>
    </div>
  );
}