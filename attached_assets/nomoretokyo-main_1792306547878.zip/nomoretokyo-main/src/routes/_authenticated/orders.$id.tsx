import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, CheckCircle2, XCircle, Loader2, Receipt } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { StatusBadge } from "@/components/StatusBadge";
import { formatMoney } from "@/lib/pricing";
import { notifyOrderEvent } from "@/lib/discord.functions";
import { refreshMechanicWeekly } from "@/lib/payroll.functions";

export const Route = createFileRoute("/_authenticated/orders/$id")({
  component: OrderDetailPage,
});

function OrderDetailPage() {
  const { id } = Route.useParams();
  const { user, role } = useAuth();
  const isStaff = role === "owner" || role === "manager";
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [busy, setBusy] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState("");
  const [showReject, setShowReject] = useState(false);

  const { data: order, isLoading } = useQuery({
    queryKey: ["order", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("orders").select("*").eq("id", id).maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const { data: mechanic } = useQuery({
    queryKey: ["order-mechanic", order?.mechanic_id],
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("display_name, email, discord_id").eq("id", order!.mechanic_id).maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!order?.mechanic_id && isStaff,
  });

  async function update(patch: Partial<{ status: string; approved_by: string; approved_at: string; rejected_reason: string; rejected_at: string }>) {
    setBusy(JSON.stringify(patch));
    try {
      const { error } = await supabase.from("orders").update(patch as any).eq("id", id);
      if (error) throw error;
      await supabase.from("audit_logs").insert({
        user_id: user!.id, action: `order_${patch.status}`, entity_type: "order", entity_id: id,
        metadata: patch as any,
      });
      if (patch.status === "paid" || patch.status === "rejected") {
        notifyOrderEvent({ data: { orderId: id, event: patch.status as "paid" | "rejected" } }).catch(() => {});
        if (order?.mechanic_id) {
          refreshMechanicWeekly({ data: { mechanicId: order.mechanic_id } }).catch(() => {});
        }
      }
      toast.success("Order updated");
      qc.invalidateQueries({ queryKey: ["order", id] });
      qc.invalidateQueries({ queryKey: ["orders-list"] });
      qc.invalidateQueries({ queryKey: ["orders-dashboard"] });
    } catch (err: any) {
      toast.error(err.message ?? "Failed");
    } finally {
      setBusy(null);
      setShowReject(false);
      setRejectReason("");
    }
  }

  if (isLoading) return <div className="py-16 text-center text-muted-foreground"><Loader2 className="mx-auto h-6 w-6 animate-spin" /></div>;
  if (!order) return <div className="py-16 text-center"><h1 className="font-display text-2xl font-bold">Order not found</h1><Link to="/orders" className="mt-3 inline-block text-accent">← Back to orders</Link></div>;

  const items = (order.items as any[]) ?? [];

  return (
    <div className="space-y-6">
      <button onClick={() => navigate({ to: "/orders" })} className="inline-flex items-center gap-2 text-sm text-muted-foreground transition hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> All orders
      </button>

      <div className="flex flex-col gap-4 sm:flex-row sm:flex-wrap sm:items-start sm:justify-between">
        <div className="min-w-0">
          <div className="font-mono text-sm text-accent">{order.order_number}</div>
          <h1 className="mt-1 font-display text-2xl font-bold sm:text-3xl break-words">Work Order</h1>
          <div className="mt-1 text-sm text-muted-foreground sm:text-base">{new Date(order.created_at).toLocaleString()}</div>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <StatusBadge status={order.status} />
          <div className="font-display text-2xl font-bold gradient-text-red sm:text-3xl">{formatMoney(Number(order.total))}</div>
        </div>
      </div>

      {order.status === "paid" && (
        <Link
          to="/receipts/$id"
          params={{ id: order.id }}
          className="inline-flex items-center gap-2 rounded-xl border border-accent/40 bg-accent/10 px-4 py-2 text-sm font-semibold text-accent transition hover:bg-accent/20"
        >
          <Receipt className="h-4 w-4" /> View / Print Receipt
        </Link>
      )}

      <div className="grid gap-6 lg:grid-cols-3">
        <section className="glass rounded-2xl p-6 lg:col-span-2">
          <h2 className="font-display text-lg font-semibold">Itemized Invoice</h2>
          <div className="mt-4 divide-y divide-border/40">
            {items.length === 0 ? (
              <div className="py-8 text-center text-muted-foreground">No items.</div>
            ) : items.map((i, idx) => (
              <div key={idx} className="flex items-center justify-between py-3">
                <div>
                  <div className="font-semibold">{i.label}</div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{i.category}</div>
                </div>
                <div className="font-display font-semibold">{formatMoney(Number(i.price))}</div>
              </div>
            ))}
          </div>
          <div className="mt-4 space-y-1.5 border-t border-border/40 pt-4 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Customer Total</span><span className="font-display font-semibold">{formatMoney(Number(order.total))}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">− Parts Cost</span><span className="font-display font-semibold text-emerald-400">{formatMoney(Number((order as { parts_cost?: number }).parts_cost ?? 0))}</span></div>
            <div className="flex justify-between border-t border-border/40 pt-2 text-lg font-bold"><span>Labour</span><span className="font-display text-primary">{formatMoney(Math.max(0, Number(order.total) - Number((order as { parts_cost?: number }).parts_cost ?? 0)))}</span></div>
          </div>
          {order.notes && (
            <div className="mt-5 rounded-xl border border-border/40 bg-card/40 p-4">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Notes</div>
              <div className="mt-1 text-sm">{order.notes}</div>
            </div>
          )}
        </section>

        <aside className="space-y-4">
          {isStaff && order.status === "submitted" && (
            <div className="glass rounded-2xl p-5">
              <h3 className="font-display text-sm font-bold uppercase tracking-widest text-muted-foreground">Review</h3>
              <div className="mt-3 space-y-2">
                <button
                  disabled={!!busy}
                  onClick={() => update({ status: "paid", approved_by: user!.id, approved_at: new Date().toISOString() })}
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-500 py-3 font-semibold text-white shadow-[0_0_30px_oklch(0.7_0.18_150/0.4)] transition hover:scale-[1.01] disabled:opacity-60"
                >
                  <CheckCircle2 className="h-4 w-4" /> Mark Paid
                </button>
                <button
                  disabled={!!busy}
                  onClick={() => setShowReject(true)}
                  className="flex w-full items-center justify-center gap-2 rounded-xl border border-primary/50 bg-primary/10 py-2.5 font-semibold text-primary transition hover:bg-primary/20"
                >
                  <XCircle className="h-4 w-4" /> Reject
                </button>
              </div>
              {showReject && (
                <div className="mt-3 space-y-2">
                  <textarea value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} placeholder="Reason for rejection" className="w-full rounded-lg border border-border/60 bg-input/60 p-2 text-sm outline-none focus:border-primary" rows={3} />
                  <button
                    disabled={!rejectReason.trim() || !!busy}
                    onClick={() => update({ status: "rejected", rejected_reason: rejectReason, rejected_at: new Date().toISOString() })}
                    className="w-full rounded-lg bg-primary py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50"
                  >
                    Confirm Reject
                  </button>
                </div>
              )}
            </div>
          )}

          {order.status === "rejected" && order.rejected_reason && (
            <div className="glass rounded-2xl border border-primary/30 p-5">
              <h3 className="font-display text-sm font-bold uppercase tracking-widest text-primary">Rejection Reason</h3>
              <p className="mt-2 text-sm">{order.rejected_reason}</p>
            </div>
          )}

          <div className="glass rounded-2xl p-5 text-xs">
            <div className="space-y-1.5 text-muted-foreground">
              {isStaff && mechanic && (
                <div className="text-foreground">
                  Mechanic: <span className="font-semibold">{mechanic.display_name || mechanic.email}</span>
                  {mechanic.discord_id && <span className="ml-1 text-muted-foreground">({mechanic.discord_id})</span>}
                </div>
              )}
              {(order.customer_name || order.vehicle_name || order.plate) && (
                <div className="text-foreground">
                  {order.customer_name && <>Customer: <span className="font-semibold">{order.customer_name}</span></>}
                  {order.vehicle_name && <> · {order.vehicle_name}</>}
                  {order.plate && <> · {order.plate}</>}
                </div>
              )}
              <div>Created {new Date(order.created_at).toLocaleString()}</div>
              {order.approved_at && <div>Approved {new Date(order.approved_at).toLocaleString()}</div>}
              {order.rejected_at && <div>Rejected {new Date(order.rejected_at).toLocaleString()}</div>}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}