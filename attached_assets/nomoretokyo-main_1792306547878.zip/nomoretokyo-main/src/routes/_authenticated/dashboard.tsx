import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { CircleDollarSign, CheckCircle2, Clock, TrendingUp, FilePlus2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { StatCard } from "@/components/StatCard";
import { StatusBadge } from "@/components/StatusBadge";
import { formatMoney } from "@/lib/pricing";
import { WeeklyPayCard } from "@/components/WeeklyPayCard";
import { TutorialDialog } from "@/components/TutorialDialog";

export const Route = createFileRoute("/_authenticated/dashboard")({
  component: DashboardPage,
});

function DashboardPage() {
  const { user, role, displayName } = useAuth();
  const isStaff = role === "owner" || role === "manager";

  const { data, isLoading } = useQuery({
    queryKey: ["orders-dashboard", user?.id, isStaff],
    queryFn: async () => {
      let q = supabase.from("orders").select("*").order("created_at", { ascending: false });
      if (!isStaff && user) q = q.eq("mechanic_id", user.id);
      const { data, error } = await q;
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!user,
  });

  const orders = data ?? [];
  const paid = orders.filter((o) => o.status === "paid");
  const pending = orders.filter((o) => o.status === "submitted");
  const revenue = paid.reduce((s, o) => s + Number(o.total), 0);
  const avg = paid.length ? revenue / paid.length : 0;

  return (
    <div className="space-y-8">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex flex-col gap-4 md:flex-row md:flex-wrap md:items-end md:justify-between">
          <div className="min-w-0">
            <h1 className="font-display text-2xl font-bold sm:text-3xl md:text-4xl break-words">
              Welcome back,{" "}
              <span className="gradient-text-red">{displayName?.split(" ")[0] ?? "Tuner"}</span>
            </h1>
            <p className="mt-1 text-sm text-muted-foreground md:text-base">
              {isStaff ? "Shop overview across the crew." : "Your work, your numbers."}
            </p>
          </div>
          <div className="flex flex-col gap-2 md:flex-row md:items-center">
            <TutorialDialog role={isStaff ? "owner" : "mechanic"} />
            <Link to="/orders/new" className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3 font-semibold text-primary-foreground shadow-[0_0_30px_oklch(0.62_0.24_25/0.4)] transition hover:scale-[1.02] md:w-auto">
              <FilePlus2 className="h-4 w-4" /> New Order
            </Link>
          </div>
        </div>
      </motion.div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Revenue Generated" value={revenue} prefix="$" icon={<CircleDollarSign className="h-5 w-5" />} accent="red" delay={0.05} />
        <StatCard label="Completed Jobs" value={paid.length} icon={<CheckCircle2 className="h-5 w-5" />} accent="blue" delay={0.1} />
        <StatCard label="Pending Orders" value={pending.length} icon={<Clock className="h-5 w-5" />} accent="red" delay={0.15} />
        <StatCard label="Average Ticket" value={Math.round(avg)} prefix="$" icon={<TrendingUp className="h-5 w-5" />} accent="blue" delay={0.2} />
      </div>

      {!isStaff && <WeeklyPayCard />}

      <motion.section initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="glass rounded-2xl p-4 md:p-7">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-xl font-semibold">Recent Orders</h2>
          <Link to="/orders" className="text-sm font-semibold text-accent hover:underline">View all →</Link>
        </div>
        {isLoading ? (
          <div className="py-12 text-center text-muted-foreground">Loading…</div>
        ) : orders.length === 0 ? (
          <div className="py-12 text-center text-muted-foreground">No orders yet. Create your first one.</div>
        ) : (
          <>
          {/* Mobile cards */}
          <ul className="divide-y divide-border/40 md:hidden">
            {orders.slice(0, 8).map((o) => (
              <li key={o.id}>
                <Link to="/orders/$id" params={{ id: o.id }} className="flex items-center justify-between gap-3 py-3 active:opacity-80">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-semibold text-accent">{o.order_number}</span>
                      <StatusBadge status={o.status} />
                    </div>
                    <div className="mt-1 truncate text-xs text-muted-foreground">{new Date(o.created_at).toLocaleString()}</div>
                  </div>
                  <div className="shrink-0 font-display font-semibold">{formatMoney(Number(o.total))}</div>
                </Link>
              </li>
            ))}
          </ul>
          {/* Desktop table */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase tracking-wider text-muted-foreground">
                  <th className="pb-3 pr-4">Order</th><th className="pb-3 pr-4">Date</th><th className="pb-3 pr-4">Status</th><th className="pb-3 pr-4 text-right">Parts</th><th className="pb-3 pr-4 text-right">Total</th>
                </tr>
              </thead>
              <tbody>
                {orders.slice(0, 8).map((o) => (
                  <tr key={o.id} className="border-t border-border/40 transition hover:bg-card/30">
                    <td className="py-3 pr-4">
                      <Link to="/orders/$id" params={{ id: o.id }} className="font-mono font-semibold text-accent hover:underline">{o.order_number}</Link>
                    </td>
                    <td className="py-3 pr-4 text-muted-foreground">{new Date(o.created_at).toLocaleString()}</td>
                    <td className="py-3 pr-4"><StatusBadge status={o.status} /></td>
                    <td className="py-3 pr-4 text-right font-mono text-emerald-400">{formatMoney(Number((o as { parts_cost?: number }).parts_cost ?? 0))}</td>
                    <td className="py-3 pr-4 text-right font-display font-semibold">{formatMoney(Number(o.total))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          </>
        )}
      </motion.section>
    </div>
  );
}