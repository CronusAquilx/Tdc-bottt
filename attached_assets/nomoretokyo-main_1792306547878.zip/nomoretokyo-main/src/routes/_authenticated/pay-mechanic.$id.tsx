import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Loader2, CheckCircle2, XCircle, ArrowLeft } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { payMechanicWeek } from "@/lib/payroll.functions";
import { formatMoney } from "@/lib/pricing";

export const Route = createFileRoute("/_authenticated/pay-mechanic/$id")({
  component: PayMechanicPage,
});

function PayMechanicPage() {
  const { id } = Route.useParams();
  const { role } = useAuth();
  const [state, setState] = useState<"confirm" | "running" | "done" | "error">("confirm");
  const [result, setResult] = useState<{ paid: number; invoices: number; mechanicName: string } | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (role && role !== "owner") setState("error"), setErr("Only the boss can run payouts.");
  }, [role]);

  async function run() {
    setState("running");
    try {
      const r = await payMechanicWeek({ data: { mechanicId: id } });
      setResult({ paid: r.paid, invoices: r.invoices, mechanicName: r.mechanicName });
      setState("done");
    } catch (e: any) {
      setErr(e?.message ?? "Failed");
      setState("error");
    }
  }

  return (
    <div className="mx-auto max-w-lg space-y-6 py-10">
      <Link to="/dashboard" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Dashboard
      </Link>
      <div className="glass-strong rounded-2xl p-6">
        <h1 className="font-display text-2xl font-bold">Pay Mechanic — This Week</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          This will mark all this week's invoices as <b>paid</b>, post a confirmation to Discord, and reset their week.
        </p>

        {state === "confirm" && (
          <button onClick={run} className="mt-5 w-full rounded-xl bg-emerald-500 py-3 font-semibold text-white shadow-[0_0_30px_oklch(0.7_0.18_150/0.4)] transition hover:scale-[1.01]">
            Confirm & Pay
          </button>
        )}
        {state === "running" && (
          <div className="mt-5 flex items-center justify-center gap-2 text-muted-foreground"><Loader2 className="h-5 w-5 animate-spin" /> Processing…</div>
        )}
        {state === "done" && result && (
          <div className="mt-5 space-y-3 text-center">
            <CheckCircle2 className="mx-auto h-10 w-10 text-emerald-400" />
            <div className="font-display text-xl font-bold">{result.mechanicName} paid</div>
            <div className="text-3xl font-bold gradient-text-red">{formatMoney(result.paid)}</div>
            <div className="text-xs text-muted-foreground">{result.invoices} invoice{result.invoices !== 1 ? "s" : ""}</div>
          </div>
        )}
        {state === "error" && (
          <div className="mt-5 flex flex-col items-center gap-2 text-center">
            <XCircle className="h-8 w-8 text-primary" />
            <div className="text-sm text-muted-foreground">{err}</div>
          </div>
        )}
      </div>
    </div>
  );
}