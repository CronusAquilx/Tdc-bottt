import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { motion, AnimatePresence } from "framer-motion";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Loader2, ImageIcon, Copy, Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { CATEGORIES, formatMoney, computeTotals, type SelectedItem } from "@/lib/pricing";
import { notifyOrderEvent } from "@/lib/discord.functions";
import { refreshMyWeekly } from "@/lib/payroll.functions";

export const Route = createFileRoute("/_authenticated/orders/new")({
  component: NewOrderPage,
});

function NewOrderPage() {
  const { user } = useAuth();
  const profile = useAuth();
  const navigate = useNavigate();
  const [notes, setNotes] = useState("");
  const [selections, setSelections] = useState<Record<string, string[]>>({});
  const [busy, setBusy] = useState(false);
  const [labourInput, setLabourInput] = useState<string>("");
  const [labourTouched, setLabourTouched] = useState(false);
  const [copied, setCopied] = useState(false);

  const items = useMemo<SelectedItem[]>(() => {
    const out: SelectedItem[] = [];
    for (const cat of CATEGORIES) {
      const picked = selections[cat.id] ?? [];
      for (const id of picked) {
        const opt = cat.options.find((o) => o.id === id);
        if (opt) out.push({ id: opt.id, label: opt.label, price: opt.price, cost: opt.cost, category: cat.label });
      }
    }
    return out;
  }, [selections]);

  const { partsTotal, resprayCount, resprayCapped } = computeTotals(items);
  // Suggest a fair labour per item — Tokyo Drift rates (cheaper than old Storms
  // but high enough that a 30% cut is real money on the FiveM economy).
  // 75% of (price - cost), min $500, rounded to nearest $100.
  const suggestPerItem = (price: number, cost: number) =>
    Math.max(500, Math.round(((price - cost) * 0.75) / 100) * 100);
  const suggestedLabour = useMemo(
    () => items.reduce((s, i) => s + suggestPerItem(i.price, i.cost), 0),
    [items],
  );
  const labour = labourTouched
    ? Math.max(0, Number(labourInput) || 0)
    : suggestedLabour;
  // Customer is charged for parts + mechanic's labour
  const total = partsTotal + labour;
  const rate = 0.4; // visual only — actual commission is computed server-side from profile
  const commissionPreview = labour * rate;

  function toggle(catId: string, optId: string, multi: boolean) {
    setSelections((prev) => {
      const cur = prev[catId] ?? [];
      if (multi) {
        return { ...prev, [catId]: cur.includes(optId) ? cur.filter((x) => x !== optId) : [...cur, optId] };
      }
      return { ...prev, [catId]: cur[0] === optId ? [] : [optId] };
    });
  }

  function applyPreset(preset: "full" | "max") {
    if (preset === "full") {
      // Full Package: every respray/visual option, all lighting & extras,
      // a full repair, plus the top-tier performance upgrades.
      const next: Record<string, string[]> = {};
      for (const cat of CATEGORIES) {
        if (
          cat.id === "visual" ||
          cat.id === "lighting" ||
          cat.id === "extras" ||
          cat.id === "repair" ||
          cat.id === "turbo"
        ) {
          next[cat.id] = cat.options.map((o) => o.id);
        } else {
          // top tier for tiered performance categories
          const top = cat.options[cat.options.length - 1];
          if (top) next[cat.id] = [top.id];
        }
      }
      setSelections(next);
      setLabourTouched(false);
      toast.success("Full Package loaded");
      return;
    }
    // Max Performance: only the performance upgrades (top tier) + turbo + repair
    const next: Record<string, string[]> = {};
    for (const cat of CATEGORIES) {
      if (cat.id === "repair" || cat.id === "turbo") {
        next[cat.id] = cat.options.map((o) => o.id);
      } else if (["brakes", "engine", "suspension", "transmission"].includes(cat.id)) {
        const top = cat.options[cat.options.length - 1];
        if (top) next[cat.id] = [top.id];
      }
    }
    setSelections(next);
    setLabourTouched(false);
    toast.success("Max Performance loaded");
  }

  const copyText = useMemo(() => {
    const lines = [
      `Tokyo Drift Customs — Invoice`,
      `--------------------------------`,
      ...items.map((i) => `• ${i.label} — ${formatMoney(i.cost)}`),
      `--------------------------------`,
      `Parts Cost:     ${formatMoney(partsTotal)}`,
      `Labour:         ${formatMoney(labour)}`,
      `Customer Total: ${formatMoney(total)}`,
    ];
    return lines.join("\n");
  }, [items, total, partsTotal, labour]);

  async function copySummary() {
    try {
      await navigator.clipboard.writeText(copyText);
      setCopied(true);
      toast.success("Copied to clipboard");
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error("Copy failed");
    }
  }

  async function submit(asDraft: boolean) {
    if (!user) return;
    if (items.length === 0) { toast.error("Add at least one service"); return; }

    setBusy(true);
    try {
      const { data, error } = await supabase.from("orders").insert({
        mechanic_id: user.id,
        notes: notes || null,
        items: items as any,
        subtotal: total, tax: 0, total,
        parts_cost: partsTotal,
        labour,
        status: asDraft ? "draft" : "submitted",
      }).select().single();
      if (error) throw error;

      toast.success(asDraft ? "Draft saved" : `Order ${data.order_number} submitted`);
      if (!asDraft) {
        try {
          const res = await notifyOrderEvent({ data: { orderId: data.id, event: "submitted" } });
          if (!res.sent && res.reason === "no_webhook_configured") {
            toast.warning("Order submitted, but no Discord webhook is set in Settings.");
          } else if (!res.sent) {
            toast.warning(`Discord notification failed: ${res.reason ?? "unknown"}`);
          }
        } catch (e: any) {
          toast.warning(`Discord notification failed: ${e?.message ?? "unknown"}`);
        }
        refreshMyWeekly().catch(() => {});
      }
      navigate({ to: "/orders/$id", params: { id: data.id } });
    } catch (err: any) {
      toast.error(err.message ?? "Failed to save");
    } finally {
      setBusy(false);
    }
  }
  void profile;

  return (
    <div className="space-y-6 pb-10">
      <div>
        <h1 className="font-display text-2xl font-bold sm:text-3xl">New Work Order</h1>
        <p className="mt-1 text-sm text-muted-foreground sm:text-base">Pick the work, set your labour, submit.</p>
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => applyPreset("full")}
          className="rounded-xl border border-primary/50 bg-primary/15 px-4 py-2 text-xs font-bold uppercase tracking-wider text-primary transition hover:bg-primary/25"
        >
          ⚡ Full Package
        </button>
        <button
          type="button"
          onClick={() => applyPreset("max")}
          className="rounded-xl border border-accent/50 bg-accent/15 px-4 py-2 text-xs font-bold uppercase tracking-wider text-accent transition hover:bg-accent/25"
        >
          🏁 Max Performance
        </button>
        <button
          type="button"
          onClick={() => { setSelections({}); setLabourTouched(false); }}
          className="rounded-xl border border-border/60 bg-card/40 px-4 py-2 text-xs font-bold uppercase tracking-wider text-muted-foreground transition hover:text-foreground"
        >
          Clear
        </button>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          {/* Services */}
          <section className="glass rounded-2xl p-5 md:p-6">
            <SectionTitle index="01" title="Services & Upgrades" />
            <div className="mt-5 space-y-5">
              {CATEGORIES.map((cat) => {
                const picked = selections[cat.id] ?? [];
                const multi = cat.id === "lighting" || cat.id === "extras" || cat.id === "visual" || cat.id === "repair";
                return (
                  <div key={cat.id}>
                    <div className="mb-2 flex items-center gap-3">
                      <h3 className="font-display text-sm font-bold uppercase tracking-widest text-muted-foreground">{cat.label}</h3>
                      <div className="h-px flex-1 bg-border/40" />
                      {cat.isRespray && picked.length > 4 && (
                        <span className="rounded-md bg-emerald-500/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-emerald-400">Capped $60k</span>
                      )}
                    </div>
                    <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                      {cat.options.map((opt) => {
                        const active = picked.includes(opt.id);
                        return (
                          <button
                            key={opt.id}
                            type="button"
                            onClick={() => toggle(cat.id, opt.id, multi)}
                            className={`group relative overflow-hidden rounded-xl border px-4 py-3 text-left transition ${
                              active
                                ? "border-primary bg-primary/15 shadow-[0_0_20px_oklch(0.62_0.24_25/0.3)]"
                                : "border-border/50 bg-card/30 hover:border-accent/50"
                            }`}
                          >
                            <div className="flex items-center justify-between gap-2">
                              <span className="text-sm font-semibold">{opt.label}</span>
                              <span className={`font-display text-sm font-bold ${active ? "text-primary" : "text-accent"}`}>{formatMoney(opt.cost)}</span>
                            </div>
                            <div className="mt-0.5 flex items-center justify-between text-[10px] font-semibold uppercase tracking-wider">
                              <span className="text-emerald-500/80">Parts {formatMoney(opt.cost)}</span>
                              <span className="text-accent/80">Fair labour ~{formatMoney(suggestPerItem(opt.price, opt.cost))}</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-5">
              <Field label="Notes (optional)">
                <input className="input" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Anything the boss should know" />
              </Field>
            </div>
          </section>

        </div>

        {/* Sticky calculator */}
        <aside className="lg:sticky lg:top-6 h-fit">
          <div className="glass-strong rounded-2xl p-4 md:p-6">
            <div className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Live Invoice</div>
            <div className="mt-2 flex items-baseline gap-2">
              <motion.div key={total} initial={{ scale: 0.95, opacity: 0.6 }} animate={{ scale: 1, opacity: 1 }} className="gradient-text-red font-display text-3xl font-bold sm:text-4xl break-all">
                {formatMoney(total)}
              </motion.div>
            </div>
            <div className="mt-1 text-sm text-muted-foreground">
              {items.length} item{items.length !== 1 ? "s" : ""} · {resprayCount} respray{resprayCount !== 1 ? "s" : ""}
              {resprayCapped && <span className="ml-1 text-emerald-400">· capped</span>}
            </div>

            <div className="mt-5 max-h-72 space-y-1.5 overflow-y-auto pr-1">
              <AnimatePresence initial={false}>
                {items.length === 0 ? (
                  <div className="rounded-xl border border-dashed border-border/40 py-8 text-center text-xs text-muted-foreground">
                    <ImageIcon className="mx-auto mb-2 h-5 w-5 opacity-50" />
                    Pick services to start
                  </div>
                ) : items.map((i) => (
                  <motion.div
                    key={`${i.category}-${i.id}`}
                    initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}
                    className="flex items-center justify-between rounded-lg bg-card/40 px-3 py-2 text-sm"
                  >
                    <div>
                      <div className="font-semibold">{i.label}</div>
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{i.category}</div>
                    </div>
                    <div className="font-display font-semibold">{formatMoney(i.cost)}</div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            <div className="mt-5 space-y-2 border-t border-border/40 pt-4 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Parts Cost</span><span className="font-display font-semibold text-emerald-400">{formatMoney(partsTotal)}</span></div>
              <div className="border-t border-border/40 pt-3">
                <div className="mb-1.5 flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Labour (you decide)</span>
                  <button
                    type="button"
                    onClick={() => { setLabourInput(String(suggestedLabour)); setLabourTouched(true); }}
                    className="text-[10px] font-bold uppercase tracking-wider text-accent hover:underline"
                  >
                    Use ~{formatMoney(suggestedLabour)}
                  </button>
                </div>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">$</span>
                  <input
                    type="number"
                    min={0}
                    value={labourTouched ? labourInput : String(suggestedLabour)}
                    onChange={(e) => { setLabourTouched(true); setLabourInput(e.target.value); }}
                    placeholder="0"
                    className="input pl-6 font-display text-base font-semibold"
                  />
                </div>
                <div className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">Suggested fair labour: {formatMoney(suggestedLabour)}</div>
              </div>
              <div className="flex justify-between border-t border-border/40 pt-3 text-base font-bold"><span>Customer Total</span><span className="font-display">{formatMoney(total)}</span></div>
              <div className="flex justify-between text-base font-bold"><span>Your Commission</span><span className="font-display text-primary">~{formatMoney(commissionPreview)}</span></div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Commission shown at default 40%. Actual % set by your boss.</div>
            </div>

            {/* Quick copy summary */}
            <div className="mt-4 rounded-xl border border-border/50 bg-card/30 p-3">
              <div className="mb-2 flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Quick Copy</span>
                <button
                  type="button"
                  onClick={copySummary}
                  className="flex items-center gap-1.5 rounded-md bg-accent/15 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-accent transition hover:bg-accent/25"
                >
                  {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                  {copied ? "Copied" : "Copy"}
                </button>
              </div>
              <pre className="max-h-40 overflow-y-auto whitespace-pre-wrap break-words rounded-md bg-black/40 p-2 font-mono text-[10px] leading-relaxed text-foreground/90">{copyText}</pre>
            </div>

            <div className="mt-5 space-y-2">
              <button disabled={busy} onClick={() => submit(false)} className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 font-semibold text-primary-foreground shadow-[0_0_30px_oklch(0.62_0.24_25/0.4)] transition hover:scale-[1.01] disabled:opacity-60">
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Submit Order"}
              </button>
              <button disabled={busy} onClick={() => submit(true)} className="w-full rounded-xl border border-border/60 bg-card/40 py-2.5 text-sm font-semibold text-muted-foreground transition hover:text-foreground">
                Save as Draft
              </button>
            </div>
          </div>
        </aside>
      </div>

      <style>{`
        .input { width:100%; background: oklch(0.18 0.012 250 / 0.6); border:1px solid oklch(0.3 0.015 250 / 0.6); border-radius:.75rem; padding:.6rem .9rem; color:inherit; outline:none; transition:all .15s; }
        .input:focus { border-color: oklch(0.72 0.18 230); box-shadow: 0 0 0 3px oklch(0.72 0.18 230 / 0.2); }
      `}</style>
    </div>
  );
}

function SectionTitle({ index, title }: { index: string; title: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="rounded-md bg-primary/15 px-2 py-0.5 font-display text-xs font-bold text-primary">{index}</div>
      <h2 className="font-display text-lg font-semibold">{title}</h2>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}