import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Search, FilePlus2, CheckCircle2, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { StatusBadge } from "@/components/StatusBadge";
import { formatMoney } from "@/lib/pricing";
import { notifyOrderEvent } from "@/lib/discord.functions";
import { refreshMechanicWeekly } from "@/lib/payroll.functions";
import { MechanicsBreakdown } from "@/components/MechanicsBreakdown";

export const Route = createFileRoute("/_authenticated/orders/")({
  component: OrdersPage,
});

function OrdersPage() {
  const { user, role } = useAuth();
  const isStaff = role === "owner" || role === "manager";
  const qc = useQueryClient();
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [payingId, setPayingId] = useState<string | null>(null);

  async function quickPay(orderId: string, mechanicId: string | null) {
    if (!user) return;
    setPayingId(orderId);
    try {
      const { error } = await supabase.from("orders").update({
        status: "paid", approved_by: user.id, approved_at: new Date().toISOString(),
      } as any).eq("id", orderId);
      if (error) throw error;
      notifyOrderEvent({ data: { orderId, event: "paid" } }).catch(() => {});
      if (mechanicId) refreshMechanicWeekly({ data: { mechanicId } }).catch(() => {});
      toast.success("Order marked paid");
      qc.invalidateQueries({ queryKey: ["orders-list"] });
      qc.invalidateQueries({ queryKey: ["orders-dashboard"] });
    } catch (e: any) {
      toast.error(e?.message ?? "Failed");
    } finally {
      setPayingId(null);
    }
  }

  const { data, isLoading } = useQuery({
    queryKey: ["orders-list", user?.id, isStaff],
    queryFn: async () => {
      let q = supabase.from("orders").select("*").order("created_at", { ascending: false });
      if (!isStaff && user) q = q.eq("mechanic_id", user.id);
      const { data, error } = await q;
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!user,
  });

  const mechanicIds = Array.from(new Set((data ?? []).map((o) => o.mechanic_id).filter(Boolean))) as string[];
  const { data: mechMap } = useQuery({
    queryKey: ["orders-mechanics", mechanicIds.sort().join(",")],
    queryFn: async () => {
      if (mechanicIds.length === 0) return {} as Record<string, string>;
      const { data, error } = await supabase.from("profiles").select("id, display_name, email").in("id", mechanicIds);
      if (error) throw error;
      const map: Record<string, string> = {};
      (data ?? []).forEach((p: any) => { map[p.id] = p.display_name || p.email || "Unknown"; });
      return map;
    },
    enabled: mechanicIds.length > 0,
  });

  const filtered = (data ?? []).filter((o) => {
    if (statusFilter !== "all" && o.status !== statusFilter) return false;
    if (!query.trim()) return true;
    const q = query.toLowerCase();
    return [o.order_number, o.notes]
      .filter(Boolean).some((s) => String(s).toLowerCase().includes(q));
  });

  const statuses = ["all", "draft", "submitted", "paid", "rejected", "archived"];

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:flex-wrap md:items-end md:justify-between">
        <div className="min-w-0">
          <h1 className="font-display text-2xl font-bold sm:text-3xl">Work Orders</h1>
          <p className="mt-1 text-sm text-muted-foreground sm:text-base">{isStaff ? "All orders across the shop." : "Your work orders."}</p>
        </div>
        <Link to="/orders/new" className="inline-flex w-full md:w-auto items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3 font-semibold text-primary-foreground shadow-[0_0_30px_oklch(0.62_0.24_25/0.4)] transition hover:scale-[1.02]">
          <FilePlus2 className="h-4 w-4" /> New Order
        </Link>
      </div>

      <div className="glass rounded-2xl p-4 md:p-5">
        <div className="flex flex-col gap-3 md:flex-row md:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search by order number or notes…" className="w-full rounded-xl border border-border/60 bg-input/60 py-2.5 pl-10 pr-3 outline-none transition focus:border-accent focus:shadow-[0_0_0_3px_oklch(0.72_0.18_230/0.2)]" />
          </div>
          <div className="flex flex-wrap gap-2">
            {statuses.map((s) => (
              <button key={s} onClick={() => setStatusFilter(s)} className={`rounded-lg px-3 py-1.5 text-xs font-bold uppercase tracking-wider transition ${statusFilter === s ? "bg-primary text-primary-foreground" : "bg-card/40 text-muted-foreground hover:text-foreground"}`}>{s}</button>
            ))}
          </div>
        </div>
      </div>

      {isStaff && <MechanicsBreakdown orders={(data ?? []) as any} />}

      <div className="glass overflow-hidden rounded-2xl">
        {isLoading ? (
          <div className="py-16 text-center text-muted-foreground">Loading…</div>
        ) : filtered.length === 0 ? (
          <div className="py-16 text-center text-muted-foreground">No orders match.</div>
        ) : (
          <>
          {/* Mobile cards */}
          <ul className="divide-y divide-border/40 md:hidden">
            {filtered.map((o) => (
              <li key={o.id}>
                <div className="flex items-center justify-between gap-3 p-4">
                  <Link to="/orders/$id" params={{ id: o.id }} className="min-w-0 flex-1 active:opacity-70">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-semibold text-accent">{o.order_number}</span>
                      <StatusBadge status={o.status} />
                    </div>
                    <div className="mt-1 truncate text-xs text-muted-foreground">
                      {new Date(o.created_at).toLocaleString()}
                      {isStaff && o.mechanic_id && <> · by <span className="text-foreground">{mechMap?.[o.mechanic_id] ?? "…"}</span></>}
                    </div>
                  </Link>
                  <div className="flex shrink-0 items-center gap-2">
                    <div className="font-display font-semibold">{formatMoney(Number(o.total))}</div>
                    {isStaff && o.status === "submitted" && (
                      <button
                        disabled={payingId === o.id}
                        onClick={() => quickPay(o.id, o.mechanic_id)}
                        className="rounded-lg bg-emerald-500 p-2 text-white disabled:opacity-50"
                        aria-label="Mark paid"
                      >
                        {payingId === o.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
                      </button>
                    )}
                    </div>
                </div>
              </li>
            ))}
          </ul>
          {/* Desktop table */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-card/40 text-left text-xs uppercase tracking-wider text-muted-foreground">
                  <th className="px-5 py-3">Order</th><th className="px-5 py-3">Date</th>{isStaff && <th className="px-5 py-3">Mechanic</th>}<th className="px-5 py-3">Status</th><th className="px-5 py-3 text-right">Parts</th><th className="px-5 py-3 text-right">Total</th>{isStaff && <th className="px-5 py-3 text-right">Action</th>}
                </tr>
              </thead>
              <tbody>
                {filtered.map((o) => (
                  <tr key={o.id} className="border-t border-border/40 transition hover:bg-card/30">
                    <td className="px-5 py-3"><Link to="/orders/$id" params={{ id: o.id }} className="font-mono font-semibold text-accent hover:underline">{o.order_number}</Link></td>
                    <td className="px-5 py-3 text-muted-foreground">{new Date(o.created_at).toLocaleString()}</td>
                    {isStaff && <td className="px-5 py-3">{o.mechanic_id ? (mechMap?.[o.mechanic_id] ?? "…") : "—"}</td>}
                    <td className="px-5 py-3"><StatusBadge status={o.status} /></td>
                    <td className="px-5 py-3 text-right font-mono text-emerald-400">{formatMoney(Number((o as { parts_cost?: number }).parts_cost ?? 0))}</td>
                    <td className="px-5 py-3 text-right font-display font-semibold">{formatMoney(Number(o.total))}</td>
                    {isStaff && (
                      <td className="px-5 py-3 text-right">
                        {o.status === "submitted" ? (
                          <button
                            disabled={payingId === o.id}
                            onClick={() => quickPay(o.id, o.mechanic_id)}
                            className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-500 px-3 py-1.5 text-xs font-bold text-white disabled:opacity-50"
                          >
                            {payingId === o.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
                            Pay
                          </button>
                        ) : <span className="text-xs text-muted-foreground">—</span>}
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          </>
        )}
      </div>
    </div>
  );
}