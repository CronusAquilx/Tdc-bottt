import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Webhook, Save, Loader2, RotateCcw, AlertTriangle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { setPayoutDay, runPayout } from "@/lib/payroll.functions";
import { factoryReset } from "@/lib/system.functions";
import { useServerFn } from "@tanstack/react-start";

export const Route = createFileRoute("/_authenticated/settings")({
  component: SettingsPage,
});

function SettingsPage() {
  const { user, role, displayName } = useAuth();
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold">Settings</h1>
        <p className="mt-1 text-muted-foreground">Your profile and preferences.</p>
      </div>
      <div className="glass rounded-2xl p-6">
        <h2 className="font-display text-lg font-semibold">Profile</h2>
        <dl className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
          <Row label="Email" value={user?.email ?? "—"} />
          <Row label="Display Name" value={displayName ?? "—"} />
          <Row label="Role" value={role ?? "—"} />
          <Row label="User ID" value={<span className="font-mono text-xs">{user?.id}</span>} />
        </dl>
      </div>
      {role === "owner" && <DiscordWebhookCard />}
      {role === "owner" && <PayrollWebhookCard />}
      {role === "owner" && <PayrollCard />}
      {role === "owner" && <FactoryResetCard />}
    </div>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-border/40 bg-card/30 p-4">
      <dt className="text-xs uppercase tracking-wider text-muted-foreground">{label}</dt>
      <dd className="mt-1 font-semibold">{value}</dd>
    </div>
  );
}

function FactoryResetCard() {
  const qc = useQueryClient();
  const reset = useServerFn(factoryReset);
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);

  async function doReset() {
    if (confirm !== "RESET") {
      toast.error('Type RESET to confirm');
      return;
    }
    setBusy(true);
    try {
      await reset({});
      toast.success("System reset — all orders, invoices, and weekly hours cleared");
      setConfirm("");
      qc.invalidateQueries();
    } catch (e: any) {
      toast.error(e?.message ?? "Reset failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="glass rounded-2xl border border-destructive/40 p-6">
      <div className="flex items-center gap-2">
        <AlertTriangle className="h-5 w-5 text-destructive" />
        <h2 className="font-display text-lg font-semibold text-destructive">Factory Reset</h2>
      </div>
      <p className="mt-2 text-sm text-muted-foreground">
        Wipes <strong>all orders, invoices, audit logs, payment proofs</strong> and resets every mechanic's
        weekly hours to zero. User accounts stay intact. This cannot be undone.
      </p>
      <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <input
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
          placeholder='Type "RESET" to confirm'
          className="flex-1 rounded-md border border-border/60 bg-input/60 px-3 py-2 font-mono text-sm"
        />
        <button
          onClick={doReset}
          disabled={busy || confirm !== "RESET"}
          className="inline-flex items-center justify-center gap-2 rounded-md bg-destructive px-4 py-2 text-sm font-bold text-destructive-foreground transition disabled:opacity-40"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <RotateCcw className="h-4 w-4" />}
          Reset Whole System
        </button>
      </div>
    </div>
  );
}

function DiscordWebhookCard() {
  const qc = useQueryClient();
  const [url, setUrl] = useState("");
  const [busy, setBusy] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ["app_settings", "discord_webhook_url"],
    queryFn: async () => {
      const { data, error } = await supabase.from("app_settings").select("value").eq("key", "discord_webhook_url").maybeSingle();
      if (error) throw error;
      return (data?.value as { url?: string } | null)?.url ?? "";
    },
  });

  useEffect(() => { if (typeof data === "string") setUrl(data); }, [data]);

  async function save() {
    setBusy(true);
    const { error } = await supabase.from("app_settings").upsert({ key: "discord_webhook_url", value: { url: url.trim() } });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Webhook saved");
    qc.invalidateQueries({ queryKey: ["app_settings", "discord_webhook_url"] });
  }

  return (
    <div className="glass rounded-2xl p-6">
      <div className="flex items-center gap-2">
        <Webhook className="h-5 w-5 text-accent" />
        <h2 className="font-display text-lg font-semibold">Discord Notifications · Fallback</h2>
      </div>
      <p className="mt-1 text-sm text-muted-foreground">
        Fallback webhook used when a mechanic has no personal channel set, and when no dedicated payroll channel is configured. Per-mechanic webhooks live in <strong>Crew &amp; Roles</strong>.
      </p>
      <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:flex-wrap">
        <input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://discord.com/api/webhooks/..."
          className="w-full sm:flex-1 sm:min-w-[260px] rounded-lg border border-border/60 bg-input/60 px-3 py-2 text-sm font-mono outline-none focus:border-accent"
        />
        <button
          onClick={save}
          disabled={busy || isLoading}
          className="inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-accent-foreground disabled:opacity-50"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Save
        </button>
      </div>
    </div>
  );
}

function PayrollWebhookCard() {
  const qc = useQueryClient();
  const [url, setUrl] = useState("");
  const [busy, setBusy] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ["app_settings", "payroll_webhook_url"],
    queryFn: async () => {
      const { data, error } = await supabase.from("app_settings").select("value").eq("key", "payroll_webhook_url").maybeSingle();
      if (error) throw error;
      return (data?.value as { url?: string } | null)?.url ?? "";
    },
  });

  useEffect(() => { if (typeof data === "string") setUrl(data); }, [data]);

  async function save() {
    setBusy(true);
    const { error } = await supabase.from("app_settings").upsert({ key: "payroll_webhook_url", value: { url: url.trim() } });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Payroll webhook saved");
    qc.invalidateQueries({ queryKey: ["app_settings", "payroll_webhook_url"] });
  }

  return (
    <div className="glass rounded-2xl p-6">
      <div className="flex items-center gap-2">
        <Webhook className="h-5 w-5 text-emerald-400" />
        <h2 className="font-display text-lg font-semibold">Weekly Payroll Channel</h2>
      </div>
      <p className="mt-1 text-sm text-muted-foreground">
        Dedicated channel where every mechanic's weekly pay embed lives and the final payout summary posts.
      </p>
      <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:flex-wrap">
        <input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://discord.com/api/webhooks/..."
          className="w-full sm:flex-1 sm:min-w-[260px] rounded-lg border border-border/60 bg-input/60 px-3 py-2 text-sm font-mono outline-none focus:border-accent"
        />
        <button
          onClick={save}
          disabled={busy || isLoading}
          className="inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg bg-emerald-500 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Save
        </button>
      </div>
    </div>
  );
}

function PayrollCard() {
  const qc = useQueryClient();
  const [day, setDay] = useState(5);
  const [busy, setBusy] = useState(false);
  const [paying, setPaying] = useState(false);

  const { data } = useQuery({
    queryKey: ["app_settings", "payroll_config"],
    queryFn: async () => {
      const { data } = await supabase.from("app_settings").select("value").eq("key", "payroll_config").maybeSingle();
      return (data?.value as { payout_day?: number; last_payout_at?: string | null } | null) ?? {};
    },
  });

  useEffect(() => {
    if (typeof data?.payout_day === "number") setDay(data.payout_day);
  }, [data?.payout_day]);

  async function saveDay() {
    setBusy(true);
    try {
      await setPayoutDay({ data: { payoutDay: day } });
      toast.success("Payout day saved");
      qc.invalidateQueries({ queryKey: ["app_settings", "payroll_config"] });
    } catch (e: any) { toast.error(e?.message ?? "Failed"); }
    finally { setBusy(false); }
  }

  async function doPayout() {
    if (!confirm("Run payout now? This will post a final summary to Discord and reset the week for every mechanic.")) return;
    setPaying(true);
    try {
      const res = await runPayout();
      toast.success(`Payout complete · $${res.totalPaid.toLocaleString(undefined,{maximumFractionDigits:2})} paid`);
      qc.invalidateQueries({ queryKey: ["app_settings", "payroll_config"] });
      qc.invalidateQueries({ queryKey: ["my-weekly"] });
    } catch (e: any) { toast.error(e?.message ?? "Failed"); }
    finally { setPaying(false); }
  }

  const dayNames = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  const last = data?.last_payout_at ? new Date(data.last_payout_at).toLocaleString() : "Never";

  return (
    <div className="glass rounded-2xl p-6">
      <h2 className="font-display text-lg font-semibold">Weekly Payroll</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Pick the payout day. Each mechanic gets a live Discord embed with their invoices, hours, and expected pay. Hit "Run Payout" to post a final summary and reset the week.
      </p>
      <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-end">
        <label className="w-full sm:w-auto sm:min-w-[200px]">
          <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">Payout Day</span>
          <select value={day} onChange={(e) => setDay(Number(e.target.value))}
            className="w-full rounded-lg border border-border/60 bg-input/60 px-3 py-2 text-sm outline-none focus:border-accent">
            {dayNames.map((n,i) => <option key={i} value={i}>{n}</option>)}
          </select>
        </label>
        <button onClick={saveDay} disabled={busy}
          className="inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-accent-foreground disabled:opacity-50">
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save
        </button>
        <button onClick={doPayout} disabled={paying}
          className="inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-lg bg-emerald-500 px-4 py-2 text-sm font-semibold text-white shadow-[0_0_30px_oklch(0.7_0.18_150/0.4)] disabled:opacity-50">
          {paying ? <Loader2 className="h-4 w-4 animate-spin" /> : "💵 Run Payout Now"}
        </button>
      </div>
      <p className="mt-3 text-xs text-muted-foreground">Last payout: <span className="font-mono">{last}</span></p>
    </div>
  );
}