import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Shield, ShieldCheck, Wrench, UserPlus, Copy } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, type AppRole } from "@/lib/auth-context";
import { setCommissionRate } from "@/lib/payroll.functions";
import { seedCrew, getCrewCredentials, createCrewMember } from "@/lib/system.functions";
import { useState } from "react";

export const Route = createFileRoute("/_authenticated/users")({
  component: UsersPage,
});

function UsersPage() {
  const { role, user: me } = useAuth();
  if (role && role !== "owner") return <Navigate to="/dashboard" />;
  const qc = useQueryClient();
  const [seeding, setSeeding] = useState(false);
  const [newName, setNewName] = useState("");
  const [newUser, setNewUser] = useState("");
  const [newDiscord, setNewDiscord] = useState("");
  const [newRole, setNewRole] = useState<"mechanic" | "owner">("mechanic");
  const [creating, setCreating] = useState(false);

  const { data: creds = [] } = useQuery({
    queryKey: ["crew-credentials"],
    queryFn: () => getCrewCredentials(),
  });

  async function doSeed() {
    setSeeding(true);
    try {
      const res = await seedCrew();
      toast.success(`Crew synced — ${res.created} new, ${res.count - res.created} updated`);
      qc.invalidateQueries({ queryKey: ["users-mgmt"] });
      qc.invalidateQueries({ queryKey: ["crew-credentials"] });
    } catch (e: any) {
      toast.error(e?.message ?? "Seed failed");
    } finally {
      setSeeding(false);
    }
  }

  async function doCreate() {
    if (!newName.trim() || !newUser.trim()) {
      toast.error("Name and username required");
      return;
    }
    setCreating(true);
    try {
      const res = await createCrewMember({
        data: {
          displayName: newName,
          username: newUser,
          discordId: newDiscord,
          role: newRole,
        },
      });
      toast.success(`Account created — user: ${res.username} · pass: ${res.password}`);
      setNewName(""); setNewUser(""); setNewDiscord(""); setNewRole("mechanic");
      qc.invalidateQueries({ queryKey: ["users-mgmt"] });
      qc.invalidateQueries({ queryKey: ["crew-credentials"] });
    } catch (e: any) {
      toast.error(e?.message ?? "Create failed");
    } finally {
      setCreating(false);
    }
  }

  async function copyAll() {
    const lines = [
      "Tokyo Drift Customs — Crew Credentials",
      "=======================================",
      ...creds.map((c) => `${c.role.toUpperCase().padEnd(8)} ${c.displayName.padEnd(18)} user: ${c.username.padEnd(16)} pass: ${c.password.padEnd(14)} discord: ${c.discordId}`),
    ];
    await navigator.clipboard.writeText(lines.join("\n"));
    toast.success("Credentials copied");
  }

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["users-mgmt"],
    queryFn: async () => {
      const [{ data: profiles }, { data: roles }] = await Promise.all([
        supabase.from("profiles").select("*").order("display_name"),
        supabase.from("user_roles").select("*"),
      ]);
      return (profiles ?? []).map((p) => ({
        ...p,
        role: (roles ?? []).find((r) => r.user_id === p.id)?.role ?? "mechanic",
      }));
    },
  });

  async function setRole(userId: string, newRole: AppRole) {
    const { error: delErr } = await supabase.from("user_roles").delete().eq("user_id", userId);
    if (delErr) { toast.error(delErr.message); return; }
    const { error } = await supabase.from("user_roles").insert({ user_id: userId, role: newRole });
    if (error) { toast.error(error.message); return; }
    toast.success("Role updated");
    qc.invalidateQueries({ queryKey: ["users-mgmt"] });
  }

  async function saveRate(userId: string, ratePct: number) {
    try {
      await setCommissionRate({ data: { userId, rate: ratePct / 100 } });
      toast.success("Commission updated");
      qc.invalidateQueries({ queryKey: ["users-mgmt"] });
    } catch (e: any) { toast.error(e?.message ?? "Failed"); }
  }

  async function saveWebhook(userId: string, url: string) {
    const { error } = await supabase.from("profiles").update({ discord_webhook_url: url.trim() || null }).eq("id", userId);
    if (error) { toast.error(error.message); return; }
    toast.success("Webhook saved");
    qc.invalidateQueries({ queryKey: ["users-mgmt"] });
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold md:text-4xl"><span className="gradient-text-red">Crew & Roles</span></h1>
        <p className="mt-1 text-muted-foreground">Manage who can do what across the shop.</p>
      </div>

      <div className="glass-strong rounded-2xl p-4 md:p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="font-display text-lg font-bold">Crew Credentials Sheet</div>
            <div className="text-xs text-muted-foreground">Bosses use <span className="font-mono text-accent">boss123</span> · Mechanics use <span className="font-mono text-accent">TokyoDrift123</span></div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={copyAll}
              disabled={creds.length === 0}
              className="inline-flex items-center gap-1.5 rounded-lg border border-accent/40 bg-accent/10 px-3 py-2 text-xs font-bold uppercase tracking-wider text-accent transition hover:bg-accent/20 disabled:opacity-40"
            >
              <Copy className="h-3.5 w-3.5" /> Copy All
            </button>
            <button
              onClick={doSeed}
              disabled={seeding}
              className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-2 text-xs font-bold uppercase tracking-wider text-primary-foreground shadow-[0_0_20px_oklch(0.62_0.24_25/0.4)] disabled:opacity-50"
            >
              <UserPlus className="h-3.5 w-3.5" /> {seeding ? "Syncing…" : "Sync / Create Crew"}
            </button>
          </div>
      </div>

      <div className="glass-strong rounded-2xl p-4 md:p-6">
        <div className="mb-3 flex items-center gap-2">
          <UserPlus className="h-4 w-4 text-primary" />
          <div className="font-display text-sm font-bold uppercase tracking-widest">Create New Account</div>
        </div>
        <div className="grid gap-3 md:grid-cols-4">
          <input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Display name (e.g. Jeff Jeffery)"
            className="rounded-lg border border-border/60 bg-input/60 px-3 py-2 text-sm"
          />
          <input
            value={newUser}
            onChange={(e) => setNewUser(e.target.value)}
            placeholder="username (e.g. jeffjeffery)"
            className="rounded-lg border border-border/60 bg-input/60 px-3 py-2 text-sm font-mono"
          />
          <input
            value={newDiscord}
            onChange={(e) => setNewDiscord(e.target.value)}
            placeholder="Discord ID (optional)"
            className="rounded-lg border border-border/60 bg-input/60 px-3 py-2 text-sm font-mono"
          />
          <div className="flex gap-2">
            <select
              value={newRole}
              onChange={(e) => setNewRole(e.target.value as any)}
              className="flex-1 rounded-lg border border-border/60 bg-input/60 px-3 py-2 text-sm"
            >
              <option value="mechanic">Mechanic</option>
              <option value="owner">Owner</option>
            </select>
            <button
              onClick={doCreate}
              disabled={creating}
              className="rounded-lg bg-primary px-4 py-2 text-xs font-bold uppercase tracking-wider text-primary-foreground shadow-[0_0_20px_oklch(0.62_0.24_25/0.4)] disabled:opacity-50"
            >
              {creating ? "…" : "Create"}
            </button>
          </div>
        </div>
        <p className="mt-2 text-[11px] text-muted-foreground">
          Mechanics get password <span className="font-mono text-accent">TokyoDrift123</span>, owners get <span className="font-mono text-accent">boss123</span>. Email becomes <span className="font-mono">username@tokyocustoms.gg</span>.
        </p>
        </div>
        {creds.length > 0 && (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="text-[10px] uppercase tracking-wider text-muted-foreground">
                <tr className="border-b border-border/40">
                  <th className="py-2 pr-3">Role</th>
                  <th className="py-2 pr-3">Name</th>
                  <th className="py-2 pr-3">Username</th>
                  <th className="py-2 pr-3">Password</th>
                  <th className="py-2">Discord ID</th>
                </tr>
              </thead>
              <tbody className="font-mono">
                {creds.map((c) => (
                  <tr key={c.username} className="border-b border-border/20">
                    <td className="py-1.5 pr-3">
                      <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold uppercase ${c.role === "owner" ? "bg-primary/20 text-primary" : "bg-accent/15 text-accent"}`}>{c.role}</span>
                    </td>
                    <td className="py-1.5 pr-3 font-sans">{c.displayName}</td>
                    <td className="py-1.5 pr-3">{c.username}</td>
                    <td className="py-1.5 pr-3 text-accent">{c.password}</td>
                    <td className="py-1.5">{c.discordId}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="glass rounded-2xl p-4 md:p-7">
        {isLoading ? (
          <div className="py-12 text-center text-muted-foreground">Loading…</div>
        ) : (
          <div className="space-y-2">
            {rows.map((u) => (
              <div key={u.id} className="rounded-xl border border-border/40 bg-card/30 p-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/15 font-display font-bold text-primary">
                    {(u.display_name ?? u.email ?? "?").charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <div className="font-semibold">{u.display_name ?? "Unnamed"} {u.id === me?.id && <span className="ml-1 text-xs text-accent">(you)</span>}</div>
                    <div className="text-xs text-muted-foreground">{u.email}</div>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-3">
                  <CommissionInput
                    initial={Math.round(Number((u as any).commission_rate ?? 0.4) * 100)}
                    onSave={(pct) => saveRate(u.id, pct)}
                  />
                  <div className="flex gap-1.5">
                  {(["owner", "manager", "mechanic"] as AppRole[]).map((r) => {
                    const Icon = r === "owner" ? ShieldCheck : r === "manager" ? Shield : Wrench;
                    const active = u.role === r;
                    return (
                      <button
                        key={r}
                        onClick={() => !active && setRole(u.id, r)}
                        disabled={active || u.id === me?.id}
                        className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-bold uppercase tracking-wider transition disabled:cursor-not-allowed ${
                          active
                            ? "border-primary bg-primary/20 text-primary"
                            : "border-border/60 text-muted-foreground hover:border-accent hover:text-accent"
                        }`}
                      >
                        <Icon className="h-3 w-3" /> {r}
                      </button>
                    );
                  })}
                  </div>
                </div>
                </div>
                <div className="mt-3">
                  <WebhookInput
                    initial={(u as any).discord_webhook_url ?? ""}
                    onSave={(v) => saveWebhook(u.id, v)}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function CommissionInput({ initial, onSave }: { initial: number; onSave: (pct: number) => void }) {
  const [val, setVal] = useState(String(initial));
  return (
    <div className="flex items-center gap-1.5">
      <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Commission</span>
      <input
        type="number" min={0} max={100} value={val}
        onChange={(e) => setVal(e.target.value)}
        onBlur={() => { const n = Number(val); if (!Number.isNaN(n) && n !== initial) onSave(n); }}
        className="w-16 rounded-md border border-border/60 bg-input/60 px-2 py-1 text-center text-xs"
      />
      <span className="text-xs text-muted-foreground">%</span>
    </div>
  );
}

function WebhookInput({ initial, onSave }: { initial: string; onSave: (url: string) => void }) {
  const [val, setVal] = useState(initial);
  const [dirty, setDirty] = useState(false);
  return (
    <div className="flex flex-wrap items-center gap-2">
      <span className="text-[10px] uppercase tracking-wider text-muted-foreground shrink-0">Discord Channel Webhook</span>
      <input
        value={val}
        onChange={(e) => { setVal(e.target.value); setDirty(e.target.value !== initial); }}
        placeholder="https://discord.com/api/webhooks/..."
        className="w-full sm:min-w-[260px] sm:w-auto flex-1 rounded-md border border-border/60 bg-input/60 px-2 py-1 font-mono text-xs"
      />
      <button
        onClick={() => { if (dirty) { onSave(val); setDirty(false); } }}
        disabled={!dirty}
        className="rounded-md bg-accent px-3 py-1 text-xs font-bold text-accent-foreground disabled:opacity-40"
      >Save</button>
    </div>
  );
}