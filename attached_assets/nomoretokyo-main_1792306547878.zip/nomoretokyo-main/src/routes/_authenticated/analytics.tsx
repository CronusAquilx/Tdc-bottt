import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, BarChart, Bar, CartesianGrid, PieChart, Pie, Cell, Legend } from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { StatCard } from "@/components/StatCard";
import { formatMoney } from "@/lib/pricing";
import { DollarSign, Wrench, TrendingUp, Activity } from "lucide-react";

export const Route = createFileRoute("/_authenticated/analytics")({
  ssr: false,
  component: AnalyticsPage,
});

const COLORS = ["oklch(0.62 0.24 25)", "oklch(0.72 0.18 230)", "#f59e0b", "#10b981", "#a855f7", "#ec4899", "#06b6d4", "#f43f5e"];

function AnalyticsPage() {
  const { role } = useAuth();
  if (role && role !== "owner" && role !== "manager") {
    return <Navigate to="/dashboard" />;
  }

  const { data: orders = [], isLoading } = useQuery({
    queryKey: ["analytics-orders"],
    queryFn: async () => {
      const { data, error } = await supabase.from("orders").select("*").order("created_at");
      if (error) throw error;
      return data ?? [];
    },
  });

  const paid = orders.filter((o) => o.status === "paid");
  const revenue = paid.reduce((s, o) => s + Number(o.total), 0);
  const partsCost = paid.reduce((s, o) => s + Number((o as { parts_cost?: number }).parts_cost ?? 0), 0);
  const labourTotal = Math.max(0, revenue - partsCost);

  // Revenue by day (last 30 days)
  const byDay = new Map<string, number>();
  for (let i = 29; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i);
    byDay.set(d.toISOString().slice(0, 10), 0);
  }
  paid.forEach((o) => {
    const k = String(o.created_at).slice(0, 10);
    if (byDay.has(k)) byDay.set(k, (byDay.get(k) ?? 0) + Number(o.total));
  });
  const revenueSeries = [...byDay.entries()].map(([date, revenue]) => ({
    date: date.slice(5),
    revenue,
  }));

  // Top mechanics
  const byMech = new Map<string, { count: number; revenue: number }>();
  paid.forEach((o) => {
    const cur = byMech.get(o.mechanic_id) ?? { count: 0, revenue: 0 };
    cur.count += 1; cur.revenue += Number(o.total);
    byMech.set(o.mechanic_id, cur);
  });

  // Service category breakdown
  const byCat = new Map<string, number>();
  paid.forEach((o) => {
    const items = (o.items as any[]) ?? [];
    items.forEach((it) => {
      byCat.set(it.category, (byCat.get(it.category) ?? 0) + Number(it.price));
    });
  });
  const catData = [...byCat.entries()].map(([name, value]) => ({ name, value }));

  return (
    <div className="space-y-8">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="font-display text-2xl font-bold sm:text-3xl md:text-4xl">
          <span className="gradient-text-blue">Analytics</span>
        </h1>
        <p className="mt-1 text-sm text-muted-foreground sm:text-base">Performance and revenue insights across the shop.</p>
      </motion.div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Total Revenue" value={revenue} prefix="$" icon={<DollarSign className="h-5 w-5" />} accent="red" delay={0.05} />
        <StatCard label="Jobs Paid" value={paid.length} icon={<Wrench className="h-5 w-5" />} accent="blue" delay={0.1} />
        <StatCard label="Labour Profit" value={labourTotal} prefix="$" icon={<TrendingUp className="h-5 w-5" />} accent="red" delay={0.15} />
        <StatCard label="Active Mechanics" value={byMech.size} icon={<Activity className="h-5 w-5" />} accent="blue" delay={0.2} />
      </div>

      <section className="glass rounded-2xl p-5 md:p-7">
        <h2 className="font-display text-lg font-semibold">Revenue · Last 30 Days</h2>
        {isLoading ? (
          <div className="h-72 animate-pulse rounded-xl bg-card/30" />
        ) : (
          <div className="mt-4 h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revenueSeries}>
                <defs>
                  <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.62 0.24 25)" stopOpacity={0.6} />
                    <stop offset="100%" stopColor="oklch(0.62 0.24 25)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="oklch(1 0 0 / 0.06)" strokeDasharray="3 3" />
                <XAxis dataKey="date" stroke="oklch(0.66 0.02 250)" fontSize={11} />
                <YAxis stroke="oklch(0.66 0.02 250)" fontSize={11} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
                <Tooltip
                  contentStyle={{ background: "oklch(0.17 0.012 250)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12 }}
                  formatter={(v: number) => formatMoney(v)}
                />
                <Area type="monotone" dataKey="revenue" stroke="oklch(0.62 0.24 25)" strokeWidth={2} fill="url(#rev)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </section>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="glass rounded-2xl p-5 md:p-7">
          <h2 className="font-display text-lg font-semibold">Revenue by Service Category</h2>
          <div className="mt-4 h-72">
            {catData.length === 0 ? (
              <div className="flex h-full items-center justify-center text-sm text-muted-foreground">No data yet</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={catData} dataKey="value" nameKey="name" innerRadius={50} outerRadius={100} paddingAngle={2}>
                    {catData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: "oklch(0.17 0.012 250)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12 }} formatter={(v: number) => formatMoney(v)} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </section>

        <section className="glass rounded-2xl p-5 md:p-7">
          <h2 className="font-display text-lg font-semibold">Top Mechanics</h2>
          <div className="mt-4 h-72">
            {byMech.size === 0 ? (
              <div className="flex h-full items-center justify-center text-sm text-muted-foreground">No data yet</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={[...byMech.entries()].map(([id, v]) => ({ id: id.slice(0, 6), ...v }))}>
                  <CartesianGrid stroke="oklch(1 0 0 / 0.06)" strokeDasharray="3 3" />
                  <XAxis dataKey="id" stroke="oklch(0.66 0.02 250)" fontSize={11} />
                  <YAxis stroke="oklch(0.66 0.02 250)" fontSize={11} />
                  <Tooltip contentStyle={{ background: "oklch(0.17 0.012 250)", border: "1px solid oklch(1 0 0 / 0.1)", borderRadius: 12 }} formatter={(v: number) => formatMoney(v)} />
                  <Bar dataKey="revenue" fill="oklch(0.72 0.18 230)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}