import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Megaphone, Pin, PinOff, Trash2, Copy, Plus, Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";

export const Route = createFileRoute("/_authenticated/jobs")({
  component: JobsPage,
});

const DEFAULT_AD = `Tokyo Drift Customs — Open

Pull up and get your car built right 🔧🔥

Full max performance upgrades starting at 120K 💸

Custom builds • Clean upgrades • Street-ready setups 🏁

We can work with your budget 💯

📍 Postal: 7228`;

type Ad = {
  id: string;
  title: string;
  body: string;
  posted_by: string;
  pinned: boolean;
  created_at: string;
};

function JobsPage() {
  const { role, user } = useAuth();
  const qc = useQueryClient();
  const isOwner = role === "owner";

  const [title, setTitle] = useState("Tokyo Drift Customs — Open");
  const [body, setBody] = useState(DEFAULT_AD);
  const [busy, setBusy] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const { data: ads = [], isLoading } = useQuery({
    queryKey: ["job-ads"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("job_ads")
        .select("*")
        .order("pinned", { ascending: false })
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as Ad[];
    },
  });

  async function postAd() {
    if (!user) return;
    if (!title.trim() || !body.trim()) {
      toast.error("Title and body required");
      return;
    }
    setBusy(true);
    const { error } = await supabase.from("job_ads").insert({
      title: title.trim(),
      body: body.trim(),
      posted_by: user.id,
      pinned: false,
    });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Ad posted");
    setTitle("Tokyo Drift Customs — Open");
    setBody(DEFAULT_AD);
    qc.invalidateQueries({ queryKey: ["job-ads"] });
  }

  async function togglePin(ad: Ad) {
    const { error } = await supabase
      .from("job_ads")
      .update({ pinned: !ad.pinned })
      .eq("id", ad.id);
    if (error) toast.error(error.message);
    else qc.invalidateQueries({ queryKey: ["job-ads"] });
  }

  async function deleteAd(id: string) {
    if (!confirm("Delete this ad?")) return;
    const { error } = await supabase.from("job_ads").delete().eq("id", id);
    if (error) toast.error(error.message);
    else {
      toast.success("Deleted");
      qc.invalidateQueries({ queryKey: ["job-ads"] });
    }
  }

  async function copyAd(ad: Ad) {
    try {
      await navigator.clipboard.writeText(ad.body);
      setCopiedId(ad.id);
      toast.success("Copied — paste in Discord");
      setTimeout(() => setCopiedId(null), 1500);
    } catch {
      toast.error("Copy failed");
    }
  }

  return (
    <div className="space-y-6 pb-10">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold md:text-4xl">
            <span className="gradient-text-red">Job Ads</span>
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Shop ads ready to copy + paste into Discord. Emojis included.
          </p>
        </div>
        <div className="hidden h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary sm:flex">
          <Megaphone className="h-6 w-6" />
        </div>
      </div>

      {isOwner && (
        <section className="glass-strong rounded-2xl p-4 md:p-6">
          <div className="mb-3 flex items-center gap-2">
            <Plus className="h-4 w-4 text-primary" />
            <h2 className="font-display text-sm font-bold uppercase tracking-widest">Post a new ad</h2>
          </div>
          <div className="space-y-3">
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Title"
              className="w-full rounded-xl border border-border/60 bg-input/60 px-3 py-2 text-sm font-semibold"
            />
            <textarea
              value={body}
              onChange={(e) => setBody(e.target.value)}
              rows={9}
              placeholder="Ad body — paste your message with emojis"
              className="w-full rounded-xl border border-border/60 bg-input/60 px-3 py-2 font-mono text-xs leading-relaxed"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => { setTitle("Tokyo Drift Customs — Open"); setBody(DEFAULT_AD); }}
                className="rounded-xl border border-border/60 bg-card/40 px-4 py-2 text-xs font-bold uppercase tracking-wider text-muted-foreground transition hover:text-foreground"
              >
                Reset
              </button>
              <button
                onClick={postAd}
                disabled={busy}
                className="rounded-xl bg-primary px-5 py-2 text-xs font-bold uppercase tracking-wider text-primary-foreground shadow-[0_0_20px_oklch(0.62_0.24_25/0.4)] disabled:opacity-50"
              >
                {busy ? "Posting…" : "Post Ad"}
              </button>
            </div>
          </div>
        </section>
      )}

      <section className="space-y-3">
        {isLoading ? (
          <div className="glass rounded-2xl p-8 text-center text-sm text-muted-foreground">Loading…</div>
        ) : ads.length === 0 ? (
          <div className="glass rounded-2xl p-8 text-center text-sm text-muted-foreground">
            No ads posted yet{isOwner ? " — drop the first one above." : "."}
          </div>
        ) : (
          ads.map((ad) => (
            <article
              key={ad.id}
              className={`glass rounded-2xl p-4 md:p-6 transition ${
                ad.pinned ? "ring-1 ring-accent/40" : ""
              }`}
            >
              <header className="mb-3 flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    {ad.pinned && (
                      <span className="inline-flex items-center gap-1 rounded-md bg-accent/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-accent">
                        <Pin className="h-2.5 w-2.5" /> Pinned
                      </span>
                    )}
                    <h3 className="font-display text-lg font-bold">{ad.title}</h3>
                  </div>
                  <div className="mt-0.5 text-[10px] uppercase tracking-wider text-muted-foreground">
                    {new Date(ad.created_at).toLocaleString()}
                  </div>
                </div>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => copyAd(ad)}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-accent/40 bg-accent/10 px-3 py-1.5 text-xs font-bold uppercase tracking-wider text-accent transition hover:bg-accent/20"
                  >
                    {copiedId === ad.id ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                    {copiedId === ad.id ? "Copied" : "Copy"}
                  </button>
                  {isOwner && (
                    <>
                      <button
                        onClick={() => togglePin(ad)}
                        title={ad.pinned ? "Unpin" : "Pin"}
                        className="rounded-lg border border-border/60 bg-card/40 px-2.5 py-1.5 text-muted-foreground transition hover:text-foreground"
                      >
                        {ad.pinned ? <PinOff className="h-3.5 w-3.5" /> : <Pin className="h-3.5 w-3.5" />}
                      </button>
                      <button
                        onClick={() => deleteAd(ad.id)}
                        title="Delete"
                        className="rounded-lg border border-destructive/40 bg-destructive/10 px-2.5 py-1.5 text-destructive transition hover:bg-destructive/20"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </>
                  )}
                </div>
              </header>
              <pre className="whitespace-pre-wrap break-words rounded-xl bg-black/40 p-4 font-mono text-xs leading-relaxed text-foreground/90">
                {ad.body}
              </pre>
            </article>
          ))
        )}
      </section>
    </div>
  );
}