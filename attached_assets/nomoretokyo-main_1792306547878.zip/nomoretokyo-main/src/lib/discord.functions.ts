import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const notifyOrderEvent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      orderId: z.string().uuid(),
      event: z.enum(["paid", "rejected", "submitted"]),
    }).parse(input),
  )
  .handler(async ({ data }) => {
    const { data: settings } = await supabaseAdmin
      .from("app_settings")
      .select("value")
      .eq("key", "discord_webhook_url")
      .maybeSingle();
    const fallbackUrl = (settings?.value as { url?: string } | null)?.url ?? null;

    const { data: order } = await supabaseAdmin
      .from("orders")
      .select("*")
      .eq("id", data.orderId)
      .maybeSingle();
    if (!order) return { sent: false, reason: "order_not_found" };

    // Look up mechanic display name + personal webhook
    let mechanicName = "Unknown";
    let mechanicWebhook: string | null = null;
    let mechanicDiscordId: string | null = null;
    let commissionRate = 0.4;
    if (order.mechanic_id) {
      const { data: prof } = await supabaseAdmin
        .from("profiles")
        .select("display_name, email, discord_webhook_url, discord_id, commission_rate")
        .eq("id", order.mechanic_id)
        .maybeSingle();
      mechanicName = prof?.display_name || prof?.email || "Unknown";
      mechanicWebhook = (prof as { discord_webhook_url?: string | null } | null)?.discord_webhook_url ?? null;
      mechanicDiscordId = (prof as { discord_id?: string | null } | null)?.discord_id ?? null;
      const r = (prof as { commission_rate?: number | null } | null)?.commission_rate;
      if (typeof r === "number") commissionRate = r;
    }

    const url = mechanicWebhook || fallbackUrl;
    if (!url) return { sent: false, reason: "no_webhook_configured" };

    const colorMap = { paid: 0x10b981, rejected: 0xef4444, submitted: 0x3b82f6 };
    const titleMap = {
      paid: `✅ Order Paid · ${order.order_number}`,
      rejected: `❌ Order Rejected · ${order.order_number}`,
      submitted: `📋 Order Submitted · ${order.order_number}`,
    };

    // Build itemized work list
    const items = Array.isArray(order.items) ? (order.items as Array<{ label: string; price: number; cost?: number; category?: string }>) : [];
    const workList = items.length
      ? items.map((i) => `• **${i.label}** — $${Number(i.price).toLocaleString()}`).join("\n").slice(0, 1024)
      : "_No items_";

    const customerTotal = Number(order.total);
    const partsCost = Number((order as { parts_cost?: number }).parts_cost ?? 0);
    const labour = Math.max(0, customerTotal - partsCost);
    const commission = labour * commissionRate;
    const resprayCount = items.filter((i) => i.category === "Visual & Body").length;

    // Signed URL for the payment proof image (valid 7 days)
    let proofUrl: string | null = null;
    if (order.payment_proof_url) {
      const { data: signed } = await supabaseAdmin
        .storage
        .from("payment-proofs")
        .createSignedUrl(order.payment_proof_url, 60 * 60 * 24 * 7);
      proofUrl = signed?.signedUrl ?? null;
    }

    const appBase = process.env.PUBLIC_APP_URL || "https://stormtuners.lovable.app";
    const orderUrl = `${appBase}/orders/${order.id}`;

    const body = {
      username: "Tokyo Drift Customs",
      ...(data.event === "paid" && mechanicDiscordId
        ? { content: `<@${mechanicDiscordId}> you've been paid! 💸` }
        : {}),
      ...(data.event === "paid" && mechanicDiscordId
        ? { allowed_mentions: { users: [mechanicDiscordId] } }
        : {}),
      embeds: [{
        title: titleMap[data.event],
        color: colorMap[data.event],
        fields: [
          { name: "Mechanic", value: mechanicName, inline: true },
          { name: "Resprays", value: String(resprayCount), inline: true },
          { name: "\u200b", value: "\u200b", inline: true },
          { name: "Customer Total", value: `$${customerTotal.toLocaleString()}`, inline: true },
          { name: "Parts Cost", value: `$${partsCost.toLocaleString()}`, inline: true },
          { name: "Labour", value: `$${labour.toLocaleString()}`, inline: true },
          { name: `Commission (${(commissionRate * 100).toFixed(0)}%)`, value: `**$${commission.toLocaleString(undefined, { maximumFractionDigits: 2 })}**`, inline: false },
          { name: "Work Done", value: workList, inline: false },
          ...(order.notes ? [{ name: "Notes", value: String(order.notes).slice(0, 1024), inline: false }] : []),
          ...(order.rejected_reason && data.event === "rejected"
            ? [{ name: "Rejection Reason", value: String(order.rejected_reason).slice(0, 1024), inline: false }]
            : []),
        ],
        ...(proofUrl ? { image: { url: proofUrl } } : {}),
        timestamp: new Date().toISOString(),
      }],
      components: [{
        type: 1,
        components: [{
          type: 2,
          style: 5,
          label: data.event === "submitted" ? "💸 Review / Pay Order" : "🔎 View Order",
          url: orderUrl,
        }],
      }],
    };

    try {
      // For "paid" we post a fresh message so the mechanic actually gets pinged
      // (editing an existing message never triggers a notification).
      const shouldEdit = order.discord_message_id && data.event !== "paid";
      if (shouldEdit) {
        const editRes = await fetch(`${url}/messages/${order.discord_message_id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        if (editRes.ok) return { sent: true, edited: true };
        // Fallback: original message gone — send a new one below.
      }

      const postRes = await fetch(`${url}?wait=true`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (postRes.ok) {
        const msg = await postRes.json().catch(() => null) as { id?: string } | null;
        if (msg?.id) {
          await supabaseAdmin.from("orders").update({ discord_message_id: msg.id }).eq("id", order.id);
        }
        return { sent: true, edited: false };
      }
      return { sent: false, reason: "discord_error" };
    } catch (e) {
      console.error("Discord webhook failed", e);
      return { sent: false, reason: "network_error" };
    }
  });