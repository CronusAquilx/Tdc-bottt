import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const factoryReset = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { userId } = context;
    const { data: roles } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", userId);
    const isOwner = (roles ?? []).some((r) => r.role === "owner");
    if (!isOwner) throw new Error("Only owners can reset the system");

    await supabaseAdmin.from("orders").delete().neq("id", "00000000-0000-0000-0000-000000000000");
    await supabaseAdmin.from("audit_logs").delete().neq("id", "00000000-0000-0000-0000-000000000000");
    await supabaseAdmin
      .from("profiles")
      .update({ weekly_hours: 0, weekly_discord_message_id: null })
      .neq("id", "00000000-0000-0000-0000-000000000000");

    // Clear payment-proof storage
    const { data: files } = await supabaseAdmin.storage.from("payment-proofs").list("", { limit: 1000 });
    if (files && files.length > 0) {
      const paths = files.map((f) => f.name);
      await supabaseAdmin.storage.from("payment-proofs").remove(paths);
    }

    return { ok: true };
  });

type CrewMember = {
  username: string;
  password: string;
  displayName: string;
  discordId: string;
  role: "owner" | "mechanic";
};

const CREW: CrewMember[] = [
  // Bosses
  { username: "phoenix",       password: "boss123",       displayName: "Phoenix",        discordId: "378293480608497664",  role: "owner" },
  { username: "lu",            password: "boss123",       displayName: "Lu Chenzo",      discordId: "198572092504014848",  role: "owner" },
  { username: "ander",         password: "boss123",       displayName: "Ander Dingus",   discordId: "1363222342800511058", role: "owner" },
  { username: "sierraphoenix", password: "boss123",       displayName: "Sierra Phoenix", discordId: "632044470711484424",  role: "owner" },
  // Mechanics
  { username: "myx",            password: "TokyoDrift123", displayName: "Myx",             discordId: "1179942814906327050", role: "mechanic" },
  { username: "yancy",          password: "TokyoDrift123", displayName: "Yancy",           discordId: "1088337283180146758", role: "mechanic" },
  { username: "unclecracker",   password: "TokyoDrift123", displayName: "Uncle Cracker",   discordId: "623677968786653194",  role: "mechanic" },
  { username: "smoke",          password: "TokyoDrift123", displayName: "Smoke",           discordId: "1445564490463711413", role: "mechanic" },
  { username: "magnus",         password: "TokyoDrift123", displayName: "Magnus",          discordId: "1069621699378679828", role: "mechanic" },
  { username: "louielue",       password: "TokyoDrift123", displayName: "LouieLue",        discordId: "733808236293128314",  role: "mechanic" },
  { username: "dayytradezz",    password: "TokyoDrift123", displayName: "Dayytradezz",     discordId: "727706928536616963",  role: "mechanic" },
  { username: "ahmedbrown",     password: "TokyoDrift123", displayName: "Ahmed Brown",     discordId: "1455587333071175755", role: "mechanic" },
  { username: "onlythegamers",  password: "TokyoDrift123", displayName: "OnlyTheGamers",   discordId: "748420441881706534",  role: "mechanic" },
  { username: "dreico",         password: "TokyoDrift123", displayName: "Dreico",          discordId: "1302529753739427961", role: "mechanic" },
  { username: "ron",            password: "TokyoDrift123", displayName: "Ron",             discordId: "466238601672392734",  role: "mechanic" },
  { username: "mrwalkdown",     password: "TokyoDrift123", displayName: "Mr Walkdown",     discordId: "1246285610319347754", role: "mechanic" },
  { username: "motionmontona",  password: "TokyoDrift123", displayName: "Motion Montona",  discordId: "424950499398254604",  role: "mechanic" },
  { username: "brandonstrong",  password: "TokyoDrift123", displayName: "Brandon Strong",  discordId: "312410738977144832",  role: "mechanic" },
  { username: "ab",             password: "TokyoDrift123", displayName: "Ab",              discordId: "696524714146922496",  role: "mechanic" },
];

export const seedCrew = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { userId } = context;
    const { data: roles } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", userId);
    if (!(roles ?? []).some((r) => r.role === "owner")) {
      throw new Error("Only owners can seed the crew");
    }

    // Build a map of email -> existing user id
    const emailToId = new Map<string, string>();
    let page = 1;
    while (true) {
      const { data, error } = await supabaseAdmin.auth.admin.listUsers({ page, perPage: 1000 });
      if (error) throw new Error(error.message);
      for (const u of data.users) if (u.email) emailToId.set(u.email.toLowerCase(), u.id);
      if (data.users.length < 1000) break;
      page++;
    }

    const results: { username: string; created: boolean }[] = [];
    for (const m of CREW) {
      const email = `${m.username}@tokyocustoms.gg`;
      let id = emailToId.get(email);
      let created = false;
      if (!id) {
        const { data, error } = await supabaseAdmin.auth.admin.createUser({
          email,
          password: m.password,
          email_confirm: true,
          user_metadata: { display_name: m.displayName },
        });
        if (error) throw new Error(`${m.username}: ${error.message}`);
        id = data.user!.id;
        created = true;
      } else {
        // Reset password to the canonical one so the sheet is always accurate.
        await supabaseAdmin.auth.admin.updateUserById(id, { password: m.password });
      }

      await supabaseAdmin.from("profiles").upsert({
        id,
        email,
        display_name: m.displayName,
        discord_id: m.discordId,
      });

      await supabaseAdmin.from("user_roles").delete().eq("user_id", id);
      await supabaseAdmin.from("user_roles").insert({ user_id: id, role: m.role });

      results.push({ username: m.username, created });
    }

    return { ok: true, count: results.length, created: results.filter((r) => r.created).length };
  });

export const getCrewCredentials = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { userId } = context;
    const { data: roles } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", userId);
    if (!(roles ?? []).some((r) => r.role === "owner")) {
      throw new Error("Only owners can view credentials");
    }
    return CREW.map((m) => ({
      username: m.username,
      password: m.password,
      displayName: m.displayName,
      discordId: m.discordId,
      role: m.role,
    }));
  });

export const createCrewMember = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: {
    displayName: string;
    username: string;
    discordId: string;
    role: "owner" | "mechanic";
    password?: string;
  }) => data)
  .handler(async ({ context, data }) => {
    const { userId } = context;
    const { data: roles } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", userId);
    if (!(roles ?? []).some((r) => r.role === "owner")) {
      throw new Error("Only owners can create accounts");
    }

    const username = data.username.trim().toLowerCase().replace(/[^a-z0-9]/g, "");
    if (!username) throw new Error("Username required");
    if (!data.displayName.trim()) throw new Error("Display name required");
    const password = data.password?.trim() || (data.role === "owner" ? "boss123" : "TokyoDrift123");
    const email = `${username}@tokyocustoms.gg`;

    // Check if email already exists
    let existingId: string | undefined;
    let page = 1;
    while (true) {
      const { data: list, error } = await supabaseAdmin.auth.admin.listUsers({ page, perPage: 1000 });
      if (error) throw new Error(error.message);
      const hit = list.users.find((u) => u.email?.toLowerCase() === email);
      if (hit) { existingId = hit.id; break; }
      if (list.users.length < 1000) break;
      page++;
    }

    let id = existingId;
    if (!id) {
      const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
        user_metadata: { display_name: data.displayName.trim() },
      });
      if (error) throw new Error(error.message);
      id = created.user!.id;
    } else {
      await supabaseAdmin.auth.admin.updateUserById(id, { password });
    }

    await supabaseAdmin.from("profiles").upsert({
      id,
      email,
      display_name: data.displayName.trim(),
      discord_id: data.discordId.trim() || null,
    });
    await supabaseAdmin.from("user_roles").delete().eq("user_id", id);
    await supabaseAdmin.from("user_roles").insert({ user_id: id, role: data.role });

    return { ok: true, id, username, email, password };
  });