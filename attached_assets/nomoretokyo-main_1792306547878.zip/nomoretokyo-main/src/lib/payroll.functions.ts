import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

type PayrollConfig = { payout_day: number; last_payout_at: string | null };

async function getConfig(): Promise<PayrollConfig> {
  const { data } = await supabaseAdmin
    .from("app_settings").select("value").eq("key", "payroll_config").maybeSingle();
  const v = (data?.value as Partial<PayrollConfig> | null) ?? {};
  return { payout_day: typeof v.payout_day === "number" ? v.payout_day : 5, last_payout_at: v.last_payout_at ?? null };
}

function computeWeekStart(cfg: PayrollConfig): Date {
  if (cfg.last_payout_at) return new Date(cfg.last_payout_at);
  // most recent occurrence of payout_day at 00:00 (start of current pay week)
  const now = new Date();
  const d = new Date(now);
  d.setHours(0, 0, 0, 0);
  const day = d.getDay();
  const diff = (day - cfg.payout_day + 7) % 7;
  d.setDate(d.getDate() - diff);
  return d;
}

async function getWebhookUrl(): Promise<string | null> {
  // Prefer the dedicated payroll webhook; fall back to the global one.
  const { data: payroll } = await supabaseAdmin
    .from("app_settings").select("value").eq("key", "payroll_webhook_url").maybeSingle();
  const pUrl = (payroll?.value as { url?: string } | null)?.url;
  if (pUrl) return pUrl;
  const { data } = await supabaseAdmin
    .from("app_settings").select("value").eq("key", "discord_webhook_url").maybeSingle();
  return (data?.value as { url?: string } | null)?.url ?? null;
}

async function buildAndSyncMechanicEmbed(mechanicId: string) {
  const url = await getWebhookUrl();
  if (!url) return { sent: false, reason: "no_webhook_configured" as const };

  const cfg = await getConfig();
  const weekStart = computeWeekStart(cfg);

  const { data: profile } = await supabaseAdmin
    .from("profiles").select("*").eq("id", mechanicId).maybeSingle();
  if (!profile) return { sent: false, reason: "no_profile" as const };

  const p = profile as unknown as {
    id: string; display_name: string | null; email: string | null;
    commission_rate: number | null; weekly_hours: number | null;
    weekly_discord_message_id: string | null;
  };

  const { data: ordersRaw } = await supabaseAdmin
    .from("orders")
    .select("order_number,total,parts_cost,status,created_at")
    .eq("mechanic_id", mechanicId)
    .neq("status", "draft")
    .neq("status", "rejected")
    .gte("created_at", weekStart.toISOString())
    .order("created_at", { ascending: true });

  const orders = ordersRaw ?? [];
  const total = orders.reduce((s, o) => s + Number(o.total), 0);
  const partsTotal = orders.reduce((s, o) => s + Number((o as { parts_cost?: number }).parts_cost ?? 0), 0);
  const labourTotal = Math.max(0, total - partsTotal);
  const rate = Number(p.commission_rate ?? 0.4);
  const expectedPay = labourTotal * rate;
  const mechName = p.display_name || p.email || "Unknown";

  const list = orders.length
    ? orders.map((o) => `• \`${o.order_number}\` — $${Number(o.total).toLocaleString()} _(${o.status})_`).join("\n").slice(0, 1024)
    : "_No invoices yet this week_";

  const dayName = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"][cfg.payout_day];

  const appBase = process.env.PUBLIC_APP_URL || "https://stormtuners.lovable.app";
  const payUrl = `${appBase}/pay-mechanic/${mechanicId}`;

  const body = {
    username: "Tokyo Drift Customs · Payroll",
    embeds: [{
      title: `💰 Weekly Pay · ${mechName}`,
      color: 0xf59e0b,
      description: `Week started **${weekStart.toLocaleDateString()}** · Payout day: **${dayName}**`,
      fields: [
        { name: "Invoices", value: String(orders.length), inline: true },
        { name: "Commission %", value: `${(rate * 100).toFixed(0)}%`, inline: true },
        { name: "\u200b", value: "\u200b", inline: true },
        { name: "Customer Total", value: `$${total.toLocaleString()}`, inline: true },
        { name: "Parts Cost", value: `$${partsTotal.toLocaleString()}`, inline: true },
        { name: "Labour", value: `$${labourTotal.toLocaleString()}`, inline: true },
        { name: "Expected Pay", value: `**$${expectedPay.toLocaleString(undefined,{maximumFractionDigits:2})}**`, inline: false },
        { name: "Invoice Breakdown", value: list, inline: false },
      ],
      timestamp: new Date().toISOString(),
    }],
    components: [{
      type: 1,
      components: [{
        type: 2,
        style: 5,
        label: "💸 Pay This Week",
        url: payUrl,
      }],
    }],
  };

  // Edit existing message if we have one
  if (p.weekly_discord_message_id) {
    const r = await fetch(`${url}/messages/${p.weekly_discord_message_id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (r.ok) return { sent: true, edited: true };
  }

  // Post new and save id
  const r = await fetch(`${url}?wait=true`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!r.ok) return { sent: false, reason: "discord_error" as const };
  const msg = await r.json().catch(() => null) as { id?: string } | null;
  if (msg?.id) {
    await supabaseAdmin.from("profiles").update({ weekly_discord_message_id: msg.id } as never).eq("id", mechanicId);
  }
  return { sent: true, edited: false };
}

export const refreshMyWeekly = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    try { return await buildAndSyncMechanicEmbed(context.userId); }
    catch (e) { console.error("refreshMyWeekly", e); return { sent: false, reason: "error" as const }; }
  });

export const refreshMechanicWeekly = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ mechanicId: z.string().uuid() }).parse(i))
  .handler(async ({ data }) => {
    try { return await buildAndSyncMechanicEmbed(data.mechanicId); }
    catch (e) { console.error("refreshMechanicWeekly", e); return { sent: false, reason: "error" as const }; }
  });

export const setWeeklyHours = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ hours: z.number().min(0).max(168) }).parse(i))
  .handler(async ({ data, context }) => {
    const { error } = await supabaseAdmin
      .from("profiles").update({ weekly_hours: data.hours } as never).eq("id", context.userId);
    if (error) throw new Error(error.message);
    await buildAndSyncMechanicEmbed(context.userId).catch(() => null);
    return { ok: true };
  });

async function assertOwner(userId: string, action: string) {
  const { data, error } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "owner");
  if (error) throw new Error(error.message);
  if (!data || data.length === 0) {
    throw new Error(`Only owners can ${action}`);
  }
}

export const setCommissionRate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ userId: z.string().uuid(), rate: z.number().min(0).max(1) }).parse(i))
  .handler(async ({ data, context }) => {
    await assertOwner(context.userId, "change commission rates");
    const { error } = await supabaseAdmin
      .from("profiles").update({ commission_rate: data.rate } as never).eq("id", data.userId);
    if (error) throw new Error(error.message);
    await buildAndSyncMechanicEmbed(data.userId).catch(() => null);
    return { ok: true };
  });

export const setPayoutDay = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ payoutDay: z.number().int().min(0).max(6) }).parse(i))
  .handler(async ({ data, context }) => {
    await assertOwner(context.userId, "change payroll settings");
    const cfg = await getConfig();
    const next = { ...cfg, payout_day: data.payoutDay };
    const { error } = await supabaseAdmin.from("app_settings")
      .upsert({ key: "payroll_config", value: next as never });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const payMechanicWeek = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ mechanicId: z.string().uuid() }).parse(i))
  .handler(async ({ data, context }) => {
    await assertOwner(context.userId, "run payouts");

    const cfg = await getConfig();
    const weekStart = computeWeekStart(cfg);

    const { data: prof } = await supabaseAdmin
      .from("profiles").select("display_name, email, commission_rate, weekly_hours")
      .eq("id", data.mechanicId).maybeSingle();
    const p = prof as unknown as { display_name: string | null; email: string | null; commission_rate: number | null; weekly_hours: number | null } | null;
    if (!p) throw new Error("Mechanic not found");

    const { data: orders } = await supabaseAdmin
      .from("orders").select("id,total,parts_cost,status")
      .eq("mechanic_id", data.mechanicId)
      .neq("status", "draft").neq("status", "rejected")
      .gte("created_at", weekStart.toISOString());
    const arr = orders ?? [];
    const total = arr.reduce((s, o) => s + Number(o.total), 0);
    const partsTotal = arr.reduce((s, o) => s + Number((o as { parts_cost?: number }).parts_cost ?? 0), 0);
    const labour = Math.max(0, total - partsTotal);
    const rate = Number(p.commission_rate ?? 0.4);
    const pay = labour * rate;
    const mechName = p.display_name || p.email || "Unknown";

    // Mark all submitted orders as paid (those not already paid)
    const toPay = arr.filter((o) => o.status !== "paid").map((o) => o.id);
    if (toPay.length) {
      await supabaseAdmin.from("orders")
        .update({ status: "paid", approved_by: context.userId, approved_at: new Date().toISOString() } as never)
        .in("id", toPay);
    }

    // Post confirmation to webhook
    const url = await getWebhookUrl();
    if (url) {
      const body = {
        username: "Tokyo Drift Customs · Payroll",
        embeds: [{
          title: `✅ Paid Out · ${mechName}`,
          color: 0x10b981,
          fields: [
            { name: "Invoices Paid", value: String(arr.length), inline: true },
            { name: "Labour", value: `$${labour.toLocaleString()}`, inline: true },
            { name: "Commission %", value: `${(rate * 100).toFixed(0)}%`, inline: true },
            { name: "Amount Paid", value: `**$${pay.toLocaleString(undefined,{maximumFractionDigits:2})}**`, inline: false },
          ],
          timestamp: new Date().toISOString(),
        }],
      };
      await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).catch(() => null);
    }

    // Reset their week and clear the weekly embed id so the next one is fresh
    await supabaseAdmin.from("profiles")
      .update({ weekly_hours: 0, weekly_discord_message_id: null } as never)
      .eq("id", data.mechanicId);

    return { ok: true, paid: pay, invoices: arr.length, mechanicName: mechName };
  });

export const runPayout = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertOwner(context.userId, "run payout");

    const cfg = await getConfig();
    const weekStart = computeWeekStart(cfg);
    const url = await getWebhookUrl();

    // Build a final summary post + reset
    const { data: profiles } = await supabaseAdmin
      .from("profiles").select("id, display_name, email, commission_rate, weekly_hours") as unknown as {
        data: Array<{ id: string; display_name: string | null; email: string | null; commission_rate: number | null; weekly_hours: number | null }> | null;
      };

    let totalPaid = 0;
    const lines: string[] = [];
    for (const p of profiles ?? []) {
      const { data: orders } = await supabaseAdmin
        .from("orders").select("total,parts_cost,status")
        .eq("mechanic_id", p.id)
        .neq("status", "draft").neq("status", "rejected")
        .gte("created_at", weekStart.toISOString());
      const sum = (orders ?? []).reduce((s, o) => s + Number(o.total), 0);
      const partsSum = (orders ?? []).reduce((s, o) => s + Number((o as { parts_cost?: number }).parts_cost ?? 0), 0);
      const labourSum = Math.max(0, sum - partsSum);
      const rate = Number(p.commission_rate ?? 0.4);
      const pay = labourSum * rate;
      if (sum > 0 || Number(p.weekly_hours ?? 0) > 0) {
        totalPaid += pay;
        lines.push(`**${p.display_name || p.email || "?"}** — ${(orders??[]).length} inv · labour $${labourSum.toLocaleString()} · ${(rate*100).toFixed(0)}% → **$${pay.toLocaleString(undefined,{maximumFractionDigits:2})}**`);
      }
    }

    if (url) {
      const body = {
        username: "Tokyo Drift Customs · Payroll",
        embeds: [{
          title: "✅ Payout Complete",
          color: 0x10b981,
          description: `Pay week ending **${new Date().toLocaleDateString()}**\n\n${lines.join("\n") || "_No activity_"}`,
          fields: [{ name: "Total Paid Out", value: `**$${totalPaid.toLocaleString(undefined,{maximumFractionDigits:2})}**`, inline: false }],
          timestamp: new Date().toISOString(),
        }],
      };
      await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).catch(() => null);
    }

    // Reset week
    const nextCfg = { ...cfg, last_payout_at: new Date().toISOString() };
    await supabaseAdmin.from("app_settings").upsert({ key: "payroll_config", value: nextCfg as never });
    await supabaseAdmin.from("profiles").update({ weekly_hours: 0, weekly_discord_message_id: null } as never).neq("id", "00000000-0000-0000-0000-000000000000");

    return { ok: true, totalPaid };
  });
