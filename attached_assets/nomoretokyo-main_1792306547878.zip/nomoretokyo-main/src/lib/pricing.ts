export type ServiceCategory = {
  id: string;
  label: string;
  type: "single" | "tier";
  isRespray?: boolean;
  options: { id: string; label: string; price: number; cost: number }[];
};

export const CATEGORIES: ServiceCategory[] = [
  {
    id: "repair",
    label: "Repair",
    type: "single",
    options: [{ id: "repair", label: "Full Repair", price: 1000, cost: 100 }],
  },
  {
    id: "brakes",
    label: "Brakes",
    type: "tier",
    options: [
      { id: "brake1", label: "Brakes 1", price: 10000, cost: 2500 },
      { id: "brake2", label: "Brakes 2", price: 15000, cost: 5000 },
      { id: "brake3", label: "Brakes 3", price: 20000, cost: 7500 },
    ],
  },
  {
    id: "engine",
    label: "Engine",
    type: "tier",
    options: [
      { id: "engine1", label: "Engine 1", price: 30000, cost: 10000 },
      { id: "engine2", label: "Engine 2", price: 50000, cost: 20000 },
      { id: "engine3", label: "Engine 3", price: 70000, cost: 30000 },
      { id: "engine4", label: "Engine 4", price: 80000, cost: 40000 },
    ],
  },
  {
    id: "suspension",
    label: "Suspension",
    type: "tier",
    options: [
      { id: "susp1", label: "Suspension 1", price: 6000, cost: 3000 },
      { id: "susp2", label: "Suspension 2", price: 12000, cost: 6000 },
      { id: "susp3", label: "Suspension 3", price: 18000, cost: 9000 },
      { id: "susp4", label: "Suspension 4", price: 24000, cost: 12000 },
    ],
  },
  {
    id: "transmission",
    label: "Transmission",
    type: "tier",
    options: [
      { id: "trans1", label: "Transmission 1", price: 10000, cost: 5000 },
      { id: "trans2", label: "Transmission 2", price: 20000, cost: 10000 },
      { id: "trans3", label: "Transmission 3", price: 30000, cost: 15000 },
    ],
  },
  {
    id: "turbo",
    label: "Turbo",
    type: "single",
    options: [{ id: "turbo", label: "Turbo", price: 50000, cost: 10000 }],
  },
  {
    id: "visual",
    label: "Visual & Body",
    type: "single",
    isRespray: true,
    options: [
      { id: "primary-color", label: "Primary Color", price: 15000, cost: 1000 },
      { id: "secondary-color", label: "Secondary Color", price: 15000, cost: 1000 },
      { id: "dashboard", label: "Respray Dashboard", price: 15000, cost: 1000 },
      { id: "interior", label: "Interior", price: 15000, cost: 1000 },
      { id: "respray-primary", label: "Respray (Primary)", price: 15000, cost: 1000 },
      { id: "respray-secondary", label: "Respray (Secondary)", price: 15000, cost: 1000 },
      { id: "respray-wheels", label: "Respray Wheels", price: 15000, cost: 1000 },
      { id: "pearlescent", label: "Pearlescent", price: 15000, cost: 1000 },
    ],
  },
  {
    id: "lighting",
    label: "Neon & Lighting",
    type: "single",
    options: [
      { id: "neon", label: "Neon Kit", price: 5000, cost: 1000 },
      { id: "tire-smoke", label: "Tire Smoke", price: 5000, cost: 1000 },
      { id: "window-tint", label: "Window Tinting", price: 2500, cost: 1000 },
      { id: "xenon", label: "Xenon Lighting", price: 2500, cost: 1000 },
    ],
  },
  {
    id: "extras",
    label: "Extras",
    type: "single",
    options: [
      { id: "horns", label: "Horns", price: 2000, cost: 500 },
      { id: "hydraulics", label: "Hydraulics", price: 2000, cost: 500 },
      { id: "plate", label: "Plate Style", price: 2000, cost: 500 },
      { id: "wheels", label: "Wheels", price: 5000, cost: 500 },
    ],
  },
];

export type SelectedItem = { id: string; label: string; price: number; cost: number; category: string };

export const RESPRAY_CAP = 60000;

/**
 * Apply the respray deal: when more than 4 resprays are picked,
 * the customer charge for resprays is capped at $60,000.
 * Returns { chargeTotal, partsTotal } for ALL items.
 */
export function computeTotals(items: SelectedItem[]) {
  const resprays = items.filter((i) => i.category === "Visual & Body");
  const others = items.filter((i) => i.category !== "Visual & Body");
  const resprayRaw = resprays.reduce((s, i) => s + i.price, 0);
  const resprayCharge = resprays.length > 4 ? Math.min(resprayRaw, RESPRAY_CAP) : resprayRaw;
  const otherCharge = others.reduce((s, i) => s + i.price, 0);
  const partsTotal = items.reduce((s, i) => s + i.cost, 0);
  const chargeTotal = resprayCharge + otherCharge;
  return { chargeTotal, partsTotal, resprayCount: resprays.length, resprayCapped: resprays.length > 4 };
}

export const formatMoney = (n: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n);