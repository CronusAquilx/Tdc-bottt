import {
  SlashCommandBuilder, ChatInputCommandInteraction
} from "discord.js";
import { db, getProfile, rowToTimeclock, getGuildConfig } from "../db.js";
import { requireRole } from "../lib/roles.js";
import { buildClockInEmbed, buildClockOutEmbed } from "../lib/embeds.js";
import { randomUUID } from "../lib/utils.js";
import { warnedMechanics, stayedIn } from "../lib/warnState.js";
import { calculateCreditedShiftMinutes } from "../lib/timeclock.js";
import { logEvent } from "../lib/eventLog.js";

export const data = new SlashCommandBuilder()
  .setName("clock")
  .setDescription("Time tracking (or use the buttons in the timeclock channel)")
  .addSubcommand(s => s.setName("in").setDescription("Clock in to start your shift"))
  .addSubcommand(s =>
    s.setName("out")
      .setDescription("Clock out to end your shift")
      .addStringOption(o => o.setName("notes").setDescription("Session notes (optional)"))
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  const sub = interaction.options.getSubcommand();

  if (sub === "in") {
    await interaction.deferReply();
    const active = await db.execute({ sql: "SELECT id FROM timeclock WHERE mechanic_id = ? AND clock_out_time IS NULL LIMIT 1", args: [interaction.user.id] });
    if (active.rows[0]) {
      await interaction.editReply({ content: `⚠️ <@${interaction.user.id}> You're already clocked in. Use \`/clock out\` or the **Clock Out** button.` });
      return;
    }
    const id = randomUUID();
    await db.execute({
      sql: "INSERT INTO timeclock (id, mechanic_id, clock_in_time, guild_id) VALUES (?, ?, datetime('now'), ?)",
      args: [id, interaction.user.id, interaction.guild?.id ?? ""]
    });
    await db.execute({ sql: "UPDATE profiles SET status = 'online' WHERE discord_id = ?", args: [interaction.user.id] });
    logEvent({ kind: "clock_in", guildId: interaction.guild?.id, userId: interaction.user.id, userName: interaction.user.username, detail: "clocked in via /clock" });
    const r = await db.execute({ sql: "SELECT * FROM timeclock WHERE id = ?", args: [id] });
    const entry = rowToTimeclock(r.rows[0]);
    const profile = await getProfile(interaction.user.id);
    const displayName = profile?.display_name
      ?? (interaction.member as any)?.displayName
      ?? interaction.user.globalName
      ?? interaction.user.username;
    const embed = buildClockInEmbed(displayName, entry.clock_in_time);

    // Post to clock LOGS channel (not the panel channel — panel stays clean)
    let postedTo = "";
    if (interaction.guild) {
      const config = await getGuildConfig(interaction.guild.id);
      const logChanId = config?.clocklog_channel_id ?? config?.timeclock_channel_id;
      if (logChanId) {
        try {
          const ch = await interaction.guild.channels.fetch(logChanId);
          if (ch?.isTextBased()) {
            const msg = await (ch as any).send({ embeds: [embed] });
            await db.execute({ sql: "UPDATE timeclock SET clock_message_id = ?, clock_channel_id = ? WHERE id = ?", args: [msg.id, ch.id, id] });
            postedTo = ch.id;
          }
        } catch { /* ignore */ }
      }
    }

    await interaction.editReply({ content: postedTo ? `✅ Clocked in! Check <#${postedTo}>.` : "✅ Clocked in!" });
    return;
  }

  if (sub === "out") {
    await interaction.deferReply();
    const notes = interaction.options.getString("notes");
    const active = await db.execute({ sql: "SELECT * FROM timeclock WHERE mechanic_id = ? AND clock_out_time IS NULL ORDER BY created_at DESC LIMIT 1", args: [interaction.user.id] });
    if (!active.rows[0]) {
      await interaction.editReply({ content: `❌ <@${interaction.user.id}> You're not clocked in.` });
      return;
    }
    const entry = rowToTimeclock(active.rows[0]);
    const mins = await calculateCreditedShiftMinutes(entry.id, entry.mechanic_id, entry.clock_in_time);
    await db.execute({ sql: "UPDATE timeclock SET clock_out_time = datetime('now'), duration_minutes = ?, notes = ?, status = 'approved', warned_at = NULL, stayed_in_at = NULL WHERE id = ?", args: [mins, notes ?? null, entry.id] });
    await db.execute({ sql: "UPDATE profiles SET hours_worked_this_week = hours_worked_this_week + ?, status = 'offline' WHERE discord_id = ?", args: [mins / 60, entry.mechanic_id] });
    logEvent({ kind: "clock_out", guildId: interaction.guild?.id, userId: entry.mechanic_id, userName: interaction.user.username, detail: `${Math.round(mins)} min credited (/clock)` });
    // Clear any in-memory warn/stay state for this shift
    warnedMechanics.delete(entry.id);
    stayedIn.delete(entry.mechanic_id);
    const ur = await db.execute({ sql: "SELECT * FROM timeclock WHERE id = ?", args: [entry.id] });
    const updated = rowToTimeclock(ur.rows[0]);
    const profile = await getProfile(interaction.user.id);
    const ordersThisShift = await db.execute({
      sql: "SELECT COUNT(*) FROM orders WHERE mechanic_id = ? AND status = 'complete' AND completed_at >= ?",
      args: [interaction.user.id, entry.clock_in_time]
    });
    const orderCount = Number(ordersThisShift.rows[0]?.[0] ?? 0);
    const embed = buildClockOutEmbed(profile?.display_name ?? interaction.user.username, updated.clock_in_time, updated.clock_out_time!, mins, orderCount);

    // Edit the original clock-in message in the timeclock channel
    if (updated.clock_message_id && updated.clock_channel_id && interaction.guild) {
      try {
        const ch = await interaction.guild.channels.fetch(updated.clock_channel_id);
        if (ch?.isTextBased()) {
          const msg = await (ch as any).messages.fetch(updated.clock_message_id);
          await msg.edit({ embeds: [embed] });
        }
      } catch { /* ignore */ }
    }

    await interaction.editReply({ embeds: [embed] });
  }
}
