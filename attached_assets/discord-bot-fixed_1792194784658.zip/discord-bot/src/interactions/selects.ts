import {
  AnySelectMenuInteraction,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  StringSelectMenuBuilder, StringSelectMenuOptionBuilder,
  ChannelSelectMenuBuilder, UserSelectMenuBuilder, EmbedBuilder,
  ChannelType, PermissionFlagsBits, TextChannel, MessageFlags} from "discord.js";
import { db, getProfile, getSetting, setSetting, rowToOrder, setGuildRoleMapping, getGuildConfig, splitRoleIds, checkpointDatabase, saveDatabaseSnapshot } from "../db.js";
import { buildDraftEmbed, money, COLORS } from "../lib/embeds.js";
import { requireRole } from "../lib/roles.js";
import { postOrderPanel } from "./orderpanel.js";
import { mainDraftButtonRows, categoryViewButtonRow, getCommissionData } from "./draftbuttons.js";
import { ensureMechanicSalesChannel } from "../lib/saleschannel.js";
import { handleBankSelect } from "./bankaccount.js";
import { logEvent } from "../lib/eventLog.js";
import { withOrderLock, safeUpdate, ephemeralNotice } from "../lib/resilience.js";
import { resolveDraftId } from "../lib/draftRecovery.js";

const FOOTER = "東京ドリフトカスタム  ·  Built Different. Driven Hard.";

export async function handleSelect(interaction: AnySelectMenuInteraction) {
  if (await handleBankSelect(interaction)) return;
  const [ns, action, ...rest] = interaction.customId.split(":");
  const extra = rest.join(":");

  // ── Role select menus ─────────────────────────────────────────────────────
  if (interaction.isRoleSelectMenu()) {
    // setup:setrole:level
    if (ns === "setup" && action === "setrole") {
      const level = rest[0] as "owner" | "head_manager" | "manager" | "trainer" | "mechanic" | "needs_training";
      const validLevels = ["owner", "head_manager", "manager", "trainer", "mechanic", "needs_training"];
      if (!validLevels.includes(level)) { await interaction.reply({ content: "❌ Invalid role level.", flags: MessageFlags.Ephemeral }); return; }
      const roleIds = interaction.values;
      if (!interaction.guild) { await interaction.reply({ content: "❌ Must be used in a server.", flags: MessageFlags.Ephemeral }); return; }
      await setGuildRoleMapping(interaction.guild.id, level, roleIds);
      const levelLabel = level.charAt(0).toUpperCase() + level.slice(1).replace(/_/g, " ");
      const mentions = roleIds.map(id => `<@&${id}>`).join(", ");
      await interaction.reply({ content: `✅ **${levelLabel}** set to ${mentions}. Members with ${roleIds.length > 1 ? "any of these roles" : "this role"} can use ${level}-level commands.`, flags: MessageFlags.Ephemeral });
    }

    // admin:assignbyrole:pickrole — pick role → fetch members with that role → show multi-select
    if (ns === "admin" && action === "assignbyrole" && rest[0] === "pickrole") {
      if (!(await requireRole(interaction, "manager"))) return;
      const guild = interaction.guild;
      if (!guild) { await interaction.reply({ content: "❌ Must be used in a server.", flags: MessageFlags.Ephemeral }); return; }
      await interaction.deferUpdate();

      const roleId = interaction.values[0];
      let members: { id: string; displayName: string }[] = [];
      try {
        await guild.members.fetch();
        const role = await guild.roles.fetch(roleId);
        if (role) {
          members = [...role.members.values()].map(m => ({ id: m.id, displayName: m.displayName }));
        }
      } catch { /* ignore */ }

      if (!members.length) {
        await interaction.editReply({ content: `❌ No members found with that role.`, embeds: [], components: [] });
        return;
      }

      const limited = members.slice(0, 25);
      const embed = new EmbedBuilder()
        .setTitle("🔩  Assign by Role — Step 2")
        .setColor(COLORS.dark)
        .setDescription(
          `Found **${members.length}** member(s) with that role.\n` +
          (members.length > 25 ? "*(Showing first 25)*\n" : "") +
          "\nSelect which mechanics you want to assign to a manager.\nYou can select multiple."
        )
        .setFooter({ text: FOOTER });

      const memberSelect = new StringSelectMenuBuilder()
        .setCustomId("admin:assignbyrole:pickmembers")
        .setPlaceholder("Select mechanics to assign...")
        .setMinValues(1)
        .setMaxValues(Math.min(limited.length, 25))
        .addOptions(limited.map(m =>
          new StringSelectMenuOptionBuilder().setLabel(m.displayName.slice(0, 100)).setValue(m.id)
        ));

      await interaction.editReply({
        embeds: [embed],
        components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(memberSelect)]
      });
    }

    return;
  }

  // ── User select menus ──────────────────────────────────────────────────────
  if (interaction.isUserSelectMenu()) {
    // admin:crew:pickmembers — bulk add selected members as mechanics
    if (ns === "admin" && action === "crew" && rest[0] === "pickmembers") {
      if (!(await requireRole(interaction, "manager"))) return;
      await interaction.deferUpdate();

      const guild = interaction.guild;
      if (!guild) {
        await interaction.editReply({ content: "❌ This can only be used inside a server.", embeds: [], components: [] });
        return;
      }

      const config = await getGuildConfig(guild.id);
      const mechanicRoleIds = splitRoleIds(config?.mechanic_role_id);
      const added: string[] = [];
      const alreadyMechanics: string[] = [];
      const preservedStaff: string[] = [];
      const failed: string[] = [];
      const pendingMemberIds: string[] = [];

      for (const memberId of interaction.values) {
        try {
          const member = await guild.members.fetch(memberId);
          if (member.user.bot) continue;

          const displayName = member.displayName?.trim() || member.user.globalName?.trim() || member.user.username;
          const profile = await getProfile(memberId);
          const roleRows = await db.execute({
            sql: "SELECT role FROM user_roles WHERE discord_id = ?",
            args: [memberId]
          });
          const existingRoles = roleRows.rows.map(row => String(row[0] ?? ""));
          const existingStaffRole = existingRoles.find(role => ["owner", "manager", "trainer"].includes(role));

          // Never downgrade an existing manager/trainer/owner through the mechanic
          // bulk-add button. New users and unassigned users become mechanics.
          if (existingStaffRole) {
            preservedStaff.push(`${displayName} (${existingStaffRole})`);
            continue;
          }

          if (!profile) {
            await db.execute({
              sql: "INSERT INTO profiles (discord_id, display_name, commission_rate) VALUES (?, ?, 0.3)",
              args: [memberId, displayName]
            });
            added.push(displayName);
          } else {
            alreadyMechanics.push(displayName);
          }

          await db.execute({
            sql: "INSERT OR IGNORE INTO user_roles (discord_id, role) VALUES (?, 'mechanic')",
            args: [memberId]
          });
           pendingMemberIds.push(memberId);

          // Keep the Discord role and database role aligned when the mapping exists.
          for (const roleId of mechanicRoleIds) {
            if (!member.roles.cache.has(roleId)) {
              try { await member.roles.add(roleId, "Added to crew from Admin Panel"); } catch { /* report below only if all fail */ }
            }
          }
        } catch (err: any) {
          failed.push(`<@${memberId}>${err?.message ? ` (${err.message})` : ""}`);
        }
      }

       // Persist crew membership before asking Discord to create any channels.
       // If the bot restarts during channel setup, the people are still saved.
       await saveDatabaseSnapshot();
      logEvent({
        kind: "crew_changed", guildId: guild.id, userId: interaction.user.id, userName: interaction.user.username,
        detail: `bulk add via admin panel: ${added.length} new, ${alreadyMechanics.length} existing, ${failed.length} failed`,
      });

      const lines = [
        `✅ **${added.length}** new mechanic${added.length === 1 ? "" : "s"} saved`,
        alreadyMechanics.length ? `↪️ **${alreadyMechanics.length}** already in the crew (commission preserved)` : "",
        preservedStaff.length ? `🛡️ **${preservedStaff.length}** existing staff member${preservedStaff.length === 1 ? "" : "s"} kept unchanged: ${preservedStaff.join(", ")}` : "",
        failed.length ? `❌ **${failed.length}** failed: ${failed.join(", ")}` : "",
         mechanicRoleIds.length ? "Discord mechanic role applied where permitted." : "No Discord mechanic role is configured; the database crew entry was still saved.",
         pendingMemberIds.length ? "Next, choose the category for their private sales channels." : ""
      ].filter(Boolean);

      const embed = new EmbedBuilder()
         .setTitle(pendingMemberIds.length ? "✅  CREW SAVED — CHOOSE CHANNEL CATEGORY" : "✅  CREW SAVED")
        .setColor(failed.length ? COLORS.warning : COLORS.approved)
        .setDescription(lines.join("\n"))
        .setFooter({ text: FOOTER })
        .setTimestamp();

       if (!pendingMemberIds.length) {
         await interaction.editReply({ embeds: [embed], components: [] });
         return;
       }

       const pendingKey = `pending_crew_add:${guild.id}:${interaction.user.id}`;
       await setSetting(pendingKey, JSON.stringify(pendingMemberIds));
       await saveDatabaseSnapshot();
       const categoryRow = new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(
         new ChannelSelectMenuBuilder()
           .setCustomId("admin:crew:pickcategory")
           .setChannelTypes(ChannelType.GuildCategory)
           .setPlaceholder("Choose a category for sales channels...")
           .setMinValues(1).setMaxValues(1)
       );
       await interaction.editReply({ embeds: [embed], components: [categoryRow] });
      return;
    }

    // admin:setrole:pickmember:(trainer|manager) — assign user a role in the DB
    if (ns === "admin" && action === "setrole" && rest[0] === "pickmember") {
      if (!(await requireRole(interaction, "manager"))) return;
      await interaction.deferUpdate();
      try {
        const roleTarget = rest[1] as "trainer" | "manager";
        const targetUserId = interaction.values[0];
        const targetUser = interaction.users?.get(targetUserId) ?? (await interaction.client.users.fetch(targetUserId).catch(() => null));
        const displayName = targetUser?.displayName ?? targetUser?.username ?? targetUserId;
        // Ensure profile exists so the role record has a backing profile
        await db.execute({ sql: "INSERT OR IGNORE INTO profiles (discord_id, display_name, commission_rate) VALUES (?, ?, 0.3)", args: [targetUserId, displayName] });
        // Remove any existing role for this user then insert the new one
        await db.execute({ sql: "DELETE FROM user_roles WHERE discord_id = ?", args: [targetUserId] });
        await db.execute({ sql: "INSERT INTO user_roles (discord_id, role) VALUES (?, ?)", args: [targetUserId, roleTarget] });
       await saveDatabaseSnapshot();
        logEvent({
          kind: "crew_changed", guildId: interaction.guildId ?? undefined, userId: targetUserId, userName: displayName,
          detail: `set as ${roleTarget} by ${interaction.user.username}`,
        });
        const roleEmoji = roleTarget === "trainer" ? "📚" : "👔";
        const roleDesc  = roleTarget === "manager"
          ? `<@${targetUserId}> is now recognised as a **Manager** in the bot.\n\nThey can use manager commands and will earn a cut of the mechanic commission pool each pay period.`
          : `<@${targetUserId}> is now recognised as a **Trainer** in the bot.\n\nThey will see their crew cut on order embeds and their commission is calculated accordingly.`;
        const embed = new EmbedBuilder()
          .setTitle(`✅ ${roleEmoji} ${roleTarget === "trainer" ? "Trainer" : "Manager"} Assigned`)
          .setColor(COLORS.approved)
          .setDescription(roleDesc)
          .setFooter({ text: "Tokyo Drift Customs" }).setTimestamp();
        await interaction.editReply({ embeds: [embed], components: [] });
      } catch (err: any) {
        console.error("[TDC] setrole:pickmember error:", err);
        try { await interaction.editReply({ content: `❌ Failed to assign role: ${err?.message ?? "Unknown error"}`, components: [] }); } catch { /* ignore */ }
      }
      return;
    }

    // admin:assignbyrole:pickmanager — after bulk mechanic selection, pick manager
    if (ns === "admin" && action === "assignbyrole" && rest[0] === "pickmanager") {
      if (!(await requireRole(interaction, "manager"))) return;
      await interaction.deferUpdate();
      const managerId = interaction.values[0];
      const managerProfile = await getProfile(managerId);
      if (!managerProfile) {
        await interaction.editReply({ content: "❌ Manager not found — add them via `/crew add` first.", embeds: [], components: [] });
        return;
      }
      const pendingKey = `pending_bulk_assign_${interaction.user.id}`;
      const pendingStr = await getSetting(pendingKey);
      if (!pendingStr) {
        await interaction.editReply({ content: "❌ Session expired. Please start over.", embeds: [], components: [] });
        return;
      }
      const mechIds = pendingStr.split(",").filter(Boolean);
      let assigned = 0;
      const failedNames: string[] = [];
      for (const mechId of mechIds) {
        const mechProfile = await getProfile(mechId);
        if (!mechProfile) { failedNames.push(`<@${mechId}>`); continue; }
        await db.execute({ sql: "UPDATE profiles SET manager_id = ? WHERE discord_id = ?", args: [managerId, mechId] });
        assigned++;
      }
      await db.execute({ sql: "DELETE FROM app_settings WHERE key = ?", args: [pendingKey] });
      await checkpointDatabase();
      logEvent({
        kind: "crew_changed", guildId: interaction.guildId ?? undefined, userId: managerId, userName: managerProfile.display_name,
        detail: `${assigned} mechanic(s) assigned to manager ${managerProfile.display_name} by ${interaction.user.username}`,
      });
      const embed = new EmbedBuilder()
        .setTitle("✅  Bulk Manager Assignment Complete")
        .setColor(COLORS.approved)
        .setDescription(
          `**${assigned}** mechanic(s) are now assigned to **${managerProfile.display_name}**.\n` +
          `💰 ${managerProfile.display_name} will earn **${Math.round((managerProfile.manager_override_rate ?? 0.20) * 100)}%** of each mechanic's commission per order.\n\n` +
          (failedNames.length ? `⚠️ Not found in crew (use \`/crew add\` first): ${failedNames.join(", ")}` : "")
        )
        .setFooter({ text: FOOTER });
      await interaction.editReply({ embeds: [embed], components: [] });
      return;
    }

    if (ns === "admin" && action === "saleschan" && rest[0] === "pickmechanic") {
      const type = rest[1];
      if (!(await requireRole(interaction, "manager"))) return;

      const mechanicId = interaction.values[0];
      const guild = interaction.guild!;

      if (type === "resend") {
        await interaction.deferUpdate();
        const profile = await getProfile(mechanicId);
        if (!profile) {
          await interaction.editReply({ content: "❌ That user isn't in the crew. Add them via `/crew add` first.", components: [] });
          return;
        }
        if (!profile.sales_channel_id) {
          await interaction.editReply({ content: `❌ **${profile.display_name}** doesn't have a sales channel set up yet.`, components: [] });
          return;
        }
        try {
          const ch = await guild.channels.fetch(profile.sales_channel_id);
          if (!ch?.isTextBased()) throw new Error("Not a text channel");
          const result = await postOrderPanel(ch as TextChannel, mechanicId, profile.display_name, profile.commission_rate);
          const pinNote = result.pinned ? "" : "\n⚠️ Panel sent but **could not be pinned** — give the bot **Manage Messages** permission in that channel so mechanics can find it easily.";
          await interaction.editReply({ content: `✅ Order panel re-posted to <#${profile.sales_channel_id}> for **${profile.display_name}**.${pinNote}`, embeds: [], components: [] });
        } catch (err: any) {
          await interaction.editReply({ content: `❌ Could not post panel — check bot permissions in <#${profile.sales_channel_id}>. ${err?.message ?? ""}`, embeds: [], components: [] });
        }
        return;
      }

      if (type === "new") {
        await interaction.deferUpdate();

        const profile = await getProfile(mechanicId);
        if (!profile) {
          await interaction.editReply({ content: "❌ That user isn't in the crew. Add them via `/crew add` first.", components: [] });
          return;
        }

        // Ask which category to put the channel in
        const embed = new EmbedBuilder()
          .setTitle("📁  Choose a Category (optional)")
          .setColor(COLORS.primary)
          .setDescription(
            `Creating sales channel for **${profile.display_name}**.\n\n` +
            `Pick a **channel category** to place it in, or click **No Category** to create it at the top level.`
          )
          .setFooter({ text: FOOTER });

        const catRow = new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(
          new ChannelSelectMenuBuilder()
            .setCustomId(`admin:saleschan:pickcat:${mechanicId}`)
            .setChannelTypes(ChannelType.GuildCategory)
            .setPlaceholder("Select a category folder...")
            .setMinValues(1).setMaxValues(1)
        );
        const skipRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder()
            .setCustomId(`admin:saleschan:create:${mechanicId}`)
            .setLabel("⬆️ No Category — Create Now")
            .setStyle(ButtonStyle.Primary)
        );

        await interaction.editReply({ embeds: [embed], components: [catRow, skipRow] });

      } else {
        const profile = await getProfile(mechanicId);
        const displayName = profile?.display_name ?? `<@${mechanicId}>`;

        const embed = new EmbedBuilder()
          .setTitle("🔗  Attach Existing Sales Channel")
          .setColor(COLORS.primary)
          .setDescription(`**Step 2 of 2 — Pick the channel** to attach to **${displayName}**.`)
          .setFooter({ text: FOOTER });

        const chanRow = new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(
          new ChannelSelectMenuBuilder()
            .setCustomId(`admin:saleschan:pickchan:${mechanicId}`)
            .setChannelTypes(ChannelType.GuildText)
            .setPlaceholder("Select the text channel to attach...")
            .setMinValues(1).setMaxValues(1)
        );

        await interaction.update({ embeds: [embed], components: [chanRow] });
      }
    }

    // ── Admin: payroll — mark individual as paid / pending ───────────────────
    if (ns === "admin" && action === "payroll" && rest[0] === "pickmarkpaid") {
      if (!(await requireRole(interaction, "manager"))) return;
      const memberId = interaction.values[0];
      const profile = await getProfile(memberId);
      if (!profile) {
        await interaction.update({ content: "❌ User not found in crew.", embeds: [], components: [] });
        return;
      }
      await db.execute({ sql: "UPDATE profiles SET current_pay_status = 'paid' WHERE discord_id = ?", args: [memberId] });
      await saveDatabaseSnapshot();
      await interaction.update({ content: `✅ **${profile.display_name}** marked as 💚 **paid** this week.`, embeds: [], components: [] });
    }

    if (ns === "admin" && action === "payroll" && rest[0] === "pickmarkunpaid") {
      if (!(await requireRole(interaction, "manager"))) return;
      const memberId = interaction.values[0];
      const profile = await getProfile(memberId);
      if (!profile) {
        await interaction.update({ content: "❌ User not found in crew.", embeds: [], components: [] });
        return;
      }
      await db.execute({ sql: "UPDATE profiles SET current_pay_status = 'pending' WHERE discord_id = ?", args: [memberId] });
      await saveDatabaseSnapshot();
      await interaction.update({ content: `✅ **${profile.display_name}** marked as 🔴 **pending** this week.`, embeds: [], components: [] });
    }

    // ── Admin: payroll — pick member to set individual pay ───────────────────
    if (ns === "admin" && action === "payroll" && rest[0] === "pickmember") {
      if (!(await requireRole(interaction, "manager"))) return;
      const memberId = interaction.values[0];
      const profile = await getProfile(memberId);
      if (!profile) {
        await interaction.update({ content: "❌ That user isn't in the crew. Add them via `/crew add` first.", embeds: [], components: [] });
        return;
      }
      const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder: AR } = await import("discord.js");
      const currentOverride = profile.commission_adjustment ?? 0;
      const modal = new ModalBuilder()
        .setCustomId(`admin:payroll:setpay:${memberId}`)
        .setTitle(`Set Pay — ${profile.display_name}`);
      modal.addComponents(
        new AR<InstanceType<typeof TextInputBuilder>>().addComponents(
          new TextInputBuilder()
            .setCustomId("amount")
            .setLabel("Commission $ amount (0 = use % calculation)")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setValue(currentOverride > 0 ? String(Math.round(currentOverride)) : "")
            .setPlaceholder("e.g. 5000  (enter 0 to clear override)")
        )
      );
      await interaction.showModal(modal);
    }

    // ── Admin: commission pick mechanic ─────────────────────────────────────
    if (ns === "admin" && action === "commission" && rest[0] === "pickmechanic") {
      if (!(await requireRole(interaction, "manager"))) return;
      const mechanicId = interaction.values[0];
      const profile = await getProfile(mechanicId);
      if (!profile) {
        await interaction.update({ content: "❌ That user isn't in the crew.", embeds: [], components: [] });
        return;
      }

      const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder: AR } = await import("discord.js");
      const modal = new ModalBuilder()
        .setCustomId(`admin:commission:set:${mechanicId}`)
        .setTitle(`Set Commission — ${profile.display_name}`);
      modal.addComponents(
        new AR<InstanceType<typeof TextInputBuilder>>().addComponents(
          new TextInputBuilder()
            .setCustomId("rate")
            .setLabel("Commission rate (0–100, e.g. 30 = 30%)")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setValue(String(Math.round(profile.commission_rate * 100)))
            .setPlaceholder("Enter percentage, e.g. 30")
        )
      );
      await interaction.showModal(modal);
    }

    // ── Admin: pick manager to set override rate → open modal ────────────────
    if (ns === "admin" && action === "commission" && rest[0] === "pickmanageroverride") {
      if (!(await requireRole(interaction, "manager"))) return;
      const managerId = interaction.values[0];
      const profile = await getProfile(managerId);
      if (!profile) {
        await interaction.update({ content: "❌ That user isn't in the crew.", embeds: [], components: [] });
        return;
      }
      const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder: AR } = await import("discord.js");
      const modal = new ModalBuilder()
        .setCustomId(`admin:commission:setoverride:${managerId}`)
        .setTitle(`Manager Override Cut — ${profile.display_name}`);
      modal.addComponents(
        new AR<InstanceType<typeof TextInputBuilder>>().addComponents(
          new TextInputBuilder()
            .setCustomId("override_rate")
            .setLabel("Override cut % (0–100, e.g. 20 = 20%)")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setValue(String(Math.round((profile.manager_override_rate ?? 0.20) * 100)))
            .setPlaceholder("Enter percentage, e.g. 20")
        )
      );
      await interaction.showModal(modal);
    }

    // ── Admin: assign manager — step 1, picked mechanic → pick manager ────────
    if (ns === "admin" && action === "assign" && rest[0] === "pickmechanic") {
      if (!(await requireRole(interaction, "manager"))) return;
      const mechanicId = interaction.values[0];
      const profile = await getProfile(mechanicId);
      if (!profile) {
        await interaction.update({ content: "❌ That user isn't in the crew.", embeds: [], components: [] });
        return;
      }
      const { UserSelectMenuBuilder: USM } = await import("discord.js");
      const embed = new EmbedBuilder()
        .setTitle("👤  Assign Manager — Step 2 of 2")
        .setColor(COLORS.primary)
        .setDescription(`Now pick the **manager** for **${profile.display_name}**.\nThe manager will earn **20% of this mechanic's commission** on each order.`)
        .setFooter({ text: FOOTER });
      const sel = new ActionRowBuilder<UserSelectMenuBuilder>().addComponents(
        new USM()
          .setCustomId(`admin:assign:pickmanager:${mechanicId}`)
          .setPlaceholder("Pick a manager...")
          .setMinValues(1).setMaxValues(1)
      );
      await interaction.update({ embeds: [embed], components: [sel] });
    }

    // ── Admin: assign manager — step 2, picked manager → save ────────────────
    if (ns === "admin" && action === "assign" && rest[0] === "pickmanager") {
      if (!(await requireRole(interaction, "manager"))) return;
      const mechanicId = rest[1];
      const managerId  = interaction.values[0];
      const [mechanicProfile, managerProfile] = await Promise.all([
        getProfile(mechanicId), getProfile(managerId)
      ]);
      if (!mechanicProfile) {
        await interaction.update({ content: "❌ Mechanic not found.", embeds: [], components: [] });
        return;
      }
      if (!managerProfile) {
        await interaction.update({ content: "❌ Manager not found — they need to be added via `/crew add` first.", embeds: [], components: [] });
        return;
      }
      await db.execute({ sql: "UPDATE profiles SET manager_id = ? WHERE discord_id = ?", args: [managerId, mechanicId] });
      await checkpointDatabase();
      await interaction.update({
        content: `✅ **${mechanicProfile.display_name}** is now assigned to manager **${managerProfile.display_name}**.\n💰 ${managerProfile.display_name} will earn 20% of ${mechanicProfile.display_name}'s commission on each order.`,
        embeds: [], components: []
      });
    }

    return;
  }

  // ── Channel select menus ───────────────────────────────────────────────────
  if (interaction.isChannelSelectMenu()) {
    // ── Pick a category after bulk crew profiles have been saved ───────────────
    if (ns === "admin" && action === "crew" && rest[0] === "pickcategory") {
      if (!(await requireRole(interaction, "manager"))) return;
      const guild = interaction.guild;
      if (!guild) {
        await interaction.reply({ content: "❌ This can only be used inside a server.", flags: MessageFlags.Ephemeral });
        return;
      }

      const categoryId = interaction.values[0];
      await interaction.deferUpdate();

      const category = await guild.channels.fetch(categoryId).catch(() => null);
      if (!category || category.type !== ChannelType.GuildCategory) {
        await interaction.editReply({ content: "❌ That category could not be found.", embeds: [], components: [] });
        return;
      }

      const pendingKey = `pending_crew_add:${guild.id}:${interaction.user.id}`;
      const pendingValue = await getSetting(pendingKey);
      let memberIds: string[] = [];
      try {
        const parsed = JSON.parse(pendingValue ?? "[]");
        if (Array.isArray(parsed)) memberIds = parsed.filter(id => typeof id === "string");
      } catch {
        memberIds = [];
      }

      if (!memberIds.length) {
        await interaction.editReply({
          content: "⚠️ The crew save was already completed or the setup session expired. Use **Health Check** to repair missing sales channels.",
          embeds: [],
          components: []
        });
        return;
      }

      const created: string[] = [];
      const reused: string[] = [];
      const panelIssues: string[] = [];
      const failures: string[] = [];

      for (const memberId of memberIds) {
        const profile = await getProfile(memberId);
        if (!profile) {
          failures.push(`<@${memberId}> (profile missing)`);
          continue;
        }

        try {
          const setup = await ensureMechanicSalesChannel(guild, memberId, categoryId);
          if (setup.created) created.push(profile.display_name);
          else reused.push(profile.display_name);
          if (!setup.panelPosted) {
            panelIssues.push(`${profile.display_name}: panel could not be posted`);
          } else if (!setup.panelPinned) {
            panelIssues.push(`${profile.display_name}: panel posted but could not be pinned`);
          }
        } catch (err: any) {
          failures.push(`${profile.display_name}${err?.message ? ` (${err.message})` : ""}`);
        }
      }

      await db.execute({ sql: "DELETE FROM app_settings WHERE key = ?", args: [pendingKey] });
      await checkpointDatabase();

      const resultLines = [
        `✅ Crew membership is saved permanently.`,
        `📁 **${created.length}** sales channel${created.length === 1 ? "" : "s"} created in **${category.name}**`,
        reused.length ? `🔗 **${reused.length}** existing sales channel${reused.length === 1 ? "" : "s"} reused` : "",
        panelIssues.length ? `⚠️ Panel permission issue: ${panelIssues.join(", ")}` : "",
        failures.length ? `❌ Setup failed: ${failures.join(", ")}` : "",
        "Use **Health Check** later to find or repair anything that is missing."
      ].filter(Boolean);

      const resultEmbed = new EmbedBuilder()
        .setTitle("✅  CREW CHANNELS READY")
        .setColor(failures.length ? COLORS.warning : COLORS.approved)
        .setDescription(resultLines.join("\n"))
        .setFooter({ text: FOOTER })
        .setTimestamp();
      await interaction.editReply({ embeds: [resultEmbed], components: [] });
      return;
    }

    // ── Pick a category before confirming child-channel deletion ───────────────
    if (ns === "admin" && action === "crew" && rest[0] === "pickcategorydelete") {
      if (!(await requireRole(interaction, "manager"))) return;
      const categoryId = interaction.values[0];
      const guild = interaction.guild!;
      await interaction.deferUpdate();

      const category = await guild.channels.fetch(categoryId).catch(() => null);
      if (!category || category.type !== ChannelType.GuildCategory) {
        await interaction.editReply({ content: "❌ Category not found.", embeds: [], components: [] });
        return;
      }
      const channels = await guild.channels.fetch();
      const children = [...channels.values()].filter(channel => channel?.parentId === categoryId);
      const names = children.slice(0, 12).map(channel => `• #${channel!.name}`).join("\n");
      const more = children.length > 12 ? `\n• …and ${children.length - 12} more` : "";
      const embed = new EmbedBuilder()
        .setTitle("⚠️  CONFIRM CATEGORY DELETION")
        .setColor(COLORS.rejected)
        .setDescription(
          `This will permanently delete **${children.length}** channel${children.length === 1 ? "" : "s"} inside **${category.name}**.\n\n` +
          (names || "*No child channels found.*") + more +
          "\n\nThe category will remain. Crew profiles, orders, and payroll history will be preserved, but deleted channel links will be cleared."
        )
        .setFooter({ text: FOOTER });
      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId(`admin:crew:deletecategoryconfirm:${categoryId}`).setLabel("🗑️  Delete All Channels").setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId("admin:crew:deletecategorycancel").setLabel("Cancel").setStyle(ButtonStyle.Secondary)
      );
      await interaction.editReply({ embeds: [embed], components: [row] });
      return;
    }

    // ── Attach existing channel as sales channel ──────────────────────────────
    if (ns === "admin" && action === "saleschan" && rest[0] === "pickchan") {
      if (!(await requireRole(interaction, "manager"))) return;
      const mechanicId = rest[1];
      const channelId  = interaction.values[0];
      const guild = interaction.guild!;

      await interaction.deferUpdate();

      const profile = await getProfile(mechanicId);
      if (!profile) {
        await interaction.editReply({ content: "❌ Mechanic not found. Add them via `/crew add` first.", components: [] });
        return;
      }

      let ch: any;
      try {
        ch = await guild.channels.fetch(channelId);
        if (!ch?.isTextBased()) throw new Error("Not a text channel");
      } catch {
        await interaction.editReply({ content: "❌ Channel not found or not a text channel.", components: [] });
        return;
      }

      await db.execute({ sql: "UPDATE profiles SET sales_channel_id = ? WHERE discord_id = ?", args: [channelId, mechanicId] });

      let panelPosted = false;
      let panelPinned = false;
      try {
        const result = await postOrderPanel(ch as TextChannel, mechanicId, profile.display_name, profile.commission_rate);
        panelPosted = true;
        panelPinned = result.pinned;
      } catch { /* ignore */ }

      let msg = `✅ <#${channelId}> attached as **${profile.display_name}**'s sales channel.`;
      if (!panelPosted) {
        msg += `\n⚠️ Could not post the order panel — make sure the bot has **Send Messages** and **Embed Links** permission in that channel, then use **Resend Panel** from the admin setup.`;
      } else if (!panelPinned) {
        msg += `\n✅ Order panel sent.\n⚠️ Could not pin it — give the bot **Manage Messages** permission in <#${channelId}> so mechanics can find it easily.`;
      } else {
        msg += ` Order panel posted and pinned.`;
      }

      await interaction.editReply({ content: msg, embeds: [], components: [] });
    }

    // ── Category picker for new sales channel ─────────────────────────────────
    // customId: admin:saleschan:pickcat:{mechanicId}
    if (ns === "admin" && action === "saleschan" && rest[0] === "pickcat") {
      if (!(await requireRole(interaction, "manager"))) return;
      const mechanicId = rest[1];
      const categoryId = interaction.values[0];
      const guild = interaction.guild!;

      await interaction.deferUpdate();

      const profile = await getProfile(mechanicId);
      if (!profile) {
        await interaction.editReply({ content: "❌ Mechanic not found. Add them via `/crew add` first.", components: [], embeds: [] });
        return;
      }

      // Create the sales channel inside the selected category
      const { PermissionFlagsBits, ChannelType } = await import("discord.js");
      const { splitRoleIds: srid, getGuildConfig: ggc } = await import("../db.js");
      const config = await ggc(guild.id);
      const channelName = `sales-${profile.display_name.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "").slice(0, 30)}`;

      const permOverwrites: any[] = [
        { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
      ];
      if (guild.members.me) {
        permOverwrites.push({ id: guild.members.me.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.EmbedLinks, PermissionFlagsBits.ManageMessages] });
      }
      permOverwrites.push({ id: mechanicId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });
      for (const rid of [...srid(config?.owner_role_id), ...srid(config?.head_manager_role_id), ...srid(config?.manager_role_id), ...srid(config?.trainer_role_id)]) {
        permOverwrites.push({ id: rid, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });
      }
      // Individual staff from DB
      try {
        const staffRows = await db.execute("SELECT discord_id FROM user_roles WHERE role IN ('owner','manager','trainer')");
        for (const row of staffRows.rows) {
          const uid = String(row[0]);
          if (!uid || uid === mechanicId) continue;
          try { await guild.members.fetch(uid); permOverwrites.push({ id: uid, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] }); } catch { /* not in server */ }
        }
      } catch { /* ignore */ }

      let channel: TextChannel;
      try {
        channel = await guild.channels.create({
          name: channelName,
          type: ChannelType.GuildText,
          parent: categoryId,
          topic: `📍 Personal sales channel — ${profile.display_name}`,
          permissionOverwrites: permOverwrites
        }) as TextChannel;
      } catch (err: any) {
        await interaction.editReply({ content: `❌ Failed to create channel: ${err.message}`, embeds: [], components: [] });
        return;
      }

      await db.execute({ sql: "UPDATE profiles SET sales_channel_id = ? WHERE discord_id = ?", args: [channel.id, mechanicId] });
      let newPanelPinned = false;
      try {
        const r2 = await postOrderPanel(channel, mechanicId, profile.display_name, profile.commission_rate);
        newPanelPinned = r2.pinned;
      } catch { /* ignore */ }

      await interaction.editReply({
        content: newPanelPinned
          ? `✅ Sales channel created for **${profile.display_name}** in the selected category: <#${channel.id}>\nThe order panel has been pinned.`
          : `✅ Sales channel created for **${profile.display_name}** in the selected category: <#${channel.id}>\nOrder panel sent — but give the bot **Manage Messages** permission in that channel so it can be pinned.`,
        embeds: [], components: []
      });
    }

    return;
  }

  if (!interaction.isStringSelectMenu()) return;

  // ── Bulk assign by role: mechanic multi-select → pick manager ─────────────
  if (ns === "admin" && action === "assignbyrole" && rest[0] === "pickmembers") {
    if (!(await requireRole(interaction, "manager"))) return;
    await interaction.deferUpdate();
    const selectedIds = interaction.values;
    const pendingKey = `pending_bulk_assign_${interaction.user.id}`;
    await setSetting(pendingKey, selectedIds.join(","));

    const names = (await Promise.all(selectedIds.map(id => getProfile(id))))
      .map((p, i) => p?.display_name ?? `<@${selectedIds[i]}>`)
      .join(", ");

    const embed = new EmbedBuilder()
      .setTitle("🔩  Assign by Role — Step 3")
      .setColor(COLORS.dark)
      .setDescription(
        `**${selectedIds.length}** mechanic(s) selected:\n${names}\n\n` +
        "Now pick the **manager** to assign them all to."
      )
      .setFooter({ text: FOOTER });

    const managerSelect = new ActionRowBuilder<UserSelectMenuBuilder>().addComponents(
      new UserSelectMenuBuilder()
        .setCustomId("admin:assignbyrole:pickmanager")
        .setPlaceholder("Pick a manager...")
        .setMinValues(1).setMaxValues(1)
    );
    await interaction.editReply({ embeds: [embed], components: [managerSelect] });
    return;
  }

  // ── Remove item from order ─────────────────────────────────────────────────
  if (ns === "order" && action === "removeitem") {
    const orderId = await resolveDraftId(interaction, extra);
    await withOrderLock(orderId, async () => {
    const r = await db.execute({ sql: "SELECT * FROM orders WHERE id = ?", args: [orderId] });
    if (!r.rows[0]) { await ephemeralNotice(interaction, "⚠️ That order no longer exists."); return; }
    const order = rowToOrder(r.rows[0]);
    const currentItems: any[] = order.items ?? [];

    const indicesToRemove = new Set(interaction.values.map(v => parseInt(v, 10)));
    const removed   = currentItems.filter((_: any, idx: number) => indicesToRemove.has(idx));
    const remaining = currentItems.filter((_: any, idx: number) => !indicesToRemove.has(idx));

    // Use delta approach so any manual labour adjustment is preserved
    const removedPartsCost = removed.reduce((s: number, i: any) => s + (i.cost ?? 0), 0);
    const removedLabour    = removed.reduce((s: number, i: any) => s + (i.labour ?? 0), 0);
    const newPartsCost = Math.max(0, order.parts_cost - removedPartsCost);
    const newLabour    = Math.max(0, order.labour    - removedLabour);
    const newTotal     = newPartsCost + newLabour;

    await db.execute({
      sql: "UPDATE orders SET items = ?, parts_cost = ?, labour = ?, total = ? WHERE id = ?",
      args: [JSON.stringify(remaining), newPartsCost, newLabour, newTotal, orderId]
    });

    const updated = { ...order, items: remaining, parts_cost: newPartsCost, labour: newLabour, total: newTotal };
    const guildId = interaction.guildId ?? "";
    const commData = await getCommissionData(updated.mechanic_id, guildId, updated.role_level);
    const crewCutInfo = ["trainer","manager","owner"].includes(updated.role_level)
      ? { amount: commData.crewCut, rate: commData.crewCutRate, label: commData.crewCutLabel }
      : undefined;

    const catalogStr = await getSetting("parts_catalog");
    const catalog = JSON.parse(catalogStr ?? "{}");
    const categories: string[] = catalog.categories ?? [];
    const catSelect = new StringSelectMenuBuilder()
      .setCustomId(`order:selectcategory:${orderId}`)
      .setPlaceholder("Add more services...")
      .addOptions(categories.map(c => new StringSelectMenuOptionBuilder().setLabel(c).setValue(c)));

    await safeUpdate(interaction, {
      content: `✅ Removed ${indicesToRemove.size} item(s) from the order.`,
      embeds: [buildDraftEmbed(updated, commData.weekCommission, commData.rate, crewCutInfo)],
      components: [
        new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(catSelect),
        ...mainDraftButtonRows(orderId)
      ]
    });
    });
    return;
  }

  // ── Select category → show items ───────────────────────────────────────────
  if (ns === "order" && action === "selectcategory") {
    const orderId = await resolveDraftId(interaction, extra);
    await withOrderLock(orderId, async () => {
    const category = interaction.values[0];
    const catalogStr = await getSetting("parts_catalog");
    const catalog = JSON.parse(catalogStr ?? "{}");
    const items: { label: string; category: string; price: number; cost: number; labour: number }[] = catalog.items ?? [];
    const catItems = items.filter(i => i.category === category);
    if (!catItems.length) { await ephemeralNotice(interaction, `No items in **${category}**.`); return; }

    const r = await db.execute({ sql: "SELECT * FROM orders WHERE id = ?", args: [orderId] });
    if (!r.rows[0]) { await ephemeralNotice(interaction, "⚠️ That order no longer exists."); return; }
    const order = rowToOrder(r.rows[0]);
    const guildId2 = interaction.guildId ?? "";
    const commData2 = await getCommissionData(order.mechanic_id, guildId2, order.role_level);
    const crewCutInfo2 = ["trainer","manager","owner"].includes(order.role_level)
      ? { amount: commData2.crewCut, rate: commData2.crewCutRate, label: commData2.crewCutLabel }
      : undefined;

    // Mark already-added items so user can see what's on the order
    const existingLabels = new Set((order.items ?? []).map((i: any) => `${i.category}::${i.label}`));

    const itemSelect = new StringSelectMenuBuilder()
      .setCustomId(`order:selectitem:${orderId}:${category}`)
      .setPlaceholder(`Select from ${category}...`)
      .setMinValues(1)
      .setMaxValues(Math.min(catItems.length, 10))
      .addOptions(catItems.map(i => {
        const alreadyAdded = existingLabels.has(`${i.category}::${i.label}`);
        return new StringSelectMenuOptionBuilder()
          .setLabel(alreadyAdded ? `✓ ${i.label}` : i.label)
          .setValue(i.label)
          .setDescription(`Parts: ${money(i.cost)} | Labour: ${money(i.labour)} | Total: ${money(i.price)}${alreadyAdded ? " · already added" : ""}`);
      }));

    const embed = buildDraftEmbed(order, commData2.weekCommission, commData2.rate, crewCutInfo2);
    embed.setTitle(`📝  DRAFT  ·  ${order.order_number}  ·  ${category}`);

    await safeUpdate(interaction, {
      embeds: [embed],
      components: [
        new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(itemSelect),
        categoryViewButtonRow(orderId)
      ]
    });
    });
    return;
  }

  // ── Select specific items ──────────────────────────────────────────────────
  if (ns === "order" && action === "selectitem") {
    const orderId = await resolveDraftId(interaction, extra.split(":")[0]);
    await withOrderLock(orderId, async () => {
    const category = extra.split(":").slice(1).join(":");
    const catalogStr = await getSetting("parts_catalog");
    const catalog = JSON.parse(catalogStr ?? "{}");
    const allItems: { label: string; category: string; price: number; cost: number; labour: number }[] = catalog.items ?? [];
    const r = await db.execute({ sql: "SELECT * FROM orders WHERE id = ?", args: [orderId] });
    if (!r.rows[0]) { await ephemeralNotice(interaction, "⚠️ That order no longer exists."); return; }
    const order = rowToOrder(r.rows[0]);
    const currentItems: any[] = order.items ?? [];

    const existingKeys = new Set(currentItems.map((i: any) => `${i.category}::${i.label}`));
    const newItems = interaction.values.map(label => {
      const found = allItems.find(i => i.label === label && i.category === category);
      if (!found) return null;
      const key = `${found.category}::${found.label}`;
      if (existingKeys.has(key)) return null;
      existingKeys.add(key);
      return { label: found.label, price: found.price, cost: found.cost, labour: found.labour, category: found.category };
    }).filter(Boolean);

    if (!newItems.length) {
      await ephemeralNotice(interaction, "⚠️ All selected items are already on this order. Use **🗑️ Remove** to remove them first.");
      return;
    }

    const merged = [...currentItems, ...newItems];
    // Use delta approach so any manual labour adjustment (from ✏️ Labour modal) is preserved
    const addedPartsCost = (newItems as any[]).reduce((s, i) => s + (i.cost ?? 0), 0);
    const addedLabour    = (newItems as any[]).reduce((s, i) => s + (i.labour ?? 0), 0);
    const newPartsCost = order.parts_cost + addedPartsCost;
    const newLabour    = order.labour + addedLabour;
    const newTotal     = newPartsCost + newLabour;

    await db.execute({
      sql: "UPDATE orders SET items = ?, parts_cost = ?, labour = ?, total = ? WHERE id = ?",
      args: [JSON.stringify(merged), newPartsCost, newLabour, newTotal, orderId]
    });

    const updated = { ...order, items: merged, parts_cost: newPartsCost, labour: newLabour, total: newTotal };
    const guildId3 = interaction.guildId ?? "";
    const commData3 = await getCommissionData(updated.mechanic_id, guildId3, updated.role_level);
    const crewCutInfo3 = ["trainer","manager","owner"].includes(updated.role_level)
      ? { amount: commData3.crewCut, rate: commData3.crewCutRate, label: commData3.crewCutLabel }
      : undefined;

    const categories: string[] = catalog.categories ?? [];
    const catSelect = new StringSelectMenuBuilder()
      .setCustomId(`order:selectcategory:${orderId}`)
      .setPlaceholder("Add more services...")
      .addOptions(categories.map(cat => new StringSelectMenuOptionBuilder().setLabel(cat).setValue(cat)));

    const addedNames = (newItems as any[]).map(i => i.label).join(", ");
    await safeUpdate(interaction, {
      content: `✅ Added: **${addedNames}**`,
      embeds: [buildDraftEmbed(updated, commData3.weekCommission, commData3.rate, crewCutInfo3)],
      components: [
        new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(catSelect),
        ...mainDraftButtonRows(orderId)
      ]
    });
    });
    return;
  }
}
