import {
  ButtonInteraction, MessageFlags,
  ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder,
  ButtonBuilder, ButtonStyle,
  ModalBuilder, TextInputBuilder, TextInputStyle
} from "discord.js";
import { db, getProfile, getSetting, rowToOrder, getGuildConfig, nextOrderNumber } from "../db.js";
import { requireRole, detectUserRoleLevel } from "../lib/roles.js";
import { buildOrderEmbed, buildDraftEmbed, buildClockInPromptEmbed, COLORS, money } from "../lib/embeds.js";
import { randomUUID } from "../lib/utils.js";
import { logEvent, logError } from "../lib/eventLog.js";
import { safeUpdate, ephemeralNotice } from "../lib/resilience.js";
import { resolveDraftId } from "../lib/draftRecovery.js";
import { buildCompletedOrderRow } from "./orderpanel.js";
import { isUpdateEnabled } from "../lib/featureFlags.js";
import { payrollRateForRole } from "../lib/payrollPolicy.js";

// Use completed_at so orders started before a reset but finished after it still count toward
// the current pay period. Fall back to created_at for older rows that lack completed_at.
// Both sides are wrapped in datetime() so SQLite normalises ISO-8601 and YYYY-MM-DD HH:MM:SS
// strings to the same format before comparing — prevents lexical mis-ordering.
const SINCE_RESET_SQL =
  `datetime(COALESCE(completed_at, created_at)) >= datetime(COALESCE((SELECT value FROM app_settings WHERE key = 'order_number_reset_ts'), '2000-01-01'))`;

const DONE_STATUSES = `status IN ('complete', 'approved', 'paid')`;

/**
 * Central commission helper — call once per view refresh.
 * roleLevel: 'mechanic' | 'trainer' | 'manager' | 'owner'
 */
export async function getCommissionData(userId: string, guildId: string, roleLevel: string) {
  const [profile, config] = await Promise.all([
    getProfile(userId),
    getGuildConfig(guildId)
  ]);
  const updateEnabled = await isUpdateEnabled();
  // Mechanics default to 30%; managers/trainers/owners default to 40%
  const defaultRate = roleLevel === "mechanic" ? 0.3 : 0.4;
  const rate = updateEnabled
    ? payrollRateForRole(roleLevel).commissionRate
    : profile?.commission_rate ?? defaultRate;

  const weekLabourR = await db.execute({
    sql: `SELECT COALESCE(SUM(labour), 0) FROM orders WHERE mechanic_id = ? AND ${DONE_STATUSES} AND COALESCE(is_own_car, 0) = 0 AND ${SINCE_RESET_SQL}`,
    args: [userId]
  });
  const totalLabour = Number(weekLabourR.rows[0]?.[0] ?? 0);
  const commAdj     = profile?.commission_adjustment ?? 0;
  const snapshot    = profile?.commission_labour_snapshot ?? 0;

  // How commission works:
  // - If no setpay has been run (commAdj = 0): weekCommission = totalLabour × rate
  // - If setpay was run: weekCommission = commAdj + (labour earned AFTER setpay) × rate
  //   The snapshot captures the labour total at setpay time, so new orders add on top.
  const labourAfterSetpay = Math.max(0, totalLabour - snapshot);
  const weekCommission    = commAdj > 0
    ? commAdj + labourAfterSetpay * rate
    : totalLabour * rate;

  let crewCut = 0;
  let crewCutRate = 0;
  let crewCutLabel = "";

  // Only managers/owners get a crew cut — trainer crew cut is removed
  if (roleLevel === "manager" || roleLevel === "owner") {
    crewCutRate = updateEnabled
      ? payrollRateForRole(roleLevel).crewCutRate
      : profile?.manager_override_rate ?? config?.manager_crew_rate ?? 0.20;
    const r = await db.execute({
      sql: `SELECT COALESCE(SUM(labour), 0) FROM orders WHERE ${DONE_STATUSES} AND COALESCE(is_own_car, 0) = 0 AND ${SINCE_RESET_SQL} AND mechanic_id != ? AND role_level IN ('mechanic', 'trainer')`,
      args: [userId]
    });
    const totalCrewLabour    = Number(r.rows[0]?.[0] ?? 0);
    const manualBonus        = profile?.manager_cut_adjustment ?? 0;
    const managerSnapshot    = profile?.manager_labour_snapshot ?? 0;
    const crewLabourAfterSet = Math.max(0, totalCrewLabour - managerSnapshot);
    // If a manual bonus was set: bonus + (crew labour AFTER setpay) × rate
    // Otherwise: totalCrewLabour × rate
    crewCut      = manualBonus > 0
      ? manualBonus + crewLabourAfterSet * crewCutRate
      : totalCrewLabour * crewCutRate;
    crewCutLabel = "Manager Cut";
  }

  return { rate, weekCommission, crewCut, crewCutRate, crewCutLabel };
}

// ─── Shared button row builders ───────────────────────────────────────────────

function mainDraftButtonRows(orderId: string): ActionRowBuilder<ButtonBuilder>[] {
  return [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId(`order:bikeperf:${orderId}`).setLabel("🏍️ Bike Perf").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`order:bikemaxpack:${orderId}`).setLabel("🏍️ Bike Max Pack").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`order:carperf:${orderId}`).setLabel("🚗 Car Perf").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`order:carmaxpack:${orderId}`).setLabel("🚗 Car Max Pack").setStyle(ButtonStyle.Primary),
    ),
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId(`order:editlabour:${orderId}`).setLabel("✏️ Labour").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`order:extras:${orderId}`).setLabel("🩸 Body Parts").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`order:removeitems:${orderId}`).setLabel("🗑️ Remove").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`order:discount:${orderId}`).setLabel("💲 Discount").setStyle(ButtonStyle.Secondary),
    ),
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId(`order:settotal:${orderId}`).setLabel("💰 Set Total").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`order:submit:${orderId}`).setLabel("✅ Complete Order").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`order:cancel:${orderId}`).setLabel("✕ Cancel").setStyle(ButtonStyle.Danger)
    )
  ];
}

function categoryViewButtonRow(orderId: string): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`order:backtocats:${orderId}`).setLabel("← Back").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`order:editlabour:${orderId}`).setLabel("✏️ Labour").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`order:submit:${orderId}`).setLabel("✅ Complete Order").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`order:cancel:${orderId}`).setLabel("✕ Cancel").setStyle(ButtonStyle.Danger)
  );
}

export { mainDraftButtonRows, categoryViewButtonRow };

export async function handleDraftButton(interaction: ButtonInteraction): Promise<boolean> {
  const [ns, action, ...rest] = interaction.customId.split(":");
  let orderId = rest.join(":");

  // ── "Create New Order" button from pinned panel ────────────────────────────
  // Show customer name modal FIRST — showModal must be the very first response (no defer before it)
  if (ns === "order" && action === "newpanel") {
    const modal = new ModalBuilder()
      .setCustomId("order:startorder")
      .setTitle("📋  New Order — Customer Name");
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("customer_name")
          .setLabel("Customer Name")
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMinLength(1)
          .setMaxLength(100)
          .setPlaceholder("e.g. John Smith")
      )
    );
    await interaction.showModal(modal);
    return true;
  }

  if (ns === "order" && action === "owncar") {
    if (!(await isUpdateEnabled())) {
      await interaction.reply({ content: "The update has not been activated yet.", flags: MessageFlags.Ephemeral });
      return true;
    }
    if (!(await requireRole(interaction, "mechanic"))) return true;
    const restrictions = await db.execute({
      sql: "SELECT terminated_at, order_hold_until FROM profiles WHERE discord_id = ?",
      args: [interaction.user.id],
    });
    const terminated = Boolean(restrictions.rows[0]?.[0]);
    const holdUntil = restrictions.rows[0]?.[1] ? new Date(`${String(restrictions.rows[0][1]).replace(" ", "T")}Z`).getTime() : 0;
    if (terminated || holdUntil > Date.now()) {
      await interaction.reply({
        content: terminated
          ? "Your shop profile is inactive, so you cannot start an order."
          : `You are on an order hold until <t:${Math.floor(holdUntil / 1000)}:F>.`,
        flags: MessageFlags.Ephemeral,
      });
      return true;
    }
    const modal = new ModalBuilder()
      .setCustomId("order:startowncar")
      .setTitle("🚗  Your Own Car");
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("customer_name")
          .setLabel("Your name")
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMinLength(1)
          .setMaxLength(100)
          .setPlaceholder("Name for the order record")
      )
    );
    await interaction.showModal(modal);
    return true;
  }

  if (ns !== "order") return false;

  // If this panel's draft is gone (restart, reset, stale panel, ...) resume the
  // user's open draft or start a fresh one instead of dead-ending on every click.
  if (action !== "cancel" && action !== "newpanel" && action !== "owncar") {
    orderId = await resolveDraftId(interaction, orderId);
  }

  // ── Back to categories ──────────────────────────────────────────────────────
  if (action === "backtocats") {
    await interaction.deferUpdate();
    const [catalogStr, r] = await Promise.all([
      getSetting("parts_catalog"),
      db.execute({ sql: "SELECT * FROM orders WHERE id = ?", args: [orderId] })
    ]);
    if (!r.rows[0]) return true;
    const order = rowToOrder(r.rows[0]);
    const guildId = interaction.guildId ?? "";
    const commData = await getCommissionData(order.mechanic_id, guildId, order.role_level);
    const catalog = JSON.parse(catalogStr ?? "{}");
    const categories: string[] = catalog.categories ?? [];

    if (categories.length === 0) {
      await interaction.editReply({ content: "⚠️ No service catalog is set up yet. Ask a manager to configure it with `/settings`." });
      return true;
    }

    const catSelect = new StringSelectMenuBuilder()
      .setCustomId(`order:selectcategory:${orderId}`)
      .setPlaceholder("Add more services...")
      .addOptions(categories.map(c => new StringSelectMenuOptionBuilder().setLabel(c).setValue(c)));

    const crewCutInfo = commData.crewCut > 0 || ["trainer","manager","owner"].includes(order.role_level)
      ? { amount: commData.crewCut, rate: commData.crewCutRate, label: commData.crewCutLabel }
      : undefined;

    await interaction.editReply({
      embeds: [buildDraftEmbed(order, commData.weekCommission, commData.rate, crewCutInfo)],
      components: [
        new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(catSelect),
        ...mainDraftButtonRows(orderId)
      ]
    });
    return true;
  }

  // ── Remove Items — show current order items as a select ────────────────────
  if (action === "removeitems") {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    const r = await db.execute({ sql: "SELECT items FROM orders WHERE id = ?", args: [orderId] });
    if (!r.rows[0]) return true;
    const items: any[] = JSON.parse(String(r.rows[0][0] ?? "[]"));
    if (!items.length) {
      await interaction.editReply({ content: "ℹ️ No items on this order to remove." });
      return true;
    }

    const removeSelect = new StringSelectMenuBuilder()
      .setCustomId(`order:removeitem:${orderId}`)
      .setPlaceholder("Select items to remove...")
      .setMinValues(1)
      .setMaxValues(Math.min(items.length, 10))
      .addOptions(items.map((item: any, idx: number) =>
        new StringSelectMenuOptionBuilder()
          .setLabel(`${item.label} (${item.category})`)
          .setValue(String(idx))
          .setDescription(`${money(item.price)}`)
      ));

    await interaction.editReply({
      content: "Select which items to remove from the order:",
      components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(removeSelect)]
    });
    return true;
  }

  // ── Package apply helper ───────────────────────────────────────────────────
  async function applyPackage(pkgItems: any[], label: string, breakdown: string) {
    const r = await db.execute({ sql: "SELECT * FROM orders WHERE id = ?", args: [orderId] });
    if (!r.rows[0]) { await ephemeralNotice(interaction, "⚠️ That order no longer exists."); return; }
    const existing = rowToOrder(r.rows[0]);
    // Replace entire order with the package items
    const newPartsCost = pkgItems.reduce((s: number, i: any) => s + (i.cost ?? 0), 0);
    const newLabour    = pkgItems.reduce((s: number, i: any) => s + (i.labour ?? 0), 0);
    const newTotal     = pkgItems.reduce((s: number, i: any) => s + (i.price ?? 0), 0);
    await db.execute({
      sql: "UPDATE orders SET items = ?, parts_cost = ?, labour = ?, total = ? WHERE id = ?",
      args: [JSON.stringify(pkgItems), newPartsCost, newLabour, newTotal, orderId]
    });
    const catalogStr = await getSetting("parts_catalog");
    const updated = { ...existing, items: pkgItems, parts_cost: newPartsCost, labour: newLabour, total: newTotal };
    const guildId = interaction.guildId ?? "";
    const commData = await getCommissionData(updated.mechanic_id, guildId, updated.role_level);
    const crewCutInfo = ["trainer","manager","owner"].includes(updated.role_level)
      ? { amount: commData.crewCut, rate: commData.crewCutRate, label: commData.crewCutLabel }
      : undefined;
    const catalog = JSON.parse(catalogStr ?? "{}");
    const cats: string[] = Array.isArray(catalog.categories) && catalog.categories.length > 0
      ? catalog.categories : [];
    const components = cats.length > 0
      ? [
          new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
            new StringSelectMenuBuilder()
              .setCustomId(`order:selectcategory:${orderId}`)
              .setPlaceholder("Add more services...")
              .addOptions(cats.map((c: string) => new StringSelectMenuOptionBuilder().setLabel(c).setValue(c)))
          ),
          ...mainDraftButtonRows(orderId)
        ]
      : mainDraftButtonRows(orderId);
    await safeUpdate(interaction, {
      embeds: [buildDraftEmbed(updated, commData.weekCommission, commData.rate, crewCutInfo)],
      components
    });
    const totalFmt = `$${newTotal.toLocaleString("en-US")}`;
    const labourFmt = `$${newLabour.toLocaleString("en-US")}`;
    await interaction.followUp({
      flags: MessageFlags.Ephemeral,
      content: `**${label} applied! (${totalFmt})**\n\n${breakdown}\n\n**Total: ${totalFmt}** · Labour: ${labourFmt}`
    });
  }

  // ── 🏍️ Bike Performance ────────────────────────────────────────────────────
  // No suspension — bikes don't have it. Includes Primary + Secondary respray.
  if (action === "bikeperf") {
    const BIKE_PERF = [
      { label: "Engine 4",        category: "Performance",   price: 70000, cost: 40000, labour: 30000 },
      { label: "Turbo",           category: "Performance",   price: 40000, cost: 10000, labour: 30000 },
      { label: "Transmission 3",  category: "Performance",   price: 26300, cost: 15000, labour: 11300 },
      { label: "Brakes 3",        category: "Performance",   price: 16900, cost:  7500, labour:  9400 },
      { label: "Primary Color",   category: "Visual & Body", price: 11500, cost:  1000, labour: 10500 },
      { label: "Secondary Color", category: "Visual & Body", price: 11500, cost:  1000, labour: 10500 },
    ];
    await applyPackage(
      BIKE_PERF,
      "🏍️ Bike Performance",
      "**⚡ Performance (No Suspension)**\n" +
      "> 🔧 Engine 4 — $70,000\n" +
      "> 💨 Turbo — $40,000\n" +
      "> ⚙️ Transmission 3 — $26,300\n" +
      "> 🛑 Brakes 3 — $16,900\n\n" +
      "**🎨 Resprays**\n" +
      "> 🖌️ Primary Color — $11,500\n" +
      "> 🖌️ Secondary Color — $11,500"
    );
    return true;
  }

  // ── 🏍️ Bike Max Package ────────────────────────────────────────────────────
  // No suspension. Max performance + all resprays + xenon + underglow + tire smoke + wheels + 6 body parts.
  // Extra body parts beyond 6 can be added via the 🩸 Body Parts button ($2k each).
  if (action === "bikemaxpack") {
    const BODY_PART = { cost: 500, labour: 1500, price: 2000 };
    const BIKE_MAX = [
      { label: "Engine 4",        category: "Performance",    price: 70000, cost: 40000, labour: 30000 },
      { label: "Turbo",           category: "Performance",    price: 40000, cost: 10000, labour: 30000 },
      { label: "Transmission 3",  category: "Performance",    price: 26300, cost: 15000, labour: 11300 },
      { label: "Brakes 3",        category: "Performance",    price: 16900, cost:  7500, labour:  9400 },
      { label: "Primary Color",   category: "Visual & Body",  price: 11500, cost:  1000, labour: 10500 },
      { label: "Secondary Color", category: "Visual & Body",  price: 11500, cost:  1000, labour: 10500 },
      { label: "Pearlescent",     category: "Visual & Body",  price: 11500, cost:  1000, labour: 10500 },
      { label: "Xenon Lighting",  category: "Neon & Lighting",price:  2100, cost:  1000, labour:  1100 },
      { label: "Neon Front",      category: "Neon & Lighting",price:  1000, cost:   250, labour:   750 },
      { label: "Neon Back",       category: "Neon & Lighting",price:  1000, cost:   250, labour:   750 },
      { label: "Neon Left",       category: "Neon & Lighting",price:  1000, cost:   250, labour:   750 },
      { label: "Neon Right",      category: "Neon & Lighting",price:  1000, cost:   250, labour:   750 },
      { label: "Tire Smoke",      category: "Extras",         price:  4000, cost:  1000, labour:  3000 },
      { label: "Wheels",          category: "Extras",         price:  3900, cost:   500, labour:  3400 },
      // 6 included body part cosmetics
      { label: "Body Part 1",     category: "Visual & Body",  price: BODY_PART.price, cost: BODY_PART.cost, labour: BODY_PART.labour },
      { label: "Body Part 2",     category: "Visual & Body",  price: BODY_PART.price, cost: BODY_PART.cost, labour: BODY_PART.labour },
      { label: "Body Part 3",     category: "Visual & Body",  price: BODY_PART.price, cost: BODY_PART.cost, labour: BODY_PART.labour },
      { label: "Body Part 4",     category: "Visual & Body",  price: BODY_PART.price, cost: BODY_PART.cost, labour: BODY_PART.labour },
      { label: "Body Part 5",     category: "Visual & Body",  price: BODY_PART.price, cost: BODY_PART.cost, labour: BODY_PART.labour },
      { label: "Body Part 6",     category: "Visual & Body",  price: BODY_PART.price, cost: BODY_PART.cost, labour: BODY_PART.labour },
    ];
    await applyPackage(
      BIKE_MAX,
      "🏍️ Bike Max Package",
      "**⚡ Performance (No Suspension)**\n" +
      "> 🔧 Engine 4 — $70,000\n" +
      "> 💨 Turbo — $40,000\n" +
      "> ⚙️ Transmission 3 — $26,300\n" +
      "> 🛑 Brakes 3 — $16,900\n\n" +
      "**🎨 All Resprays**\n" +
      "> 🖌️ Primary Color — $11,500\n" +
      "> 🖌️ Secondary Color — $11,500\n" +
      "> ✨ Pearlescent — $11,500\n\n" +
      "**💡 Lighting & Underglow**\n" +
      "> 💡 Xenon Lighting — $2,100\n" +
      "> 🔴 Neon Front — $1,000\n" +
      "> 🔴 Neon Back — $1,000\n" +
      "> 🔴 Neon Left — $1,000\n" +
      "> 🔴 Neon Right — $1,000\n\n" +
      "**🎆 Extras**\n" +
      "> 💨 Tire Smoke — $4,000\n" +
      "> 🛞 Wheels — $3,900\n\n" +
      "**🩸 6 Body Parts included** (add more via 🩸 Body Parts — $2,000 each)"
    );
    return true;
  }

  // ── 🚗 Car Performance ─────────────────────────────────────────────────────
  // Full max performance including suspension.
  if (action === "carperf") {
    const CAR_PERF = [
      { label: "Engine 4",       category: "Performance", price: 70000, cost: 40000, labour: 30000 },
      { label: "Turbo",          category: "Performance", price: 40000, cost: 10000, labour: 30000 },
      { label: "Suspension 4",   category: "Performance", price: 21000, cost: 12000, labour:  9000 },
      { label: "Transmission 3", category: "Performance", price: 26300, cost: 15000, labour: 11300 },
      { label: "Brakes 3",       category: "Performance", price: 16900, cost:  7500, labour:  9400 },
    ];
    await applyPackage(
      CAR_PERF,
      "🚗 Car Performance",
      "**⚡ Performance**\n" +
      "> 🔧 Engine 4 — $70,000\n" +
      "> 💨 Turbo — $40,000\n" +
      "> 🌀 Suspension 4 — $21,000\n" +
      "> ⚙️ Transmission 3 — $26,300\n" +
      "> 🛑 Brakes 3 — $16,900"
    );
    return true;
  }

  // ── 🚗 Car Max Package ─────────────────────────────────────────────────────
  // Full performance (with suspension) + all resprays + xenon + underglow + tire smoke + wheels + 6 body parts.
  // Extra body parts beyond 6 can be added via the 🩸 Body Parts button ($2k each).
  if (action === "carmaxpack") {
    const BODY_PART = { cost: 500, labour: 1500, price: 2000 };
    const CAR_MAX = [
      { label: "Engine 4",        category: "Performance",    price: 70000, cost: 40000, labour: 30000 },
      { label: "Turbo",           category: "Performance",    price: 40000, cost: 10000, labour: 30000 },
      { label: "Suspension 4",    category: "Performance",    price: 21000, cost: 12000, labour:  9000 },
      { label: "Transmission 3",  category: "Performance",    price: 26300, cost: 15000, labour: 11300 },
      { label: "Brakes 3",        category: "Performance",    price: 16900, cost:  7500, labour:  9400 },
      { label: "Primary Color",   category: "Visual & Body",  price: 11500, cost:  1000, labour: 10500 },
      { label: "Secondary Color", category: "Visual & Body",  price: 11500, cost:  1000, labour: 10500 },
      { label: "Pearlescent",     category: "Visual & Body",  price: 11500, cost:  1000, labour: 10500 },
      { label: "Xenon Lighting",  category: "Neon & Lighting",price:  2100, cost:  1000, labour:  1100 },
      { label: "Neon Front",      category: "Neon & Lighting",price:  1000, cost:   250, labour:   750 },
      { label: "Neon Back",       category: "Neon & Lighting",price:  1000, cost:   250, labour:   750 },
      { label: "Neon Left",       category: "Neon & Lighting",price:  1000, cost:   250, labour:   750 },
      { label: "Neon Right",      category: "Neon & Lighting",price:  1000, cost:   250, labour:   750 },
      { label: "Tire Smoke",      category: "Extras",         price:  4000, cost:  1000, labour:  3000 },
      { label: "Wheels",          category: "Extras",         price:  3900, cost:   500, labour:  3400 },
      // 6 included body part cosmetics
      { label: "Body Part 1",     category: "Visual & Body",  price: BODY_PART.price, cost: BODY_PART.cost, labour: BODY_PART.labour },
      { label: "Body Part 2",     category: "Visual & Body",  price: BODY_PART.price, cost: BODY_PART.cost, labour: BODY_PART.labour },
      { label: "Body Part 3",     category: "Visual & Body",  price: BODY_PART.price, cost: BODY_PART.cost, labour: BODY_PART.labour },
      { label: "Body Part 4",     category: "Visual & Body",  price: BODY_PART.price, cost: BODY_PART.cost, labour: BODY_PART.labour },
      { label: "Body Part 5",     category: "Visual & Body",  price: BODY_PART.price, cost: BODY_PART.cost, labour: BODY_PART.labour },
      { label: "Body Part 6",     category: "Visual & Body",  price: BODY_PART.price, cost: BODY_PART.cost, labour: BODY_PART.labour },
    ];
    await applyPackage(
      CAR_MAX,
      "🚗 Car Max Package",
      "**⚡ Performance**\n" +
      "> 🔧 Engine 4 — $70,000\n" +
      "> 💨 Turbo — $40,000\n" +
      "> 🌀 Suspension 4 — $21,000\n" +
      "> ⚙️ Transmission 3 — $26,300\n" +
      "> 🛑 Brakes 3 — $16,900\n\n" +
      "**🎨 All Resprays**\n" +
      "> 🖌️ Primary Color — $11,500\n" +
      "> 🖌️ Secondary Color — $11,500\n" +
      "> ✨ Pearlescent — $11,500\n\n" +
      "**💡 Lighting & Underglow**\n" +
      "> 💡 Xenon Lighting — $2,100\n" +
      "> 🔴 Neon Front — $1,000\n" +
      "> 🔴 Neon Back — $1,000\n" +
      "> 🔴 Neon Left — $1,000\n" +
      "> 🔴 Neon Right — $1,000\n\n" +
      "**🎆 Extras**\n" +
      "> 💨 Tire Smoke — $4,000\n" +
      "> 🛞 Wheels — $3,900\n\n" +
      "**🩸 6 Body Parts included** (add more via 🩸 Body Parts — $2,000 each)"
    );
    return true;
  }

  // ── Discount modal ────────────────────────────────────────────────────────
  if (action === "discount") {
    const modal = new ModalBuilder()
      .setCustomId(`order:applydiscount:${orderId}`)
      .setTitle("💲 Apply Discount");
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("percent")
          .setLabel("Discount % (1 – 100)")
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setPlaceholder("e.g. 10  for a 10% discount")
      )
    );
    await interaction.showModal(modal);
    return true;
  }

  // ── Body Parts modal ────────────────────────────────────────────────────────
  if (action === "extras") {
    const modal = new ModalBuilder()
      .setCustomId(`order:addextras:${orderId}`)
      .setTitle("🩸 Add Body Parts");
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("quantity")
          .setLabel("How many body parts? (each = $2,000)")
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setPlaceholder("e.g. 3")
      )
    );
    await interaction.showModal(modal);
    return true;
  }

  // ── Set Customer Total modal ────────────────────────────────────────────────
  if (action === "settotal") {
    const totalR = await db.execute({ sql: "SELECT total, customer_total_override FROM orders WHERE id = ?", args: [orderId] });
    if (!totalR.rows[0]) return true;
    const currentDisplay = totalR.rows[0][1] != null ? Number(totalR.rows[0][1]) : Number(totalR.rows[0][0] ?? 0);
    const modal = new ModalBuilder()
      .setCustomId(`order:applytotal:${orderId}`)
      .setTitle("💰 Set Customer Total");
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("amount")
          .setLabel("Customer total (0 to reset to calculated)")
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setPlaceholder(`Current: ${currentDisplay.toLocaleString("en-US")}`)
      )
    );
    await interaction.showModal(modal);
    return true;
  }

  // ── Edit Labour modal ───────────────────────────────────────────────────────
  if (action === "editlabour") {
    const modal = new ModalBuilder().setCustomId(`order:setlabour:${orderId}`).setTitle("Edit Labour Amount");
    modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("labour")
        .setLabel("Labour amount (e.g. 15000)")
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder("Enter custom labour amount...")
    ));
    await interaction.showModal(modal);
    return true;
  }

  // ── Complete Order ──────────────────────────────────────────────────────────
  if (action === "submit") {
    // Customer name is required — check BEFORE any defer (showModal must be first response)
    const nameR = await db.execute({ sql: "SELECT customer_name FROM orders WHERE id = ?", args: [orderId] });
    if (!nameR.rows[0]) return true;
    const existingCustName = String(nameR.rows[0][0] ?? "").trim();
    if (!existingCustName) {
      const modal = new ModalBuilder()
        .setCustomId(`order:setcustomer:${orderId}`)
        .setTitle("Customer Name Required");
      modal.addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("customer_name")
            .setLabel("Customer Name")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMinLength(1)
            .setMaxLength(100)
            .setPlaceholder("e.g. John Smith")
        )
      );
      await interaction.showModal(modal);
      return true;
    }

    await interaction.deferUpdate();
    if (!(await requireRole(interaction, "mechanic"))) return true;

    const r = await db.execute({ sql: "SELECT * FROM orders WHERE id = ?", args: [orderId] });
    if (!r.rows[0]) return true;
    const order = rowToOrder(r.rows[0]);

    if (!order.items.length) {
      await interaction.followUp({ content: "❌ Add at least one service before completing the order.", flags: MessageFlags.Ephemeral });
      return true;
    }

    // Always use the order's mechanic_id — managers completing orders on behalf
    // of a mechanic should show that mechanic's commission, not the manager's.
    const mechanicId = order.mechanic_id ?? interaction.user.id;
    const mechanicRoleLevel = order.role_level ?? "mechanic";
    const guildId = interaction.guildId ?? "";

    // Fetch commission data BEFORE marking complete so we have the previous
    // baseline + rate. We then compute the final total explicitly — this
    // guarantees the completed embed always matches what the draft was projecting.
    const [profile, prevCommData] = await Promise.all([
      getProfile(mechanicId),
      getCommissionData(mechanicId, guildId, mechanicRoleLevel)
    ]);

    // Only a DRAFT can be completed. This makes a double-tap (or two people
    // pressing Complete at once) harmless instead of posting the order twice.
    const claimed = await db.execute({
      sql: "UPDATE orders SET status = 'complete', completed_at = datetime('now') WHERE id = ? AND status = 'draft'",
      args: [orderId]
    });
    if (!claimed.rowsAffected) {
      await interaction.followUp({ content: "ℹ️ This order was already completed.", flags: MessageFlags.Ephemeral });
      return true;
    }

    const ur = await db.execute({ sql: "SELECT * FROM orders WHERE id = ?", args: [orderId] });
    const completed = rowToOrder(ur.rows[0]);

    // Add this order's cut on top of the previous week total.
    // commission_adjustment is additive, so no special-casing needed.
    const thisOrderCut = completed.is_own_car ? 0 : Math.round(completed.labour * prevCommData.rate);
    const finalWeekCommission = prevCommData.weekCommission + thisOrderCut;

    const crewCutInfo = prevCommData.crewCut > 0 || ["trainer","manager","owner"].includes(mechanicRoleLevel)
      ? { amount: prevCommData.crewCut, rate: prevCommData.crewCutRate, label: prevCommData.crewCutLabel }
      : undefined;

    const embed = buildOrderEmbed(
      completed,
      profile?.display_name ?? "Unknown",
      finalWeekCommission,
      prevCommData.rate,
      crewCutInfo
    );

    const newOrderRow = await buildCompletedOrderRow(mechanicId);

    // Reply to the mechanic FIRST — the channel posts below can be slow
    // (Discord rate limits), so they run after the user already sees "complete".
    const postedTo = profile?.sales_channel_id ?? "";
    await interaction.editReply({
      content: postedTo
        ? `✅ **${completed.order_number}** complete! Posting to <#${postedTo}>`
        : `✅ **${completed.order_number}** complete!\n*Set up a sales channel to auto-post orders.*`,
      embeds: [embed],
      components: []
    });

    const guild = interaction.guild;
    if (guild) {
      const postToSales = async () => {
        if (!profile?.sales_channel_id) return;
        try {
          const ch = await guild.channels.fetch(profile.sales_channel_id);
          if (ch?.isTextBased()) {
            const msg = await (ch as any).send({ embeds: [embed], components: [newOrderRow] });
            await db.execute({ sql: "UPDATE orders SET discord_message_id = ? WHERE id = ?", args: [msg.id, orderId] });
          } else {
            throw new Error("sales channel is not a text channel");
          }
        } catch (err) {
          logError("order-post-sales", err, { guildId, userId: mechanicId, command: "order:submit" });
          await interaction.followUp({ content: `⚠️ **${completed.order_number}** was saved, but I couldn't post it to your sales channel.`, flags: MessageFlags.Ephemeral }).catch(() => {});
        }
      };
      const postToLog = async () => {
        try {
          const gConfig = await getGuildConfig(guildId);
          const logChanId = gConfig?.orders_channel_id ?? gConfig?.log_channel_id;
          if (logChanId && logChanId !== profile?.sales_channel_id) {
            const logCh = await guild.channels.fetch(logChanId).catch(() => null);
            if (logCh?.isTextBased()) await (logCh as any).send({ embeds: [embed] });
          }
        } catch { /* ignore */ }
      };
      await Promise.all([postToSales(), postToLog()]);
    }

    // Log the completion
    logEvent({
      kind: "order_completed",
      guildId: interaction.guildId ?? "",
      userId: mechanicId,
      orderId,
      orderNumber: completed.order_number,
      amount: Math.round(completed.labour),
      detail: `total=${completed.total} parts=${completed.parts_cost}`
    });

    // Fire-and-forget: refresh the pay log panel so it reflects this order immediately
    if (interaction.guild) {
      import("../commands/payall.js")
        .then(m => m.refreshPayLogPanel(interaction.guild!))
        .catch(() => {});
    }

    // Fire-and-forget: refresh leaderboard channel
    if (interaction.guild) {
      const guildSnap = interaction.guild;
      getGuildConfig(guildId).then(async cfg => {
        if (!cfg?.leaderboard_channel_id) return;
        const ch = await guildSnap.channels.fetch(cfg.leaderboard_channel_id).catch(() => null);
        if (ch?.isTextBased()) {
          const { postLeaderboard } = await import("../commands/leaderboard.js");
          postLeaderboard(ch as any).catch(() => {});
        }
      }).catch(() => {});
    }

    return true;
  }

  // ── Cancel ──────────────────────────────────────────────────────────────────
  if (action === "cancel") {
    await interaction.deferUpdate();
    // Fetch order number for the log before deleting
    const cancelR = await db.execute({ sql: "SELECT order_number, mechanic_id FROM orders WHERE id = ?", args: [orderId] });
    await db.execute({ sql: "DELETE FROM orders WHERE id = ?", args: [orderId] });
    if (cancelR.rows[0]) {
      logEvent({
        kind: "order_cancelled",
        guildId: interaction.guildId ?? "",
        userId: String(cancelR.rows[0][1] ?? ""),
        orderId,
        orderNumber: String(cancelR.rows[0][0] ?? "")
      });
    }
    await interaction.editReply({ content: "❌ Order cancelled.", embeds: [], components: [] });
    return true;
  }

  return false;
}
