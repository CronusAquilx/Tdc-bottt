import { createClient } from "@libsql/client";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = process.env.TDC_DATA_DIR?.trim()
  ? path.resolve(process.env.TDC_DATA_DIR.trim())
  : path.join(__dirname, "..", "data");
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_PATH = path.join(DATA_DIR, "tdc.db");
const DB_BACKUP_PATH = path.join(DATA_DIR, "tdc.db.backup");
const DB_PREVIOUS_BACKUP_PATH = path.join(DATA_DIR, "tdc.db.backup.previous");

// If a persistent-disk mount was recreated while the bot was down, recover the
// last completed snapshot before libSQL opens a new empty database file.
function restoreDatabaseSnapshotIfMissing(): void {
  try {
    if (fs.existsSync(DB_PATH) && fs.statSync(DB_PATH).size > 0) return;
    for (const backup of [DB_BACKUP_PATH, DB_PREVIOUS_BACKUP_PATH]) {
      if (fs.existsSync(backup) && fs.statSync(backup).size > 0) {
        fs.copyFileSync(backup, DB_PATH);
        console.warn(`[TDC] ♻️ Restored database from ${path.basename(backup)}`);
        return;
      }
    }
  } catch (err) {
    console.error("[TDC] ❌ Database snapshot restore failed:", err);
  }
}

restoreDatabaseSnapshotIfMissing();

export const db = createClient({
  url: `file:${DB_PATH}`
});

async function exec(sql: string) {
  const statements = sql.split(";").map(s => s.trim()).filter(Boolean);
  for (const stmt of statements) {
    await db.execute(stmt);
  }
}

async function safeAlter(sql: string) {
  try { await db.execute(sql); } catch { /* column already exists */ }
}

const TDC_CATALOG = JSON.stringify({
  categories: ["Vehicle Packages", "Performance", "Repair", "Visual & Body", "Neon & Lighting", "Extras"],
  items: [
    // ── Vehicle Packages ──────────────────────────────────────────────────
    { label: "Bike Performance",             category: "Vehicle Packages", price: 145000, cost: 25000, labour: 120000 },
    { label: "Bike Full Custom + Cosmetics", category: "Vehicle Packages", price: 180000, cost: 20000, labour: 160000 },
    { label: "Car Performance",              category: "Vehicle Packages", price: 175000, cost: 30000, labour: 145000 },
    { label: "Car Full Custom + Cosmetics",  category: "Vehicle Packages", price: 210000, cost: 25000, labour: 185000 },
    // ── Performance (Brakes, Engine, Suspension, Transmission, Turbo) ─────
    { label: "Brakes 1",            category: "Performance",     price: 8100,  cost: 2500,  labour: 5600  },
    { label: "Brakes 2",            category: "Performance",     price: 12500, cost: 5000,  labour: 7500  },
    { label: "Brakes 3",            category: "Performance",     price: 16900, cost: 7500,  labour: 9400  },
    { label: "Engine 1",            category: "Performance",     price: 25000, cost: 10000, labour: 15000 },
    { label: "Engine 2",            category: "Performance",     price: 42500, cost: 20000, labour: 22500 },
    { label: "Engine 3",            category: "Performance",     price: 60000, cost: 30000, labour: 30000 },
    { label: "Engine 4",            category: "Performance",     price: 70000, cost: 40000, labour: 30000 },
    { label: "Suspension 1",        category: "Performance",     price: 5300,  cost: 3000,  labour: 2300  },
    { label: "Suspension 2",        category: "Performance",     price: 10500, cost: 6000,  labour: 4500  },
    { label: "Suspension 3",        category: "Performance",     price: 15800, cost: 9000,  labour: 6800  },
    { label: "Suspension 4",        category: "Performance",     price: 21000, cost: 12000, labour: 9000  },
    { label: "Transmission 1",      category: "Performance",     price: 8800,  cost: 5000,  labour: 3800  },
    { label: "Transmission 2",      category: "Performance",     price: 17500, cost: 10000, labour: 7500  },
    { label: "Transmission 3",      category: "Performance",     price: 26300, cost: 15000, labour: 11300 },
    { label: "Turbo",               category: "Performance",     price: 40000, cost: 10000, labour: 30000 },
    // ── Repair ────────────────────────────────────────────────────────────
    { label: "Full Repair",         category: "Repair",          price: 800,   cost: 100,   labour: 700   },
    // ── Visual & Body ─────────────────────────────────────────────────────
    { label: "Primary Color",       category: "Visual & Body",   price: 11500, cost: 1000,  labour: 10500 },
    { label: "Secondary Color",     category: "Visual & Body",   price: 11500, cost: 1000,  labour: 10500 },
    { label: "Respray Dashboard",   category: "Visual & Body",   price: 11500, cost: 1000,  labour: 10500 },
    { label: "Interior",            category: "Visual & Body",   price: 11500, cost: 1000,  labour: 10500 },
    { label: "Respray (Primary)",   category: "Visual & Body",   price: 11500, cost: 1000,  labour: 10500 },
    { label: "Respray (Secondary)", category: "Visual & Body",   price: 11500, cost: 1000,  labour: 10500 },
    { label: "Respray Wheels",      category: "Visual & Body",   price: 11500, cost: 1000,  labour: 10500 },
    { label: "Pearlescent",         category: "Visual & Body",   price: 11500, cost: 1000,  labour: 10500 },
    // ── Neon & Lighting ───────────────────────────────────────────────────
    // Each neon side is sold individually; Neon Color is a separate colour-change charge
    { label: "Neon Front",          category: "Neon & Lighting", price: 1000,  cost: 250,   labour: 750   },
    { label: "Neon Back",           category: "Neon & Lighting", price: 1000,  cost: 250,   labour: 750   },
    { label: "Neon Left",           category: "Neon & Lighting", price: 1000,  cost: 250,   labour: 750   },
    { label: "Neon Right",          category: "Neon & Lighting", price: 1000,  cost: 250,   labour: 750   },
    { label: "Neon Color",          category: "Neon & Lighting", price: 1000,  cost: 250,   labour: 750   },
    { label: "Xenon Lighting",      category: "Neon & Lighting", price: 2100,  cost: 1000,  labour: 1100  },
    // ── Extras ────────────────────────────────────────────────────────────
    { label: "Horns",               category: "Extras",          price: 1600,  cost: 500,   labour: 1100  },
    { label: "Hydraulics",          category: "Extras",          price: 1600,  cost: 500,   labour: 1100  },
    { label: "Plate Style",         category: "Extras",          price: 1600,  cost: 500,   labour: 1100  },
    { label: "Wheels",              category: "Extras",          price: 3900,  cost: 500,   labour: 3400  },
    { label: "Tire Smoke",          category: "Extras",          price: 4000,  cost: 1000,  labour: 3000  },
    { label: "Window Tinting",      category: "Extras",          price: 2100,  cost: 1000,  labour: 1100  },
  ]
});

export async function initDb() {
  // Enable WAL mode + full synchronous durability so committed pay/order data
  // is flushed to the persistent disk before SQLite reports success.
  await db.execute("PRAGMA journal_mode=WAL");
  // NORMAL is the recommended pairing with WAL: a bot crash/restart never loses a
  // committed write; only a whole-machine power loss could drop the last moments.
  // FULL fsyncs on every write, which is very slow on a network disk and freezes
  // the bot (libSQL runs on the main thread). Set TDC_DB_SYNC=FULL to go back.
  const syncMode = (process.env.TDC_DB_SYNC ?? "NORMAL").toUpperCase() === "FULL" ? "FULL" : "NORMAL";
  await db.execute(`PRAGMA synchronous=${syncMode}`);
  await db.execute("PRAGMA busy_timeout=5000");

  await exec(`
    CREATE TABLE IF NOT EXISTS profiles (
      discord_id TEXT PRIMARY KEY,
      display_name TEXT NOT NULL,
      sales_channel_id TEXT,
      commission_rate REAL NOT NULL DEFAULT 0.3,
      hours_worked_this_week REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'offline',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS user_roles (
      discord_id TEXT NOT NULL,
      role TEXT NOT NULL,
      UNIQUE(discord_id, role)
    );

    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      order_number TEXT NOT NULL UNIQUE,
      mechanic_id TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'draft',
      items TEXT NOT NULL DEFAULT '[]',
      parts_cost REAL NOT NULL DEFAULT 0,
      total REAL NOT NULL DEFAULT 0,
      labour REAL NOT NULL DEFAULT 0,
      notes TEXT NOT NULL DEFAULT '',
      rejected_reason TEXT,
      discord_message_id TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      approved_at TEXT,
      approved_by TEXT,
      completed_at TEXT
    );

    CREATE TABLE IF NOT EXISTS timeclock (
      id TEXT PRIMARY KEY,
      mechanic_id TEXT NOT NULL,
      clock_in_time TEXT NOT NULL,
      clock_out_time TEXT,
      duration_minutes REAL NOT NULL DEFAULT 0,
      approved_by TEXT,
      status TEXT NOT NULL DEFAULT 'approved',
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS payouts (
      id TEXT PRIMARY KEY,
      mechanic_id TEXT NOT NULL,
      week_start TEXT NOT NULL,
      amount REAL NOT NULL DEFAULT 0,
      order_count INTEGER NOT NULL DEFAULT 0,
      hours_worked REAL NOT NULL DEFAULT 0,
      invoice_count INTEGER NOT NULL DEFAULT 0,
      paid_at TEXT,
      paid_by TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      manager_cut REAL NOT NULL DEFAULT 0,
      hourly_pay REAL NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS jobs (
      id TEXT PRIMARY KEY,
      posted_by TEXT NOT NULL,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      discord_message_id TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      expires_at TEXT
    );

    CREATE TABLE IF NOT EXISTS guild_config (
      guild_id TEXT PRIMARY KEY,
      orders_channel_id TEXT,
      jobs_channel_id TEXT,
      log_channel_id TEXT,
      archive_channel_id TEXT
    );

    CREATE TABLE IF NOT EXISTS app_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS bank_account_logs (
      id TEXT PRIMARY KEY,
      guild_id TEXT NOT NULL,
      log_date TEXT NOT NULL,
      balance REAL NOT NULL,
      expected_change REAL NOT NULL DEFAULT 0,
      expected_balance REAL NOT NULL DEFAULT 0,
      actual_change REAL NOT NULL DEFAULT 0,
      variance REAL NOT NULL DEFAULT 0,
      order_count INTEGER NOT NULL DEFAULT 0,
      logged_by TEXT NOT NULL,
      logged_at TEXT NOT NULL DEFAULT (datetime('now')),
      payout_total REAL NOT NULL DEFAULT 0,
      UNIQUE(guild_id, log_date)
    );

    CREATE TABLE IF NOT EXISTS weekly_strike_checks (
      guild_id TEXT NOT NULL,
      period_start TEXT NOT NULL,
      mechanic_id TEXT NOT NULL,
      hours_worked REAL NOT NULL DEFAULT 0,
      strike_number INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (guild_id, period_start, mechanic_id)
    );

    CREATE TABLE IF NOT EXISTS loa_requests (
      id TEXT PRIMARY KEY,
      mechanic_id TEXT NOT NULL,
      guild_id TEXT NOT NULL,
      reason TEXT NOT NULL,
      start_date TEXT NOT NULL,
      return_date TEXT NOT NULL,
      notes TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      reviewed_by TEXT,
      discord_message_id TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS raffles (
      id TEXT PRIMARY KEY,
      guild_id TEXT NOT NULL,
      channel_id TEXT NOT NULL,
      message_id TEXT,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      prizes TEXT NOT NULL DEFAULT '[]',
      winner_count INTEGER NOT NULL DEFAULT 1,
      ends_at TEXT,
      started_by TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      winners TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      minimum_sales REAL NOT NULL DEFAULT 0,
      minimum_orders INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS raffle_entries (
      raffle_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      entered_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (raffle_id, user_id)
    )
  `);

  // Safe migrations
  await safeAlter("ALTER TABLE guild_config ADD COLUMN owner_role_id TEXT");
  await safeAlter("ALTER TABLE guild_config ADD COLUMN head_manager_role_id TEXT");
  await safeAlter("ALTER TABLE guild_config ADD COLUMN manager_role_id TEXT");
  await safeAlter("ALTER TABLE guild_config ADD COLUMN trainer_role_id TEXT");
  await safeAlter("ALTER TABLE guild_config ADD COLUMN mechanic_role_id TEXT");
  await safeAlter("ALTER TABLE guild_config ADD COLUMN timeclock_channel_id TEXT");
  await safeAlter("ALTER TABLE guild_config ADD COLUMN loa_channel_id TEXT");
  await safeAlter("ALTER TABLE guild_config ADD COLUMN raffle_channel_id TEXT");
  await safeAlter("ALTER TABLE timeclock ADD COLUMN clock_message_id TEXT");
  await safeAlter("ALTER TABLE timeclock ADD COLUMN clock_channel_id TEXT");
  await safeAlter("ALTER TABLE guild_config ADD COLUMN leaderboard_channel_id TEXT");
  await safeAlter("ALTER TABLE guild_config ADD COLUMN training_channel_id TEXT");
  await safeAlter("ALTER TABLE guild_config ADD COLUMN needs_training_role_id TEXT");
  await safeAlter("ALTER TABLE guild_config ADD COLUMN payday_channel_id TEXT");
  await safeAlter("ALTER TABLE profiles ADD COLUMN in_city_id TEXT");
  await safeAlter("ALTER TABLE profiles ADD COLUMN manager_id TEXT");
  await safeAlter("ALTER TABLE profiles ADD COLUMN manager_override_rate REAL DEFAULT 0.20");
  await safeAlter("ALTER TABLE timeclock ADD COLUMN warned_at TEXT");
  await safeAlter("ALTER TABLE timeclock ADD COLUMN stayed_in_at TEXT");
  await safeAlter("ALTER TABLE orders ADD COLUMN guild_id TEXT NOT NULL DEFAULT ''");
  await safeAlter("ALTER TABLE timeclock ADD COLUMN guild_id TEXT NOT NULL DEFAULT ''");
  await safeAlter("ALTER TABLE orders ADD COLUMN role_level TEXT NOT NULL DEFAULT 'mechanic'");
  await safeAlter("ALTER TABLE guild_config ADD COLUMN trainer_crew_rate REAL DEFAULT 0.10");
  await safeAlter("ALTER TABLE guild_config ADD COLUMN manager_crew_rate REAL DEFAULT 0.20");
  await safeAlter("ALTER TABLE guild_config ADD COLUMN clocklog_channel_id TEXT");
  await safeAlter("ALTER TABLE profiles ADD COLUMN commission_adjustment REAL DEFAULT 0");
  await safeAlter("ALTER TABLE profiles ADD COLUMN manager_cut_adjustment REAL DEFAULT 0");
  await safeAlter("ALTER TABLE profiles ADD COLUMN commission_labour_snapshot REAL DEFAULT 0");
  await safeAlter("ALTER TABLE profiles ADD COLUMN manager_labour_snapshot REAL DEFAULT 0");
  await safeAlter("ALTER TABLE timeclock ADD COLUMN warn_msg_id TEXT");
  await safeAlter("ALTER TABLE timeclock ADD COLUMN warn_chan_id TEXT");
  await safeAlter("ALTER TABLE orders ADD COLUMN customer_name TEXT NOT NULL DEFAULT ''");
  await safeAlter("ALTER TABLE profiles ADD COLUMN current_pay_status TEXT NOT NULL DEFAULT 'pending'");
  await safeAlter("ALTER TABLE guild_config ADD COLUMN lifetime_earnings_channel_id TEXT");
  await safeAlter("ALTER TABLE guild_config ADD COLUMN bank_account_channel_id TEXT");
  await safeAlter("ALTER TABLE payouts ADD COLUMN manager_cut REAL NOT NULL DEFAULT 0");
  await safeAlter("ALTER TABLE bank_account_logs ADD COLUMN payout_total REAL NOT NULL DEFAULT 0");
  await safeAlter("ALTER TABLE orders ADD COLUMN customer_total_override REAL");
  await safeAlter("ALTER TABLE orders ADD COLUMN is_own_car INTEGER NOT NULL DEFAULT 0");
  await safeAlter("ALTER TABLE raffles ADD COLUMN minimum_sales REAL NOT NULL DEFAULT 0");
  await safeAlter("ALTER TABLE raffles ADD COLUMN minimum_orders INTEGER NOT NULL DEFAULT 0");
  await safeAlter("ALTER TABLE profiles ADD COLUMN strike_count INTEGER NOT NULL DEFAULT 0");
  await safeAlter("ALTER TABLE profiles ADD COLUMN order_hold_until TEXT");
  await safeAlter("ALTER TABLE profiles ADD COLUMN terminated_at TEXT");
  await safeAlter("ALTER TABLE profiles ADD COLUMN strike_pay_cut_pending INTEGER NOT NULL DEFAULT 0");
  await safeAlter("ALTER TABLE payouts ADD COLUMN hourly_pay REAL NOT NULL DEFAULT 0");
  await safeAlter("ALTER TABLE timeclock ADD COLUMN last_idle_ping_at TEXT");
  await db.execute(`
    CREATE TABLE IF NOT EXISTS timeclock_confirmations (
      id TEXT PRIMARY KEY,
      timeclock_id TEXT NOT NULL,
      mechanic_id TEXT NOT NULL,
      confirmed_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);
  await db.execute(
    "CREATE INDEX IF NOT EXISTS idx_timeclock_confirmations_shift_time ON timeclock_confirmations(timeclock_id, confirmed_at)",
  );

  // ── Audit + error logging tables ───────────────────────────────────────────
  await db.execute(`
    CREATE TABLE IF NOT EXISTS audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ts TEXT NOT NULL,
      kind TEXT NOT NULL,
      guild_id TEXT,
      user_id TEXT,
      user_name TEXT,
      order_id TEXT,
      order_number TEXT,
      amount REAL,
      detail TEXT
    )
  `);
  await db.execute(`
    CREATE TABLE IF NOT EXISTS error_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ts TEXT NOT NULL,
      scope TEXT NOT NULL,
      message TEXT NOT NULL,
      code TEXT,
      stack TEXT,
      guild_id TEXT,
      user_id TEXT,
      command TEXT
    )
  `);

  // ── Indexes for the hot queries (orders / timeclock / logs) ────────────────
  for (const stmt of [
    "CREATE INDEX IF NOT EXISTS idx_audit_kind_ts ON audit_log(kind, ts)",
    "CREATE INDEX IF NOT EXISTS idx_audit_guild_ts ON audit_log(guild_id, ts)",
    "CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log(user_id)",
    "CREATE INDEX IF NOT EXISTS idx_error_ts ON error_log(ts)",
    "CREATE INDEX IF NOT EXISTS idx_orders_mechanic_status ON orders(mechanic_id, status)",
    "CREATE INDEX IF NOT EXISTS idx_orders_guild_status ON orders(guild_id, status)",
    "CREATE INDEX IF NOT EXISTS idx_orders_status_completed ON orders(status, completed_at)",
    "CREATE INDEX IF NOT EXISTS idx_timeclock_mechanic_open ON timeclock(mechanic_id, clock_out_time)",
    "CREATE INDEX IF NOT EXISTS idx_payouts_mechanic ON payouts(mechanic_id, created_at)",
  ]) {
    try { await db.execute(stmt); } catch (err) { console.error("[TDC] ⚠️ Index creation failed:", stmt, err); }
  }

  // Detect on-disk corruption early and say so loudly (does not auto-restore).
  try {
    const check = await db.execute("PRAGMA quick_check");
    const verdict = String(check.rows[0]?.[0] ?? "unknown");
    if (verdict !== "ok") console.error(`[TDC] ❌ Database quick_check FAILED: ${verdict}. Backups: ${DB_BACKUP_PATH}`);
  } catch (err) {
    console.error("[TDC] ⚠️ Database quick_check could not run:", err);
  }

  // Close only genuinely stale sessions at startup. Active sessions under eight
  // hours remain open across deploys/restarts, and staged payroll applies the
  // same idle cap as a normal clock-out.
  const { calculateCreditedShiftMinutes } = await import("./lib/timeclock.js");
  const staleSessions = await db.execute(
    `SELECT id, mechanic_id, clock_in_time FROM timeclock
     WHERE clock_out_time IS NULL
       AND datetime(COALESCE(clock_in_time, '2000-01-01')) < datetime('now', '-8 hours')`
  );
  for (const row of staleSessions.rows) {
    const id = String(row[0] ?? "");
    const mechanicId = String(row[1] ?? "");
    const clockIn = String(row[2] ?? "");
    const minutes = await calculateCreditedShiftMinutes(id, mechanicId, clockIn);
    await db.execute({
      sql: `UPDATE timeclock SET clock_out_time = datetime('now'), duration_minutes = ?,
            status = 'approved', warned_at = NULL, stayed_in_at = NULL
            WHERE id = ? AND clock_out_time IS NULL`,
      args: [minutes, id]
    });
    await db.execute({
      sql: "UPDATE profiles SET hours_worked_this_week = hours_worked_this_week + ?, status = 'offline' WHERE discord_id = ?",
      args: [minutes / 60, mechanicId]
    });
  }
  // Only mark offline mechanics whose session was just closed (not those still clocked in)
  await db.execute({
    sql: `UPDATE profiles SET status = 'offline'
          WHERE status IN ('online','on_break')
          AND discord_id NOT IN (SELECT DISTINCT mechanic_id FROM timeclock WHERE clock_out_time IS NULL)`,
    args: []
  });

  // Seed / update catalog
  await db.execute({ sql: "INSERT OR REPLACE INTO app_settings (key, value) VALUES (?, ?)", args: ["parts_catalog", TDC_CATALOG] });
  await db.execute({ sql: "INSERT OR IGNORE INTO app_settings (key, value) VALUES (?, ?)", args: ["commission_default", "0.3"] });

  console.log(`[TDC] 💾 Database path: ${DB_PATH}`);

  // Create a recovery copy immediately after startup, then repeat every
  // minute. Critical pay writes also call saveDatabaseSnapshot directly, so a
  // reset cannot discard a pay change waiting for the next scheduled save.
  await saveDatabaseSnapshot();
  setInterval(() => {
    saveDatabaseSnapshot().catch(err => console.error("[TDC] ⚠️ Scheduled database save failed:", err));
  }, 5 * 60 * 1000); // every 5 min (skipped when unchanged); important writes still snapshot immediately

  // Trim old log rows once at startup and then daily.
  const { pruneLogs } = await import("./lib/eventLog.js");
  await pruneLogs();
  setInterval(() => { pruneLogs().catch(() => {}); }, 24 * 60 * 60 * 1000);

  console.log("[TDC] Database initialized.");
}

// ── Helpers ────────────────────────────────────────────────────────────────────

// ── In-memory setting cache for hot-path reads (catalog, commission_default) ──
const _settingCache = new Map<string, { value: string; ts: number }>();
const SETTING_TTL = 60_000; // 60 seconds

export async function getSetting(key: string): Promise<string | null> {
  const cached = _settingCache.get(key);
  if (cached && Date.now() - cached.ts < SETTING_TTL) return cached.value;
  const r = await db.execute({ sql: "SELECT value FROM app_settings WHERE key = ?", args: [key] });
  const value = r.rows[0] ? String(r.rows[0][0]) : null;
  if (value !== null) _settingCache.set(key, { value, ts: Date.now() });
  return value;
}

export function invalidateSettingCache(key?: string) {
  if (key) _settingCache.delete(key);
  else _settingCache.clear();
}

/**
 * Flush SQLite's WAL into the main database file after important admin writes.
 * Crew membership and payroll settings must survive a fast process restart,
 * not just the periodic checkpoint.
 */
export async function checkpointDatabase(): Promise<void> {
  try {
    // Nothing in the write-ahead log → nothing to checkpoint (and no waiting on readers).
    const wal = `${DB_PATH}-wal`;
    if (fs.existsSync(wal) && fs.statSync(wal).size === 0) return;
    await db.execute("PRAGMA wal_checkpoint(TRUNCATE)");
  } catch { /* non-fatal */ }
}

let snapshotCount = 0;

/** Keep one dated copy per day for 7 days, so a bad write noticed late is still recoverable. */
function saveDailyBackup(): void {
  try {
    const day = new Date().toISOString().slice(0, 10);
    const dailyPath = path.join(DATA_DIR, `tdc.db.daily-${day}`);
    if (!fs.existsSync(dailyPath)) {
      fs.copyFileSync(DB_BACKUP_PATH, dailyPath);
      console.log(`[TDC] 🗓️ Daily database backup created: ${path.basename(dailyPath)}`);
      const old = fs.readdirSync(DATA_DIR)
        .filter(f => f.startsWith("tdc.db.daily-"))
        .sort()
        .slice(0, -7);
      for (const f of old) fs.unlinkSync(path.join(DATA_DIR, f));
    }
  } catch (err) {
    console.error("[TDC] ⚠️ Daily backup failed:", err);
  }
}

/**
 * Persist the committed SQLite state into a rotating recovery snapshot.
 * The previous snapshot is retained so a failed copy never destroys the last
 * known-good backup.
 */
let snapshotInFlight: Promise<void> | null = null;
let lastSnapshotSignature = "";

function dbSignature(): string {
  try {
    const main = fs.statSync(DB_PATH);
    const wal = fs.existsSync(`${DB_PATH}-wal`) ? fs.statSync(`${DB_PATH}-wal`) : null;
    return `${main.size}:${main.mtimeMs}:${wal ? `${wal.size}:${wal.mtimeMs}` : "0"}`;
  } catch {
    return "";
  }
}

/**
 * Persist the committed SQLite state into a rotating recovery snapshot.
 * The previous snapshot is retained so a failed copy never destroys the last
 * known-good backup.
 *
 * Runs off the main thread (async copy), merges overlapping calls into one,
 * and skips the copy entirely when nothing has changed since the last one —
 * so button clicks are never stuck behind a database file copy.
 */
export function saveDatabaseSnapshot(): Promise<void> {
  if (snapshotInFlight) return snapshotInFlight;
  snapshotInFlight = (async () => {
    try {
      await checkpointDatabase();
      const signature = dbSignature();
      if (signature && signature === lastSnapshotSignature && fs.existsSync(DB_BACKUP_PATH)) return;

      const tempPath = `${DB_BACKUP_PATH}.tmp`;
      await fs.promises.copyFile(DB_PATH, tempPath);
      if (fs.existsSync(DB_BACKUP_PATH)) {
        await fs.promises.rename(DB_BACKUP_PATH, DB_PREVIOUS_BACKUP_PATH); // rename, not copy: no second full copy
      }
      await fs.promises.rename(tempPath, DB_BACKUP_PATH);
      lastSnapshotSignature = signature;
      // Snapshots run every minute — only log one in ten so the console stays readable.
      snapshotCount++;
      if (snapshotCount % 10 === 1) {
        console.log(`[TDC] 💾 Database snapshot saved (${new Date().toISOString()}, #${snapshotCount})`);
      }
      saveDailyBackup();
    } catch (err) {
      console.error("[TDC] ⚠️ Database snapshot copy failed:", err);
    } finally {
      snapshotInFlight = null;
    }
  })();
  return snapshotInFlight;
}

export async function setSetting(key: string, value: string): Promise<void> {
  await db.execute({ sql: "INSERT OR REPLACE INTO app_settings (key, value) VALUES (?, ?)", args: [key, value] });
  invalidateSettingCache(key);
}

type GuildConfigRow = NonNullable<Awaited<ReturnType<typeof loadGuildConfig>>>;
const _guildConfigCache = new Map<string, { value: GuildConfigRow | null; ts: number }>();
const GUILD_CONFIG_TTL_MS = 15_000;

/** Forget cached server config (call after any write to guild_config). */
export function invalidateGuildConfigCache(guildId?: string) {
  if (guildId) _guildConfigCache.delete(guildId);
  else _guildConfigCache.clear();
}

/** Server config is read on almost every click, so it is cached briefly. */
export async function getGuildConfig(guildId: string): Promise<GuildConfigRow | null> {
  const hit = _guildConfigCache.get(guildId);
  if (hit && Date.now() - hit.ts < GUILD_CONFIG_TTL_MS) return hit.value;
  const value = await loadGuildConfig(guildId);
  _guildConfigCache.set(guildId, { value, ts: Date.now() });
  return value;
}

async function loadGuildConfig(guildId: string) {
  const r = await db.execute({
    sql: `SELECT guild_id,
                 orders_channel_id, jobs_channel_id, log_channel_id, archive_channel_id,
                 owner_role_id, manager_role_id, trainer_role_id, mechanic_role_id,
                 timeclock_channel_id, loa_channel_id, raffle_channel_id,
                 leaderboard_channel_id, training_channel_id, needs_training_role_id,
                  payday_channel_id, trainer_crew_rate, manager_crew_rate, clocklog_channel_id,
                  lifetime_earnings_channel_id, bank_account_channel_id, head_manager_role_id
          FROM guild_config WHERE guild_id = ?`,
    args: [guildId]
  });
  if (!r.rows[0]) return null;
  const row = r.rows[0];
  return {
    guild_id:                      String(row[0]  ?? ""),
    orders_channel_id:             row[1]  ? String(row[1])  : null,
    jobs_channel_id:               row[2]  ? String(row[2])  : null,
    log_channel_id:                row[3]  ? String(row[3])  : null,
    archive_channel_id:            row[4]  ? String(row[4])  : null,
    owner_role_id:                 row[5]  ? String(row[5])  : null,
    manager_role_id:               row[6]  ? String(row[6])  : null,
    trainer_role_id:               row[7]  ? String(row[7])  : null,
    mechanic_role_id:              row[8]  ? String(row[8])  : null,
    timeclock_channel_id:          row[9]  ? String(row[9])  : null,
    loa_channel_id:                row[10] ? String(row[10]) : null,
    raffle_channel_id:             row[11] ? String(row[11]) : null,
    leaderboard_channel_id:        row[12] ? String(row[12]) : null,
    training_channel_id:           row[13] ? String(row[13]) : null,
    needs_training_role_id:        row[14] ? String(row[14]) : null,
    payday_channel_id:             row[15] ? String(row[15]) : null,
    trainer_crew_rate:             row[16] != null ? Number(row[16]) : 0.10,
    manager_crew_rate:             row[17] != null ? Number(row[17]) : 0.20,
    clocklog_channel_id:           row[18] ? String(row[18]) : null,
    lifetime_earnings_channel_id:  row[19] ? String(row[19]) : null,
    bank_account_channel_id:       row[20] ? String(row[20]) : null,
    head_manager_role_id:          row[21] ? String(row[21]) : null,
  };
}

export async function setGuildConfig(
  guildId: string,
  field: "orders_channel_id" | "jobs_channel_id" | "log_channel_id" | "archive_channel_id" | "timeclock_channel_id" | "loa_channel_id" | "raffle_channel_id" | "leaderboard_channel_id" | "training_channel_id" | "payday_channel_id" | "clocklog_channel_id" | "lifetime_earnings_channel_id" | "bank_account_channel_id",
  channelId: string
): Promise<void> {
  await db.execute({
    sql: `INSERT INTO guild_config (guild_id, ${field}) VALUES (?, ?)
          ON CONFLICT(guild_id) DO UPDATE SET ${field} = excluded.${field}`,
    args: [guildId, channelId]
  });
  invalidateGuildConfigCache(guildId);
}

export async function setGuildCrewRate(
  guildId: string,
  field: "trainer_crew_rate" | "manager_crew_rate",
  rate: number
): Promise<void> {
  await db.execute({
    sql: `INSERT INTO guild_config (guild_id, ${field}) VALUES (?, ?)
          ON CONFLICT(guild_id) DO UPDATE SET ${field} = excluded.${field}`,
    args: [guildId, rate]
  });
  invalidateGuildConfigCache(guildId);
}

export async function setGuildRoleMapping(
  guildId: string,
  level: "owner" | "head_manager" | "manager" | "trainer" | "mechanic" | "needs_training",
  roleIds: string[]
): Promise<void> {
  const field = `${level}_role_id`;
  const value = roleIds.filter(Boolean).join(",");
  await db.execute({
    sql: `INSERT INTO guild_config (guild_id, ${field}) VALUES (?, ?)
          ON CONFLICT(guild_id) DO UPDATE SET ${field} = excluded.${field}`,
    args: [guildId, value]
  });
  invalidateGuildConfigCache(guildId);
}

/** Split a comma-separated role ID string into an array of IDs */
export function splitRoleIds(s: string | null | undefined): string[] {
  return (s ?? "").split(",").map(r => r.trim()).filter(Boolean);
}

let orderNumberQueue: Promise<void> = Promise.resolve();

export function nextOrderNumber(): Promise<string> {
  // The bot is a single process, but several Discord interactions can arrive
  // concurrently. Serialising this read/update sequence prevents two drafts
  // from receiving the same number before the UNIQUE constraint is checked.
  const task = orderNumberQueue.then(async () => {
    // Ensure the sequence row exists
    await db.execute("INSERT OR IGNORE INTO app_settings (key, value) VALUES ('order_seq', '0')");

    // Sync the counter up to the highest order number already in the table.
    // This self-heals if the counter ever falls behind (e.g. after a DB restore
    // or if orders were inserted via a different path).
    await db.execute(
      `UPDATE app_settings
       SET value = CAST(
         MAX(
           CAST(value AS INTEGER),
           COALESCE(
             (SELECT MAX(CAST(SUBSTR(order_number, 5) AS INTEGER))
              FROM orders
              WHERE order_number LIKE 'TDC-%'
                AND LENGTH(order_number) >= 8),
             0
           )
         ) AS TEXT
       )
       WHERE key = 'order_seq'`
    );

    // Atomically increment and read the new value
    const results = await db.batch([
      {
        sql: "UPDATE app_settings SET value = CAST(CAST(value AS INTEGER) + 1 AS TEXT) WHERE key = 'order_seq'",
        args: []
      },
      {
        sql: "SELECT value FROM app_settings WHERE key = 'order_seq'",
        args: []
      }
    ], "write");
    const num = parseInt(String(results[1].rows[0]?.[0] ?? "1"), 10);
    return `TDC-${String(num).padStart(4, "0")}`;
  });

  // Keep the queue usable even if one database operation fails.
  orderNumberQueue = task.then(() => undefined, () => undefined);
  return task;
}

// NOTE: order_seq is intentionally never reset — it is a globally monotonic counter.
// The pay-period boundary is tracked via order_number_reset_ts in app_settings.

export async function getProfile(discordId: string) {
  const r = await db.execute({ sql: "SELECT discord_id, display_name, sales_channel_id, commission_rate, hours_worked_this_week, status, created_at, in_city_id, manager_id, manager_override_rate, commission_adjustment, manager_cut_adjustment, commission_labour_snapshot, manager_labour_snapshot FROM profiles WHERE discord_id = ?", args: [discordId] });
  if (!r.rows[0]) return null;
  const row = r.rows[0];
  return {
    discord_id:                    String(row[0] ?? ""),
    display_name:                  String(row[1] ?? ""),
    sales_channel_id:              row[2] ? String(row[2]) : null,
    commission_rate:               Number(row[3] ?? 0.3),
    hours_worked_this_week:        Number(row[4] ?? 0),
    status:                        String(row[5] ?? "offline"),
    created_at:                    String(row[6] ?? ""),
    in_city_id:                    row[7] ? String(row[7]) : null,
    manager_id:                    row[8] ? String(row[8]) : null,
    manager_override_rate:         Number(row[9] ?? 0.20),
    commission_adjustment:         Number(row[10] ?? 0),
    manager_cut_adjustment:        Number(row[11] ?? 0),
    commission_labour_snapshot:    Number(row[12] ?? 0),
    manager_labour_snapshot:       Number(row[13] ?? 0),
  };
}

export async function ensureProfile(discordId: string, displayName: string) {
  await db.execute({ sql: "INSERT OR IGNORE INTO profiles (discord_id, display_name) VALUES (?, ?)", args: [discordId, displayName] });
  return getProfile(discordId);
}

export async function getUserRole(discordId: string): Promise<string | null> {
  const r = await db.execute({ sql: "SELECT role FROM user_roles WHERE discord_id = ?", args: [discordId] });
  if (!r.rows.length) return null;
  const hierarchy: Record<string, number> = { owner: 4, manager: 3, trainer: 2, mechanic: 1 };
  const roles = r.rows.map(row => String(row[0]));
  return roles.reduce((best, role) => (hierarchy[role] ?? 0) > (hierarchy[best] ?? 0) ? role : best);
}

export async function hasRole(discordId: string, minRole: string): Promise<boolean> {
  const hierarchy: Record<string, number> = { owner: 4, manager: 3, trainer: 2, mechanic: 1 };
  const role = await getUserRole(discordId);
  if (!role) return false;
  return (hierarchy[role] ?? 0) >= (hierarchy[minRole] ?? 0);
}

function cell(row: unknown, idx: number): unknown {
  if (Array.isArray(row)) return row[idx];
  if (row && typeof row === "object") return (row as Record<string | number, unknown>)[idx];
  return undefined;
}

export function rowToOrder(row: unknown): import("./types.js").Order {
  const c = (i: number) => cell(row, i);
  return {
    id:               String(c(0)  ?? ""),
    order_number:     String(c(1)  ?? ""),
    mechanic_id:      String(c(2)  ?? ""),
    status:           String(c(3)  ?? "draft") as any,
    items:            (() => { try { return JSON.parse(String(c(4) ?? "[]")); } catch { return []; } })(),
    parts_cost:       Number(c(5)  ?? 0),
    total:            Number(c(6)  ?? 0),
    labour:           Number(c(7)  ?? 0),
    notes:            String(c(8)  ?? ""),
    rejected_reason:  c(9)  ? String(c(9))  : null,
    discord_message_id: c(10) ? String(c(10)) : null,
    created_at:       String(c(11) ?? ""),
    approved_at:      c(12) ? String(c(12)) : null,
    approved_by:      c(13) ? String(c(13)) : null,
    completed_at:     c(14) ? String(c(14)) : null,
    role_level:              c(16) ? String(c(16)) : "mechanic",
    customer_name:           c(17) ? String(c(17)) : "",
    customer_total_override: c(18) != null ? Number(c(18)) : null,
    is_own_car:               Number(c(19) ?? 0) === 1,
  };
}

export function rowToTimeclock(row: unknown): import("./types.js").Timeclock {
  const c = (i: number) => cell(row, i);
  return {
    id:               String(c(0)  ?? ""),
    mechanic_id:      String(c(1)  ?? ""),
    clock_in_time:    String(c(2)  ?? ""),
    clock_out_time:   c(3)  ? String(c(3))  : null,
    duration_minutes: Number(c(4)  ?? 0),
    approved_by:      c(5)  ? String(c(5))  : null,
    status:           String(c(6)  ?? "approved") as any,
    notes:            c(7)  ? String(c(7))  : null,
    created_at:       String(c(8)  ?? ""),
    clock_message_id: c(9)  ? String(c(9))  : null,
    clock_channel_id: c(10) ? String(c(10)) : null,
    warn_msg_id:      c(14) ? String(c(14)) : null,
    warn_chan_id:     c(15) ? String(c(15)) : null,
  };
}
